package tw.gov.ndc.emsg.mydata;

import java.util.Locale;

import com.riease.common.sysinit.InitConfig;

/**
 * 繼承自com.riease.sysinit.InitConfig
 * 注意所需的property是否已被宣告於InitConfig。
 * 註：未來有機會被重覆使用的項目，宣告於InitConfig。
 * 
 * @author wesleyzhuang
 * @see com.riease.common.sysinit.InitConfig
 */
public class Config extends InitConfig { 

	/**
	 * 目前版本
	 */
	public static final String Version = "1.0.02-20170613";
	
	/**
	 * 會員預設語系
	 */
	public static final Locale MemberDefaultLocale = new Locale("zh","CN");
	/**
	 * 網址contextUrl
	 */
	public static final String AppContextUrl = getValue("app.backend.context.url");	
	
	/**
	 * 排程參數
	 */
	public static final boolean CronExp_Enable = getBooleanValue("CronExp_Enable");	
	public static final String RssCatch_CronExp = getValue("RssCatch_CronExp");	
	
}

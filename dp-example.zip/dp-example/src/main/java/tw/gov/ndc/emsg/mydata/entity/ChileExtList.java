package tw.gov.ndc.emsg.mydata.entity;

import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class ChileExtList {
	
	private List<ChildExt> childExtList;

	public List<ChildExt> getChildExtList() {
		return childExtList;
	}
	@XmlElement
	public void setChildExtList(List<ChildExt> childExtList) {
		this.childExtList = childExtList;
	}
}

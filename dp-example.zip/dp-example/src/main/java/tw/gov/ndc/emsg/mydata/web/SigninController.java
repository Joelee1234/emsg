/**
 * 
 */
package tw.gov.ndc.emsg.mydata.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.riease.common.sysinit.SysCode;
import tw.gov.ndc.emsg.mydata.Config;
import tw.gov.ndc.emsg.mydata.auth.SigninForm;

/**
 * 後台登入頁 - mvc controller
 * @author wesleyzhuang
 *
 */
@Controller
@RequestMapping("/")
public class SigninController {

	private static final Logger logger = LoggerFactory.getLogger(SigninController.class);
		
	
	@GetMapping("/signin")
	public String getSignin(
			SigninForm form,
			@RequestParam(value="error", required=false) String errorCode,
    		ModelMap model,
            BindingResult error) {
		
		if (errorCode != null) {
			SysCode sc = SysCode.ofStringValue(errorCode);
			if(SysCode.InvalidCaptcha == sc) {
				error.rejectValue("captcha", errorCode);
			}else if(SysCode.AccountNotExist == sc) {
				error.rejectValue("account", errorCode);
			}else if(SysCode.AuthenticateFail == sc) {
				error.rejectValue("passwd", errorCode);
			}
 		}
		
		model.addAttribute("version", Config.Version);
		
		return "login";
	}
}

/**
 * 
 */
package com.riease.common.function;

/**
 * 網頁功能項目必須實作的介面
 * @author Cid
 *
 */
public interface CFunction {
	
	public CFunctionItem item();
	
	public String name();
}

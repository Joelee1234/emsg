/**
 * 
 */
package com.riease.common.validator;

/**
 * 驗證PrimaryKey
 * @author wesleyzhuang
 *
 */
public interface ValidatePK {

}

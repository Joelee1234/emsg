import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

public class test005 {

	public static void main(String[] args) {
		/*System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.keyStoreType", "pkcs12"); */
		String pfxFileName = "/Users/mac/Desktop/keylist/emsg_tester.pfx";
		String pfxPassword = "12345678";
		File fPkcs12 = null;
		if (pfxFileName != null) {
			// Open the file
			fPkcs12 = new File(pfxFileName);
		}
		FileInputStream fis;
		try {
			fis = new FileInputStream(fPkcs12);
			//KeyStore store = KeyStore.getInstance("JKS");
			KeyStore store = KeyStore.getInstance("PKCS12");
			store.load(fis, pfxPassword.toCharArray());
			System.out.println(store.getCertificate("mydata_tester"));
		} catch (FileNotFoundException e) {
			System.out.println("FileNotFoundException\n"+e);
		} catch (KeyStoreException e) {
			System.out.println("KeyStoreException\n"+e);
		} catch (NoSuchAlgorithmException e) {
			System.out.println("NoSuchAlgorithmException\n"+e);
		} catch (CertificateException e) {
			System.out.println("CertificateException\n"+e);
		} catch (IOException e) {
			System.out.println("IOException\n"+e);
		}
	}

}

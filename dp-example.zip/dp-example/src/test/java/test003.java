import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.StringWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import tw.gov.ndc.emsg.mydata.entity.Account;
import tw.gov.ndc.emsg.mydata.entity.ChildExt;
import tw.gov.ndc.emsg.mydata.entity.ChileExtList;
import tw.gov.ndc.emsg.mydata.entity.Growth;
import tw.gov.ndc.emsg.mydata.entity.VaccinationRecord;

public class test003 {

	public static void main(String[] args) throws JAXBException {
		/**
		 * 資料庫資料存取
		 */
		Account account = null;
		account = new Account();
		account.setAccountId("D85D2CE6-16DC-41BF-8EBC-EE43B1E736AE");
		account.setLoginId("H296197830");
		account.setAddress("桃園市桃園區莊敬路二段38號");
		account.setPid("H296197830");
		account.setName("李小花");

		List<ChildExt> childExtList = new ArrayList<ChildExt>();
		ChildExt ext = new ChildExt();
		//ext.set
		ext.setBirthday(new Date());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date t = formatter.parse("1982-09-27");
			ext.setBirthday(t);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		ext.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
		try {
			Date t1 = formatter.parse("2016-01-01");
			ext.setBirthday(t1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Date t2 = formatter.parse("2017-01-01");
			ext.setCtime(t2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		ext.setName("李大童");
		ext.setGender("m");
		ext.setParentPid("H296197830");
		List<Growth> growthList = new ArrayList<Growth>();
		for(int i=0;i<10;i++) {
			Growth g = new Growth();
			g.setGid("09B0EA4E-B8E6-4666-9381-797499EA59BB");
			g.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
			g.setParentPid("H296197830");
			g.setHeight(81d);
			g.setWeight(21d);
			g.setHeadCircumference(41d);
			String inpstr = "2017-"+i+"-01";
			try {
				Date t3 = formatter.parse(inpstr);
				g.setCtime(t3);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			g.setCanChange(0);
			growthList.add(g);
		}
		ext.setGrowthList(growthList);
		
		List<VaccinationRecord> vaccinationRecordList = new ArrayList<VaccinationRecord>();
		for(int i=0;i<10;i++) {
			String inpstr = "2017-"+i+"-01";
			VaccinationRecord v = new VaccinationRecord();
			v.setVrid("1339FE87-4434-402C-BA6C-782454CC4AAD");
			v.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
			v.setParentPid("H296197830");
			v.setSuitableAge("出生滿4個月");
			v.setVaccineSpecies("白喉破傷風非細胞性百日咳、b型嗜血桿菌及不活化小兒麻痺五合一疫苗 第二劑");
			v.setVaccineCount(2);
			v.setCanChange(0);
			v.setSubsidy(1);
			v.setInoculated("1");
			v.setUnit("衛生福利部桃園醫院");
			try {
				Date t3 = formatter.parse(inpstr);
				v.setCtime(t3);
				v.setVaccinationDate(t3);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
			vaccinationRecordList.add(v);
		}
		ext.setVaccinationRecordList(vaccinationRecordList);
		childExtList.add(ext);
		ChileExtList ChileObjExtList = new ChileExtList();
		ChileObjExtList.setChildExtList(childExtList);
		
        JAXBContext jaxbContext = JAXBContext.newInstance(ChileExtList.class);
        Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
        jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
        StringWriter sw = new StringWriter();
        jaxbMarshaller.marshal(ChileObjExtList, sw);
        String xmlString = sw.toString();
        System.out.println(xmlString);
        //Write to File
        BufferedWriter bOut;
		try {
			bOut = new BufferedWriter(new FileWriter("/Users/mac/Desktop/tmp/child.xml"));
			for(int i=0;i<((xmlString.length()/1000)+1);i++) {
				int start = 0+i*1000;
				int last = 1000+i*1000;
				if(last>xmlString.length()) {
					last = xmlString.length();
				}
				bOut.write(xmlString.substring(start, last));
				bOut.flush();
			}
			bOut.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
              
	}

}


import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
 
public class test002 {
	
	public static void main(String[] args) {
		String objStr = "{alg: \"HS256\",typ: \"JWT\"}";
		try {
			Algorithm algorithm = Algorithm.HMAC256("vkWj0iDkmS");
		    String token = JWT.create()
		            //.withIssuer("auth0")
		            .withClaim("alg", "HS256")
		            .withClaim("typ", "JWT")
		            //.with
		            .sign(algorithm);
			/*Map<String, Object> headerClaims = new HashMap();
			headerClaims.put("owner", "auth0");
			String token = JWT.create()
			        .withHeader(headerClaims)
			        .sign(algorithm);*/
		    System.out.println(token);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}

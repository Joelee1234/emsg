/**
 * 
 */
package com.riease.common.validator;

/**
 * 在變更資料狀態時驗證
 * @author wesleyzhuang
 *
 */
public interface ValidateChangeStatus {

}

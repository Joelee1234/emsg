package com.riease.common.helper;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;
import java.util.SortedSet;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;
import java.util.zip.ZipInputStream;

import org.apache.log4j.Logger;

public class ZipUtil {
	Logger logger = Logger.getLogger(ZipUtil.class);

	public static final int LIST = 0, EXTRACT = 1;
	protected int mode = LIST;
	protected ZipFile zippy;
	protected byte[] b;
	private String unzipFileTargetLocation;

	public ZipUtil() {
		b = new byte[8092];
	}

	public void setMode(int m) {
		if (m == LIST || m == EXTRACT)
			mode = m;
	}

	protected SortedSet dirsMade;

	public void unZip(String fileName, String unZipTarget) {
		this.unzipFileTargetLocation = unZipTarget;
		dirsMade = new TreeSet();
		try {
			zippy = new ZipFile(fileName);
			Enumeration all = zippy.entries();
			while (all.hasMoreElements()) {
				getFile((ZipEntry) all.nextElement());
			}
		} catch (IOException err) {
			logger.error("IO Error: " + err);
			return;
		}
	}

	protected boolean warnedMkDir = false;

	protected void getFile(ZipEntry e) throws IOException {
		String zipName = e.getName();
		switch (mode) {
		case EXTRACT:
			if (zipName.startsWith("/")) {
				if (!warnedMkDir)
					System.out.println("Ignoring absolute paths");
				warnedMkDir = true;
				zipName = zipName.substring(1);
			}
			// if a directory, just return. We mkdir for every file,
			// since some widely-used Zip creators don't put out
			// any directory entries, or put them in the wrong place.
			if (zipName.endsWith("/")) {
				return;
			}
			// Else must be a file; open the file for output
			// Get the directory part.
			int ix = zipName.lastIndexOf('/');
			if (ix > 0) {
				String dirName = zipName.substring(0, ix);
				String fileName = zipName.substring(ix + 1, zipName.length());
				zipName = fileName;

			}
			logger.debug("Creating " + zipName);
			String targetFile = this.unzipFileTargetLocation;
			File file = new File(targetFile);
			if (!file.exists())
				file.createNewFile();
			FileOutputStream os = new FileOutputStream(targetFile);
			InputStream is = zippy.getInputStream(e);
			int n = 0;
			while ((n = is.read(b)) > 0)
				os.write(b, 0, n);
			is.close();
			os.close();
			break;
		case LIST:
			// Not extracting, just list
			if (e.isDirectory()) {
				logger.info("Directory " + zipName);
			} else {
				logger.info("File " + zipName);
			}
			break;
		default:
			throw new IllegalStateException("mode value (" + mode + ") bad");
		}
	}

	/**
	 * unzip zip file with
	 * 
	 * @param unZipFile,and
	 *            save unzipped file to
	 * @param saveFilePath
	 * @param unZipFile
	 *            full file path,like 'd:\temp\test.zip'
	 * @param saveFilePath
	 *            full file path,like 'd:\temp\test.kml'
	 * @return
	 */
	public static boolean unzip(String unZipFile, String saveFilePath) {
		boolean succeed = true;
		ZipInputStream zin = null;
		ZipEntry entry;
		try {
			// zip file path
			File olddirec = new File(unZipFile);
			zin = new ZipInputStream(new FileInputStream(unZipFile));
			// iterate ZipEntry in zip
			while ((entry = zin.getNextEntry()) != null) {
				// if folder,create it
				if (entry.isDirectory()) {
					File directory = new File(olddirec.getParent(), entry.getName());
					if (!directory.exists()) {
						if (!directory.mkdirs()) {
							System.out.println("Create foler in " + directory.getAbsoluteFile() + " failed");
						}
					}
					zin.closeEntry();
				}
				// if file,unzip it
				if (!entry.isDirectory()) {
					File myFile = new File(saveFilePath);
					FileOutputStream fout = new FileOutputStream(myFile);
					DataOutputStream dout = new DataOutputStream(fout);
					byte[] b = new byte[1024];
					int len = 0;
					while ((len = zin.read(b)) != -1) {
						dout.write(b, 0, len);
					}
					dout.close();
					fout.close();
					zin.closeEntry();
				}
			}
		} catch (IOException e) {
			e.printStackTrace();
			succeed = false;
			System.out.println(e);
		} finally {
			if (null != zin) {
				try {
					zin.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		if (succeed)
			System.out.println("File unzipped successfully!");
		else
			System.out.println("File unzipped with failure!");
		return succeed;
	}
}

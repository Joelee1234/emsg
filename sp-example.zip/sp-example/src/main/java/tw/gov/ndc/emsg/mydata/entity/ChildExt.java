package tw.gov.ndc.emsg.mydata.entity;

import java.util.Date;
import java.util.List;

public class ChildExt {

	private String cid;
	private String pid;
	private String parentPid;
	private String name;
	private String gender;
	private Date birthday;
	private Date ctime;
	private List<Growth> growthList;
	private List<VaccinationRecord> vaccinationRecordList;
	public String getCid() {
		return cid;
	}
	public void setCid(String cid) {
		this.cid = cid;
	}
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public String getParentPid() {
		return parentPid;
	}
	public void setParentPid(String parentPid) {
		this.parentPid = parentPid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getBirthday() {
		return birthday;
	}
	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	public Date getCtime() {
		return ctime;
	}
	public void setCtime(Date ctime) {
		this.ctime = ctime;
	}
	public List<Growth> getGrowthList() {
		return growthList;
	}
	public void setGrowthList(List<Growth> growthList) {
		this.growthList = growthList;
	}
	public List<VaccinationRecord> getVaccinationRecordList() {
		return vaccinationRecordList;
	}
	public void setVaccinationRecordList(List<VaccinationRecord> vaccinationRecordList) {
		this.vaccinationRecordList = vaccinationRecordList;
	}
}

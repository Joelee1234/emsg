package tw.gov.ndc.emsg.mydata.entity;

import java.util.List;

public class ChBook {
	private List<Growth> growthList;
	private List<VaccinationRecord> vaccinationRecordList;
	public List<Growth> getGrowthList() {
		return growthList;
	}
	public void setGrowthList(List<Growth> growthList) {
		this.growthList = growthList;
	}
	public List<VaccinationRecord> getVaccinationRecordList() {
		return vaccinationRecordList;
	}
	public void setVaccinationRecordList(List<VaccinationRecord> vaccinationRecordList) {
		this.vaccinationRecordList = vaccinationRecordList;
	}
	
}

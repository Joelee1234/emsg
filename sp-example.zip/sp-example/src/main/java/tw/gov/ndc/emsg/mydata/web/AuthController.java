package tw.gov.ndc.emsg.mydata.web;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tw.gov.ndc.emsg.mydata.entity.Authcode;
import tw.gov.ndc.emsg.mydata.entity.AuthcodeExample;
import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.bean.IntrospectEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.TokenEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.TokenRecord;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;
import tw.gov.ndc.emsg.mydata.mapper.AuthcodeMapper;

@Controller
@RequestMapping("/authcode")
public class AuthController {
	private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
	
	@Value("${gsp.oidc.client.id}")
	private String clientId;	
	@Value("${app.oidc.redirect.uri}")
	private String redirectUri;
	@Value("${gsp.oidc.client.secret}")
	private String clientSecret;
	@Value("${app.oidc.logout.redirect.uri}")
	private String logoutRedirectUri;
	
	@Autowired
	private GspOidcClient gspClient;
	
	/*@Autowired
	private AuthcodeMapper authcodeMapper;*/	
	
	/**
	 * 登入GSP後，回傳位置(app.oidc.redirect.uri)
	 * @param code
	 * @param idToken
	 * @param scope
	 * @param nonce
	 * @param state
	 * @param sessionState
	 * @param body
	 * @param model
	 * @param request
	 * @param response
	 * @return
	 */
	@PostMapping
	public String post(
			@RequestParam(name="code",required=false) String code,			//authorization code
			@RequestParam(name="id_token",required=false) String idToken,	//id token, 用來識別user身份
			@RequestParam(name="scope",required=false) String scope,			//被許可的權限項目
			@RequestParam(name="nonce",required=false) String nonce,		//請求時帶入的nonce參數
			@RequestParam(name="state",required=false) String state,		//請求時帶入的state參數
			@RequestParam(name="session_state",required=false) String sessionState,	//authorization server上的sessionId
			@RequestBody String body,
			ModelMap model,
			HttpServletRequest request,
			HttpServletResponse response) {
		
		logger.debug("print request parameters ........... ");
		logger.debug("code ............ {}", code);
		logger.debug("id_token ........ {}", idToken);
		logger.debug("scope ........... {}", scope);
		logger.debug("nonce ........... {}", nonce);
		logger.debug("state ........... {}", state);
		logger.debug("session_state ... {}", sessionState);
		model.addAttribute("codeInfo", body);
		
		/*
		 * 取得 access_token 
		 * (oauth2.0規範，回傳先送回code,第二次再送code取得access_token)
		 */
		TokenEntity tokenEntity = null;
		try {
			//以authorization_code去要求access_token
			tokenEntity = gspClient.requestAccessToken(code);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(tokenEntity != null) {
			logger.debug("id_token ........ {}", tokenEntity.getIdToken());
			logger.debug("access_token .... {}", tokenEntity.getAccessToken());
			logger.debug("expires_in ...... {}", tokenEntity.getExpiresIn());
			logger.debug("token_type ...... {}", tokenEntity.getTokenType());
			logger.debug("refresh_token ... {}", tokenEntity.getRefreshToken());
			model.addAttribute("tokenEntity", tokenEntity);
		}else {
			logger.debug("tokenEntity is NULL");
		}
		
		/*
		 * 取得登出URL
		 * 根據id_token，算出登出網址
		 */
		if(tokenEntity != null) {
			String signOutUrl = gspClient.signOutUrl(tokenEntity.getIdToken());
			logger.debug("signOutUrl ...... {}", signOutUrl);
			model.addAttribute("signOutUrl", signOutUrl);
		}else {
			logger.debug("tokenEntity is NULL");
		}
		/*
		 * 取得 user_info
		 * 根據access_token，(UserInfoEntity)，取得使用者基本資料(GSP上)
		 */
		UserInfoEntity userInfoEntity = null;
		try {
			//以access_token去要求user_info
			if(tokenEntity != null) {
				userInfoEntity = gspClient.requestUserInfo(tokenEntity.getAccessToken());
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(userInfoEntity != null) {
			logger.debug("sub .............. {}", userInfoEntity.getSub()); //與id_token相同
			logger.debug("account .......... {}", userInfoEntity.getAccount()); //egov帳號
			logger.debug("uid .............. {}", userInfoEntity.getUid()); //身份證字號
			logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); //身份證字號是否已驗證
			logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate()); 
			logger.debug("gender ........... {}", userInfoEntity.getGender()); 
			logger.debug("name ............. {}", userInfoEntity.getName()); 
			logger.debug("email ............ {}", userInfoEntity.getEmail()); 
			logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified()); 
			model.addAttribute("userInfoEntity", userInfoEntity);
		}else {
			logger.debug("userInfoEntity is NULL");
		}
		
		/*//查詢授權記錄
		List<TokenRecord> tokenRecords = null;
		try {
			tokenRecords = gspClient.requestTokenRecords(tokenEntity.getAccessToken());
			//logger.info("tokenRecords ... {}", tokenRecords);
			tokenRecords.forEach(p -> {
				logger.debug("key ................ {}", p.getKey());
				logger.debug("clientId ........... {}", p.getClientId());
				logger.debug("creationTime ....... {}", DateFormatUtils.format(p.getCreationTime(), "yyyy-MM-dd HH:mm:ss"));
				logger.debug("expiration ......... {}", p.getExpiration());
				logger.debug("subjectId .......... {}", p.getSubjectId());
				logger.debug("type ............... {}", p.getType());
				logger.debug("data.subjectId ..... {}", p.getTokenData().getSubjectId());
				logger.debug("data.clientId ...... {}", p.getTokenData().getClientId());
				logger.debug("data.scopes ........ {}", p.getTokenData().getScopes());
				logger.debug("data.creationTime .. {}", DateFormatUtils.format(p.getTokenData().getCreationTime(),"yyyy-MM-dd HH:mm:ss"));
				logger.debug("data.expiration .... {}", p.getTokenData().getExpiration());
			});
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		//取消授權
		if(tokenRecords.size() > 0) {
			TokenRecord tr = tokenRecords.get(0);
			try {
				Boolean isCanceled = gspClient.cancelTokenRecord(tokenEntity.getAccessToken(), tr.getKey());
				logger.debug("取消授權記錄 ... {} , token:{} , key:{}", isCanceled, tokenEntity.getAccessToken(), tr.getKey());
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
		
		//確認登入
		//if(userInfoEntity != null && userInfoEntity.getIsValidUid() && userInfoEntity.getUid() !=null && userInfoEntity.getUid().trim().length()>0) {
		if(userInfoEntity != null && userInfoEntity.getUid() !=null && userInfoEntity.getUid().trim().length()>0) {
			doAutoLogin(userInfoEntity.getUid(),userInfoEntity.getUid(),request);
			HttpSession session = request.getSession();
			session.setAttribute("accessToken", tokenEntity.getAccessToken());
			/**
			 * 資料庫動作，習慣上會紀錄到資料庫登入紀錄
			 */
			//TODO 資料庫動作
			
			//導向服務內頁
			return "redirect:/sp/chBook_in";
		} else {
			return "redirect:/sp/tychSP_chBook";
		}
		//return "authcode";
	}
	
	private void doAutoLogin(String username, String password, HttpServletRequest request) {
	    try {
	        // Must be called from request filtered by Spring Security, otherwise SecurityContextHolder is not updated
	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password,Collections.emptyList());
	        token.setDetails(new WebAuthenticationDetails(request));
	        /*CustomAuthenticationProvider customAuthenticationProvider = new CustomAuthenticationProvider();
	        Authentication authentication = customAuthenticationProvider.authenticate(token);
	        logger.debug("Logging in with [{}]", authentication.getPrincipal());*/
	        SecurityContextHolder.getContext().setAuthentication(token);
	    } catch (Exception e) {
	        SecurityContextHolder.getContext().setAuthentication(null);
	        logger.error("Failure in autoLogin", e);
	    }

	}
	
}

package test;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509CRL;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.bouncycastle.asn1.x509.AccessDescription;
import org.bouncycastle.asn1.x509.AuthorityInformationAccess;
import org.bouncycastle.asn1.x509.Extension;
import org.bouncycastle.asn1.x509.GeneralName;
import org.bouncycastle.asn1.x509.X509ObjectIdentifiers;
import org.bouncycastle.x509.extension.X509ExtensionUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import no.difi.certvalidator.Validator;
import no.difi.certvalidator.ValidatorBuilder;
import no.difi.certvalidator.rule.CRLRule;
import no.difi.certvalidator.rule.ExpirationRule;
import no.difi.certvalidator.rule.OCSPRule;
import no.difi.certvalidator.util.SimpleCertificateBucket;

public class testOcspAndCrl {
	
	private static final Logger log = LoggerFactory.getLogger(testOcspAndCrl.class);
	private static File certFile = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/certification.cer");
	
	public static void main(String[] args) throws Exception {
		boolean ocspCheck = runOCSP();
		System.out.println("=ocspCheck=:"+ocspCheck);
		boolean crlCheck = runCRL();
		System.out.println("=crlCheck=:"+crlCheck);
	}
	/**
	 * 使用 OCSP 方式向 CA 驗證憑證是否有效.
	 * 該方式需先取得 Authority Information Access issuer 憑證. 
	 * @throws Exception
	 */
	public static boolean runOCSP() throws Exception {
		
		X509Certificate certificate = toX509Certificate(certFile);
		log.info("read certificate subject >>> {}", certificate.getSubjectX500Principal());
		log.info("read certificate issuer >>> {}", certificate.getIssuerX500Principal());
	
		// 需要從 certificate file 檔案抓取 Authority Information Access
		List<X509Certificate> issuerCerts = findIssuerCert(certificate);
		log.info("issuerCerts size >>> {}", issuerCerts.size());
		
		// 把 certificate 檔案與 Authority CA Issuers certificates 組合成一個 List
		List<X509Certificate> useCerts = new ArrayList<>();
		useCerts.add(certificate);
		useCerts.addAll(issuerCerts);
		
		Validator validator = ValidatorBuilder.newInstance()
				.addRule(new ExpirationRule())
				.addRule(new OCSPRule(new SimpleCertificateBucket(useCerts.toArray(new X509Certificate[] {}))))
				.build();
		
		try {
			validator.validate(certificate);
		}catch(Exception ex) {
			log.error("happened error {}", ex.getMessage(), ex);
		}
		
		Boolean isValid = validator.isValid(certificate);
		log.info("OCSP validate reuslt >>> {}", isValid);
		return isValid;
	}
	
	/**
	 * 從 certificate 中取得 Authority Information Access 中 CA Issuers
	 * 並從該 URL 取得 issuer certificate list. 
	 * @param cert
	 * @return
	 * @throws IOException
	 * @throws CertificateException
	 */
	private static List<X509Certificate> findIssuerCert(X509Certificate cert) throws IOException, CertificateException {
		List<X509Certificate> issuerCerts = new ArrayList<>();
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		
		// get Authority Information Access extension (will be null if extension is not present)
		byte[] extVal = cert.getExtensionValue(Extension.authorityInfoAccess.getId());
		AuthorityInformationAccess aia = AuthorityInformationAccess
				.getInstance(X509ExtensionUtil.fromExtensionValue(extVal));
		
		// check if there is a URL to issuer's certificate
		AccessDescription[] descriptions = aia.getAccessDescriptions();
		for (AccessDescription ad : descriptions) {
			// check if it's a URL to issuer's certificate
			if (ad.getAccessMethod().equals(X509ObjectIdentifiers.id_ad_caIssuers)) {
				GeneralName location = ad.getAccessLocation();
				if (location.getTagNo() == GeneralName.uniformResourceIdentifier) {
					String issuerUrl = location.getName().toString();
					// http URL to issuer (test in your browser to see if it's a valid certificate)
					// you can use java.net.URL.openStream() to create a InputStream and create
					// the certificate with your CertificateFactory
					log.info("issuer url >>> {}", issuerUrl);
					URL url = new URL(issuerUrl);
					InputStream in = new ByteArrayInputStream(IOUtils.toByteArray(url));
					
					Iterator<? extends Certificate> it = certFactory.generateCertificates(in).iterator();
					while(it.hasNext()) {
						Certificate cItem = (Certificate) it.next();
						InputStream cin = new ByteArrayInputStream(cItem.getEncoded());
						X509Certificate newCert = (X509Certificate) certFactory.generateCertificate(cin);
						log.info("newCert.subject >>> {}", newCert.getSubjectX500Principal());
						issuerCerts.add(newCert);
					}
				}
			}
		}
		
		return issuerCerts;
	}
	
	/**
	 * 使用 CRL 方式向 CA 驗證憑證是否有效.
	 * 最後是使用 {@link X509CRL} 來進行驗證.
	 * @throws Exception
	 */
	public static boolean runCRL() throws Exception {		
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		byte[] byteInFile = FileUtils.readFileToByteArray(certFile);
		InputStream in = new ByteArrayInputStream(byteInFile);
		
		X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(in);
		log.info("read certificate file >>> {}", certificate);
		
		Validator validator = ValidatorBuilder.newInstance()
				.addRule(new ExpirationRule())
				.addRule(new CRLRule())
				.build();
		
		Boolean isValid = validator.isValid(certificate);
		log.info("CRL validate reuslt >>> {}", isValid);
		
		return isValid;
	}
	
	public static X509Certificate toX509Certificate(File file) throws CertificateException, IOException {
		CertificateFactory certFactory = CertificateFactory.getInstance("X.509");
		byte[] byteInFile = FileUtils.readFileToByteArray(file);
		InputStream in = new ByteArrayInputStream(byteInFile);
		X509Certificate certificate = (X509Certificate) certFactory.generateCertificate(in);
		return certificate;
	}
}

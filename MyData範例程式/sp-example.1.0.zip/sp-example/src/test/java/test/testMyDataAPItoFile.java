package test;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.Key;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;

public class testMyDataAPItoFile {
	/**
	 * 密鑰算法
	 */
	public static final String KEY_ALGORITHM = "AES";
	/**
	 * 加密/解密算法/工作模式/填充方式
	 */
	public static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5PADDING";
	/**
	 * 測試機sp-example服務，cbc_iv CBC壓密向量值
	 */
	public static final String cbc_iv = "cFJ0feEe4icTRx9P";
	
	/**
	 * 1. mydata-api.json 為一個測試用的 jwt 內容 
	 * 	  參考： 玖、MyData-API Endpoint規格說明 三、MyData-API的回傳格式與加簽機制說明 （一）JWT格式說明
	 * 
	 * 2. 驗證頗析JWT內容
	 * 
	 * 3. 驗證回傳data存成檔案
	 * 
	 * 4. 驗證檔案AES/CBC/PKCS5PADDING解密
	 */
	public static void main(String[] args) throws Exception {
		//String secret_key = "0471f681fa334dba87c0d47fccd76a47";
		String secret_key = "9218b713e48d4549ae140e7a582c5479";
		String jwtjsonstr = readFileAsString("/Users/mac/Desktop/Eclipse_Work/workspace_oxygen/mydata_examples/sp-example/doc/mydata-api-jwt");
		String[] jwtjsonstrList = jwtjsonstr.split("[.]");
		/**
		 * 回傳JWT必為三段
		 */
		System.out.println("==jwtjsonstrList.length==:"+jwtjsonstrList.length);
		String unsigntoken = jwtjsonstrList[0]+"."+jwtjsonstrList[1];
		String jwtsignature = jwtjsonstrList[2];
		JSONObject payloadObj = null;
		String filename = null;
		String date = null;
		System.out.println("==0==\n"+jwtjsonstrList[0]);
		System.out.println("==1==\n"+jwtjsonstrList[1]);
		try {
			String payloadStrDecode = new String(Base64.getUrlDecoder().decode(jwtjsonstrList[1]),"UTF-8");
			System.out.println("==1-1==\n"+payloadStrDecode);
			payloadObj = (JSONObject) JSONValue.parseWithException(payloadStrDecode);
		} catch (ParseException | UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if(payloadObj!=null) {
			filename = payloadObj.get("filename").toString();
			date = payloadObj.get("data").toString();
			System.out.println("==filename==:"+date);
			System.out.println("==date==:"+date);
		}
		if(filename!=null&&date!=null) {
			/**
			 * 去檔頭
			 */
			date = date.replaceFirst("application/zip;data:", "");
			/**
			 * 下載檔案
			 */
			byte[] encryptb = Base64.getUrlDecoder().decode(date);
			FileUtils.writeByteArrayToFile(new File("/Users/mac/Desktop/mydata-example/"+filename), encryptb);
			/**
			 * 去壓密 AES
			 */
			byte[] decryptb = decrypt(encryptb,secret_key, cbc_iv);
			FileUtils.writeByteArrayToFile(new File("/Users/mac/Desktop/mydata-example/decrypt."+filename), decryptb);
		}
		
	}
	
	/**
	 * 讀取文字檔
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public static String readFileAsString(String fileName) throws Exception {
		String data = "";
		data = new String(Files.readAllBytes(Paths.get(fileName)));
		return data;
	}
	
	/**
	* 轉換密鑰
	* @param key 二進制密鑰
	* @return Key 密鑰
	*/
	public static Key toKey(String key) throws Exception {
		// decode the base64 encoded string
		byte[] decodedKey = Base64.getDecoder().decode(key);
		// rebuild key using SecretKeySpec
		SecretKey originalKey = new SecretKeySpec(decodedKey, 0, decodedKey.length, KEY_ALGORITHM);
		return originalKey;
	}
	
	/**
	* 加密數據
	* @param data 待加密數據
	* @param key 密鑰
	* @return byte[] 加密後的數據
	*/
	public static byte[] encrypt(byte[] data, String key, String iv) throws Exception {
		// 還原密鑰
		Key k = toKey(key);
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		//cbc iv
		IvParameterSpec cbciv = new IvParameterSpec(iv.getBytes("UTF-8"));
		// 初始化，設置為加密模式
		cipher.init(Cipher.ENCRYPT_MODE, k, cbciv);
		// 執行操作
		return cipher.doFinal(data);
	}
	
	/**
	* 解密數據
	* @param data 待解密數據
	* @param key 密鑰
	* @return byte[] 解密後的數據
	*/
	public static byte[] decrypt(byte[] data, String key, String iv) throws Exception {
		// 歡迎密鑰
		Key k = toKey(key);
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		//cbc iv
		IvParameterSpec cbciv = new IvParameterSpec(iv.getBytes("UTF-8"));
		// 初始化，設置為解密模式
		cipher.init(Cipher.DECRYPT_MODE, k, cbciv);
		// 執行操作
		return cipher.doFinal(data);
	}	
	
}

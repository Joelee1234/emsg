package tw.gov.ndc.emsg.mydata.web;

import java.io.IOException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;


/**
 * SP-API 實作
 * 捌、SP-API Endpoint規格說明
 *
 */
@Controller
@RequestMapping("/notification")
public class SpNotificationController {
	private static final Logger logger = LoggerFactory.getLogger(SpNotificationController.class);
	
	/**
	 * SP-API
	 * 捌、SP-API Endpoint規格說明（一）MyData發出請求 - 告知SP準備來捉取資料檔
	 * Content-Type: application/json
	 * 
	 * @param params permission_ticket - String 
	 * @param params secret_key - String
	 * @param params unable_to_deliver - ArrayList 
	 * 
	 * 成功 HTTP/1.1 200 OK 
	 * 失敗 HTTP/1.1 403 Forbidden 
	 */
	@PostMapping
	public void post(
			@RequestBody Map<String,Object> params,
			ModelMap model,
			HttpServletRequest request,
			HttpServletResponse response) {
		
		Object permission_ticket = params.get("permission_ticket");
		Object secret_key = params.get("secret_key");
		Object unable_to_deliver = params.get("unable_to_deliver");
		
		System.out.println(permission_ticket);
		System.out.println(secret_key);
		System.out.println(unable_to_deliver);
		
		/**
		 * SP需自行紀錄，以待驗證用
		 * 1. permission_ticket
		 * 2. secret_key
		 * 3. unable_to_deliver
		 */
		
		/**
		 * 服務狀態回復
		 * 正常 200
		 * 錯誤 403
		 */
		boolean check = true;
		
		if(check) {
			response.setStatus(HttpServletResponse.SC_OK);
		}else {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
		}
	}
}

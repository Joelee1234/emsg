package tw.gov.ndc.emsg.mydata.web;

import java.io.UnsupportedEncodingException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ndc.common.sysinit.SessionRecord;
import tw.gov.ndc.emsg.mydata.config.Breadcrumb;

@Controller
@RequestMapping("/")
public class HomeController {
	private static Logger logger = LoggerFactory.getLogger(HomeController.class);
	private DecimalFormat df = new DecimalFormat("##0.0");
	
	//資料資源檔根目錄
	@Value("${res.rootDir}")
	private String resourceRootDir;
	
	private String userHome = System.getProperty("user.home");
	private SimpleDateFormat df1 = new SimpleDateFormat("yyyy");
	private SimpleDateFormat df2 = new SimpleDateFormat("MM");
	
	@Value("${app.frontend.context.url}")
	private String frontendContextUrl;
	/**
	 * https://login.cp.gov.tw/v1/connect/authorize
	 */
	@Value("${app.oidc.authorize.uri}")
	private String authorizeUri;
	
	@Value("${gsp.oidc.client.id}")
	private String clientId;	
	@Value("${app.oidc.redirect.uri}")
	private String redirectUri;	
	
	@Value("${app.oidc.response.type}")
	private String responseType;
	@Value("${app.oidc.response.mode}")
	private String responseMode;	
		
	
	private List<Breadcrumb> breadcrumbs = new ArrayList<Breadcrumb>();	
	
	/**
	 * 進入首頁
	 */
	@GetMapping
	public String homePage(
			ModelMap model,HttpServletRequest request,HttpSession session) {
		logger.debug("進入首頁");
		logger.debug("跳轉服務說明頁");
		return "redirect:/sp/service_description";
	}
}

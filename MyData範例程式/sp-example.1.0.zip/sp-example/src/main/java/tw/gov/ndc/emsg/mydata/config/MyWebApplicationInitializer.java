/**
 * 
 */
package tw.gov.ndc.emsg.mydata.config;

import java.util.EnumSet;

import javax.servlet.DispatcherType;
import javax.servlet.ServletContext;
import javax.servlet.ServletRegistration;
import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.filter.HiddenHttpMethodFilter;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * WebApplication初始動作，整合spring-security。
 * @author wesleyzhuang
 *
 */
public class MyWebApplicationInitializer extends AbstractSecurityWebApplicationInitializer {

	public MyWebApplicationInitializer() {
		//宣告初始設定檔
		super(AppConfig.class);
	}
	
	/**
	 * 實作初始spring-security filter chain之前的動作。
	 * @see org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer#beforeSpringSecurityFilterChain(javax.servlet.ServletContext)
	 */
	@Override
	protected void beforeSpringSecurityFilterChain(ServletContext servletContext) {
		super.beforeSpringSecurityFilterChain(servletContext);
		
		//字元編碼轉換
		final CharacterEncodingFilter encodingFilter = new CharacterEncodingFilter();
        encodingFilter.setEncoding("UTF-8");
        encodingFilter.setForceEncoding(true);
        servletContext.addFilter("characterEncodingFilter", encodingFilter)
        				.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), false, "/*");
		
		//浏览器form表单只支持GET与POST请求，而DELETE、PUT等method并不支持，spring3.0添加了一个过滤器，可以将这些请求转换为标准的http方法，使得支持GET、POST、PUT与DELETE请求，该过滤器为HiddenHttpMethodFilter。
		final HiddenHttpMethodFilter methodFilter = new HiddenHttpMethodFilter();
        servletContext.addFilter("hiddenHttpMethodFilter", methodFilter)
						.addMappingForUrlPatterns(EnumSet.of(DispatcherType.REQUEST), true, "/rest/*");
		
		
	}

	/**
	 * 實作初始spring-security filter chain之後的動作。
	 * @see org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer#afterSpringSecurityFilterChain(javax.servlet.ServletContext)
	 */
	@Override
	protected void afterSpringSecurityFilterChain(ServletContext servletContext) {
		super.afterSpringSecurityFilterChain(servletContext);
		/*
		 * SpringMVC DispatchServlet 
		 */
		AnnotationConfigWebApplicationContext dispatcherContext = 
				new AnnotationConfigWebApplicationContext();
		ServletRegistration.Dynamic dispatcher =
				servletContext.addServlet("springmvc-dispatcher", new DispatcherServlet(dispatcherContext));
			    dispatcher.setLoadOnStartup(1);
			    /*
			     * 此處的url-pattern必需使用格式如 / 或 /xxx/* 。
			     * 若使用後者，請求的完整網址必需是此處宣告的url-pattern + RequestMapping中定義的path，才會成功對應到。
			     */
			    dispatcher.addMapping("/");
			    
	}
	
	
}

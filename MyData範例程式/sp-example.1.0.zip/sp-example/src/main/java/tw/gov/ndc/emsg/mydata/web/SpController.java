package tw.gov.ndc.emsg.mydata.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import org.apache.http.Header;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ndc.common.helper.HttpClientHelper;
import com.ndc.common.helper.ZipUtil;

import tw.gov.ndc.emsg.mydata.util.DESedeCoder;
import tw.gov.ndc.emsg.mydata.util.RSAUtil;

@Controller
@RequestMapping("/sp")
public class SpController {
	private static final Logger logger = LoggerFactory.getLogger(SpController.class);
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	private final Base64.Encoder encoder = Base64.getEncoder();
	
	
	/**
	 * SP服務說明頁 [流程示意圖]
	 * 
	 * 柒、MyData整合方式說明 二、MyData整合網址及參數說明
	 * 
	 * 欲進入「服務申請頁」，/service/{client_id}/{服務篩選參數}
	 */
	@GetMapping("/service_description")
	public String getSpChBookDesc(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		HttpSession session = request.getSession();
		/**
		 * 測試服務 client_id = CLI.klmZFqH5SQ
		 * 測試資料集 resource_id 
		 * API.UZQkKbsOpz 勞工保險被保險人投保資料
		 * API.zH584wn59r 個人投退保資料（健保）
		 * 
		 * 欲進入「服務申請頁」，/service/{client_id}/{服務篩選參數}
		 * https://mydata.nat.gov.tw/API.UZQkKbsOpz/{服務篩選參數}
		 * 
		 * 成功或失敗跳回 SP指定之服務跳轉網址[流程示意圖] sp_return_url
		 * 
		 */
		
		/**
		 * 第一段，測試多組資料集
		 */
		String param1 = "API.UZQkKbsOpz:API.zH584wn59r";		
		String applyurl1 = null;
		String sp_return_url = "http://localhost:8080/sp-example/sp/service_apply";
		try {
			applyurl1 = "https://mydatadev.nat.gov.tw/mydata/service/test/CLI.klmZFqH5SQ/"+Base64.getUrlEncoder().encodeToString(param1.getBytes("UTF-8"))+"?returnUrl="+URLEncoder.encode(sp_return_url);
			/**
			 * Base64.getUrlEncoder() 和 Base64.getEncoder()結果一樣，統一用 Base64.getUrlEncoder()
			 */
			String encodeStr = Base64.getUrlEncoder().encodeToString(param1.getBytes("UTF-8"));
			System.out.println("encodeStr:"+encodeStr);
			String decodeStr = new String( Base64.getUrlDecoder().decode(encodeStr),"UTF-8");
			System.out.println("decodeStr:"+decodeStr);
			
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		/**
		 * 第二段，測試單組資料集(可選性)
		 */
		String param2 = "API.zH584wn59r";
		String applyurl2 = null;
		try {
			applyurl2 = "https://mydatadev.nat.gov.tw/mydata/service/test/CLI.klmZFqH5SQ/"+Base64.getUrlEncoder().encodeToString(param2.getBytes("UTF-8"))+"?returnUrl="+URLEncoder.encode(sp_return_url);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		model.addAttribute("applyurl1", applyurl1);
		model.addAttribute("applyurl2", applyurl2);
		return "service_description";
	}

	/**
	 * SP指定之服務跳轉網址[流程示意圖] sp_return_url
	 * 
	 * 柒、MyData整合方式說明 三、正常返回SP網址之處理方式說明 四、異常返回SP網址之處理方式說明
	 * 
	 * 正常時，傳送 permission_ticket
	 * 錯誤時，傳送 code
	 * 原有sp_return_url的參數會全數帶回方便使用
	 * 
	 */
	@GetMapping("/service_apply")
	public String getServiceapply(
			@RequestParam(name="code",required=false) String code,
			@RequestParam(name="permission_ticket",required=false) String permission_ticket,
			HttpServletRequest request, 
			HttpServletResponse response, ModelMap model) {
		/**
		 * 此處根據SP使用需求可自行填寫邏輯
		 */
		System.out.println("code="+code);
		model.addAttribute("code", code);
		
		System.out.println("permission_ticket="+permission_ticket);
		model.addAttribute("permission_ticket", permission_ticket);
		
		System.out.println("request.getQueryString()="+request.getQueryString());
		model.addAttribute("querystr", request.getQueryString());
		return "service_apply";
	}
}

package tw.gov.ndc.emsg.mydata.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import tw.gov.ndc.emsg.mydata.util.SpUtils;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.text.SimpleDateFormat;
import java.util.Base64;

@Controller
@RequestMapping("/sp")
public class SpController {

    private static final Logger logger = LoggerFactory.getLogger(SpController.class);
    private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    private final Base64.Encoder encoder = Base64.getEncoder();


    @Value("${mydata.url}")
    private String mydataHost;       // MyData主機網址
    @Value("${sp.client_id}")
    private String spClientId;      // SP client_id
    @Value("${sp.returnUrl}")
    private String spReturnUrl;     // SP return url
    @Value("${dp.resource_id}")
    private String dpResourceId;    // DP resource_id


    /**
     * SP服務說明頁 [流程示意圖]
     * <p>
     * 柒、MyData整合方式說明 二、MyData整合網址及參數說明
     * <p>
     * 欲進入「服務申請頁」，/service/{client_id}/{服務篩選參數}
     */
    @GetMapping("/service_description")
    public String getSpChBookDesc(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
        HttpSession session = request.getSession();

        // SP協助工具
        SpUtils utils = new SpUtils();
        // SP所綁定的 resourceId。
        String[] resourceIdArray = dpResourceId.split(",");

        // 重導向至MyData的整合介接網址
        String spIntergrationUrl = utils.getSpIntergrationUrlString(
                mydataHost, spClientId, resourceIdArray, spReturnUrl);

        model.addAttribute("spIntergrationUrl", spIntergrationUrl);

        return "service_description";
    }

    /**
     * SP指定之服務跳轉網址[流程示意圖] sp_return_url
     * <p>
     * 柒、MyData整合方式說明 三、正常返回SP網址之處理方式說明 四、異常返回SP網址之處理方式說明
     * <p>
     * 正常時，傳送 permission_ticket
     * 錯誤時，傳送 code
     * 原有sp_return_url的參數會全數帶回方便使用
     */
    @GetMapping("/service_apply")
    public String getServiceapply(
    			@RequestParam(name = "tx_id", required = false) String tx_id,
            @RequestHeader(name = "code", required = false) String code,
            HttpServletRequest request,
            HttpServletResponse response,
            ModelMap model) {
        /**
         * 此處根據SP使用需求可自行填寫邏輯
         */
        System.out.println("code=" + code);
        model.addAttribute("code", code);

        System.out.println("tx_id=" + tx_id);
        model.addAttribute("tx_id", tx_id);

        System.out.println("request.getQueryString()=" + request.getQueryString());
        model.addAttribute("querystr", request.getQueryString());
        return "service_apply";
    }
}

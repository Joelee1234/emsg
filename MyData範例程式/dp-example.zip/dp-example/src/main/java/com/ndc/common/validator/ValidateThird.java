/**
 * 
 */
package com.ndc.common.validator;

/**
 * 第三順位進行驗證
 * @author wesleyzhuang
 *
 */
public interface ValidateThird {

}

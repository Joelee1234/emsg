/**
 * 
 */
package com.ndc.common.validator;

/**
 * 驗證PrimaryKey
 * @author wesleyzhuang
 *
 */
public interface ValidatePK {

}

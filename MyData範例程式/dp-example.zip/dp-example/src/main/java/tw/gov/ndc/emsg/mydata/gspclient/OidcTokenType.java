/**
 * 
 */
package tw.gov.ndc.emsg.mydata.gspclient;

/**
 * OpenID Connect, Token 類別
 * @author wesleyzhuang
 *
 */
public enum OidcTokenType {

	access_token,
	refresh_token
	;
}

package test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.Node;

import com.google.common.hash.Hashing;

public class testDpZipManifest {

	public static void main(String[] args) throws IOException {
		
		/**
		 * 產生SHA-256 digest
		 */
		String jsonPathStr = "/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/person.json";
		byte[] b = Files.readAllBytes(Paths.get(jsonPathStr));
		String  sha256jsonStr = Hashing.sha256().hashBytes(b).toString();
		System.out.println("SHA256-json file：" + sha256jsonStr);
		
		String pdfPathStr = "/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/person.pdf";
		b = Files.readAllBytes(Paths.get(pdfPathStr));
		String  sha256pdfStr = Hashing.sha256().hashBytes(b).toString();
		System.out.println("SHA256-pdf file：" + Hashing.sha256().hashBytes(b).toString());

		
		
		/**
		 * 產生manifest.xml檔案
		 */
		String manifestPathStr = "/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/manifest.xml";
		Document doc = DocumentHelper.createDocument();
		Element root = doc.addElement("files");
		Element f1 = root.addElement("file");
		Element f1filename = f1.addElement("filename");
		Element f1digest = f1.addElement("digest");
		f1filename.setText("person.json");
		f1digest.setText("409508689cfa527d177ecb36da1dc198f71bea4245a85028dd6ad0636a9289ee");
		
		Element f2 = root.addElement("file");
		Element f2filename = f2.addElement("filename");
		Element f2digest = f2.addElement("digest");
		f2filename.setText("person.pdf");
		f2digest.setText("2437efe4ab23d58a136e4ac109f3c429366340d6dfcbebb2532ec0ef7bf464a3");
		
		String outXml = doc.asXML();
		System.out.print(doc.asXML());
		FileUtils.writeStringToFile(new File(manifestPathStr), outXml,"UTF-8");
		
		
	}

}

package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import org.apache.commons.io.FileUtils;

public class testSha256WithRSA {

	public final static String ALGORITHM = "RSA";
	public final static String SIGNATURE_ALGORITHM = "MD5withRSA";
	
	public static void main(String[] args) throws Exception {
		/**
		 * Java Key Store 憑證庫
		 */
		String jksPath = "/Users/mac/mydata.jks"; // jks file path
		/**
		 * 憑證庫密碼
		 */
		String jksPassword = "xxxxxxxxxxxxx"; // jks keyStore password
		/**
		 * 憑證別名
		 */
		String certAlias = "mydata.nat.gov.tw";
		/**
		 * 憑證密碼
		 */
		String certPassword = "xxxxxxxxxxxxx"; // cert password
		KeyStore keyStore = KeyStore.getInstance("JKS");
		keyStore.load(new FileInputStream(jksPath), jksPassword.toCharArray());
		PrivateKey privateKey = (PrivateKey) keyStore.getKey(certAlias, certPassword.toCharArray());
		System.out.println("私鑰：" + Base64.getEncoder().encodeToString(privateKey.getEncoded()));
		String signAlg = "SHA256withRSA"; // 簽名類型
		byte[] b = Files.readAllBytes(Paths.get("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/manifest.xml"));
		Signature signature = Signature.getInstance(signAlg);
		signature.initSign(privateKey);
		signature.update(b);
		String signedData = Base64.getEncoder().encodeToString(signature.sign()).replace("\r\n", "").replace("\n", "");
		System.out.println("簽名     ：" + signedData);
		String manifestPathStr = "/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/signature.sha256withrsa";
		FileUtils.writeStringToFile(new File(manifestPathStr), signedData,"UTF-8");
		
		/**
		 * PEM憑證公鑰驗簽
		 */
		signature.initVerify(getCAPublicKey());
		signature.update(b);
		boolean isVerify = signature.verify(Base64.getDecoder().decode(signedData));
		System.out.println("CA驗簽：" + isVerify);
	}

	/**
	 * 憑證取的公鑰
	 * @return
	 * @throws Exception
	 */
	private static PublicKey getCAPublicKey() throws Exception {
		String keyStr = "";
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(new FileInputStream("/Users/mac/mydatanatgovtw.crt"));
			keyStr = Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded());
			// System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(keyStr));
		KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
		PublicKey k = keyFactory.generatePublic(keySpec);
		return k;
	}
}

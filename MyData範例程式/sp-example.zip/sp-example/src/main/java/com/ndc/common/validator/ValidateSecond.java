/**
 * 
 */
package com.ndc.common.validator;

/**
 * 第二順位進行驗證
 * @author wesleyzhuang
 *
 */
public interface ValidateSecond {

}

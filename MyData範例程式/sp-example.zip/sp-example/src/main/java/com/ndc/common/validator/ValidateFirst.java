/**
 * 
 */
package com.ndc.common.validator;

/**
 * 第一順位進行驗證
 * @author wesleyzhuang
 *
 */
public interface ValidateFirst {

}

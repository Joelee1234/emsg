package test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.google.common.hash.Hashing;

import org.dom4j.Attribute;
import org.dom4j.Document;

public class testDpData {

	/**
	 * 使用 /src/test/java/test/testMyDataAPItoFile.java 解密後的檔案內容
	 *
	 * /Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INFO
	 */
	
	private static Element root;
    private static List<String> name = new ArrayList<String>();
    private static Document document;
    
	public static void main(String[] args) throws IOException {
		/**
		 * XML處理 dom4j
		 */


//		String manifestPathStr = "/Users/mac/Desktop/mydata-example/tmp/inqNPBf/META-INFO/manifest.xml";
		//String manifestPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/META-INFO/manifest.xml";
		String manifestPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.WE8hJHljiN/META-INFO/manifest.xml";
		File manifestfile = new File(manifestPathStr); 
		Map<String,String> hashmap = new HashMap<String,String>();
		try { 
			SAXReader reader = new SAXReader();
			Document doc = reader.read(manifestfile); 
			root = doc.getRootElement(); 
			List<Element> childElements = root.elements();
			for (Element child : childElements) {
				hashmap.put(child.elementText("filename"), child.elementText("digest"));
	            System.out.println("filename=\n" + child.elementText("filename"));
	            System.out.println("digest=\n" + child.elementText("digest"));
			}
		}catch(Exception ex) {
			ex.printStackTrace(); 
		}
		
		/**
		 * SHA-256驗證
		 */
		//String pdfPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/307500000D_1081014_000002_5520_OLDEGXN00101.zip";
//		String pdfPathStr = "/Users/mac/Desktop/mydata-example/tmp/inqNPBf/inqNPBf.pdf";
//		String jsonPathStr = "/Users/mac/Desktop/mydata-example/tmp/inqNPBf/inqNPBf.json";
		String pdfPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.WE8hJHljiN/MyLandData1.json";
		String jsonPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.WE8hJHljiN/MyLandData1.json";
		byte[] b = Files.readAllBytes(Paths.get(pdfPathStr));
		byte[] bs = Files.readAllBytes(Paths.get(jsonPathStr));
		String  sha256file = Hashing.sha256().hashBytes(b).toString();
		String  sha256filebs = Hashing.sha256().hashBytes(bs).toString();
		System.out.println("SHA256-0 file：\n" + Hashing.sha256().hashBytes(b).toString());
		System.out.println("SHA256-1 file：\n" + Hashing.sha256().hashBytes(bs).toString());
		String  sha256manifest = hashmap.get("MyLandData1.json");
		if(sha256file.equalsIgnoreCase(sha256manifest)) {
			System.out.println("==SHA-256 0==:"+true);
		}else {
			System.out.println("==SHA-256 0==:"+false);
		}
		String  sha256manifestbs = hashmap.get("MyLandData1.json");
		if(sha256filebs.equalsIgnoreCase(sha256manifestbs)) {
			System.out.println("==SHA-256 1==:"+true);
		}else {
			System.out.println("==SHA-256 1==:"+false);
		}
	}

	private static String bytesToHex(byte[] hash) {
		StringBuffer hexString = new StringBuffer();
		for (int i = 0; i < hash.length; i++) {
			String hex = Integer.toHexString(0xff & hash[i]);
			if (hex.length() == 1)
				hexString.append('0');
			hexString.append(hex);
		}
		return hexString.toString();
	}
}

package test;

import java.io.FileInputStream;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import javax.crypto.Cipher;

public class testCBCPublicKeyRSAData {
	//公鑰
	private static String keystorePublicCrypto="/Users/mac/Desktop/mydata-example/tmp/ctcb_publickey_mydata_prod.cer";
	
	public final static String ALGORITHM = "RSA";
	
	public static void main(String[] args) {
		String secretData = "P6WIc8eooPWzkh9I";
        /* 公鑰加密 私鑰解密 */
		try {
			Cipher cipher = Cipher.getInstance("RSA"); //NoSuchPaddingException
			cipher.init(Cipher.ENCRYPT_MODE,getCAPublicKey()); //InvalidKeyException
			byte[] b = cipher.doFinal(secretData.getBytes()); //BadPaddingException
			String benstr = Base64.getEncoder().encodeToString(b);
			System.out.println(benstr);
	        	
			//cipher.init(Cipher.DECRYPT_MODE,rsaPrivateKey);
			//b = cipher.doFinal(b);
			//System.out.println(new String(b));
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	private static PublicKey getCAPublicKey() throws Exception {
		String keyStr = "";
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(new FileInputStream(keystorePublicCrypto));
			keyStr = Base64.getUrlEncoder().encodeToString(cert.getPublicKey().getEncoded());
			// System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getUrlDecoder().decode(keyStr));
		KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
		PublicKey k = keyFactory.generatePublic(keySpec);
		return k;
	}
}

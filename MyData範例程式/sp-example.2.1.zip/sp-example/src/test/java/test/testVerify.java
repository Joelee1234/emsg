package test;

import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.Arrays;

import org.apache.commons.io.FilenameUtils;
import tw.gov.ndc.emsg.mydata.util.SpUtils;

public class testVerify {

	public static void main(String[] args) {
		
		SpUtils utils = new SpUtils();
		// 解壓縮 MyData 打包檔
//		File packDir = new File("/Users/mac/Desktop/mydata-example/tmp/inqNPBf");
		File packDir = new File("/Users/zhanqianjin/Downloads/個人投退保資料20200331134131");

//		try {
//
//			File targetFile = new File(packDir + "/" + packDir.getName());
//			if(!targetFile.exists()){
//				targetFile.mkdir();
//			}
//			utils.unzip(packDir,targetFile);
//		} catch (IOException e) {
//			e.printStackTrace();
//		}


//		String fileName = FilenameUtils.removeExtension(packDir.getName());
//		File targetFile = new File(packDir.getParent() + "/" +fileName + "/" );
//		System.out.println("target path -> " + targetFile.getAbsolutePath());
//		if (!targetFile.exists()) {
//			targetFile.mkdir();
//		}
//
//		try {
//			File[] fs = targetFile.listFiles((dir, name) -> !name.equals(".DS_Store"));
//
//			if(fs.length < 1){
//				utils.unzip(packDir,targetFile);
//			}else {
//				for(File f : fs){
//					System.out.println("file name -> " + f.getName());
//				}
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}



//		/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ
//		File packDir = new File("/Users/mac/Desktop/mydata-example/decrypt.CLI.MaWMSTqB71/API.UZQkKbsOpz");
//		 MyData打包檔中的 manifest.xml

		File manifestFile = utils.manifestFileOfMyDataPackFile(packDir);
		// 解壓縮 DP打包檔
		File[] dpPackFiles = packDir.listFiles(pathname -> pathname.isFile() && pathname.getName().toLowerCase().endsWith("zip"));
		try {
			// TODO 驗證DP打包檔內的憑證檔及數位簽章。
			boolean verifyDpSignatur = utils.verifySignature(packDir);

			if(verifyDpSignatur) {
				System.out.println("DP打包檔數位簽章驗證成功");
			}else {
				System.out.println("DP打包檔數位簽章驗證失敗");
			}
		} catch (IOException | InvalidKeyException | CertificateException | SignatureException e) {
			e.printStackTrace();
		}
	}

}

package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.security.Key;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;
import java.util.Enumeration;

import javax.crypto.Cipher;

public class testRSAEncodeAndDecode {
	//私鑰
	private static String keystorePrivateCrypto="/Users/mac/Desktop/keylist/emsg_tester.pfx";
	//私鑰密碼
	private static String keystorePrivateCryptoPassword="12345678";
	//公鑰
	private static String keystorePublicCrypto="/Users/mac/Desktop/keylist/emsg_tester.cer";
	
    public final static String ALGORITHM = "RSA";
	public static void main(String[] args) {
		String secretData = "iwPsfEYqBtBfgUdT";
        /* 私鑰加密 公鑰解密 */
		try {
			Cipher cipher = Cipher.getInstance("RSA"); //NoSuchPaddingException
			cipher.init(Cipher.ENCRYPT_MODE,getPrivateKey()); //InvalidKeyException
			byte[] b = cipher.doFinal(secretData.getBytes()); //BadPaddingException
			String benstr = Base64.getEncoder().encodeToString(b);
			System.out.println(benstr);
	
			cipher.init(Cipher.DECRYPT_MODE, getCAPublicKey());
			b = cipher.doFinal(Base64.getDecoder().decode(benstr));
			System.out.println(new String(b));
		}catch (Exception e) {
			e.printStackTrace();
		}

	}

	private static PublicKey getCAPublicKey() throws Exception {
		String keyStr = "";
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(new FileInputStream(keystorePublicCrypto));
			keyStr = Base64.getUrlEncoder().encodeToString(cert.getPublicKey().getEncoded());
			// System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getUrlDecoder().decode(keyStr));
		KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
		PublicKey k = keyFactory.generatePublic(keySpec);
		return k;
	}
	
    private static Key getPrivateKey() throws Exception{
		File fPkcs12 = null;
		String keyStr = null;
		PrivateKey key = null;
		if (keystorePrivateCrypto != null) {
			// Open the file
			fPkcs12 = new File(keystorePrivateCrypto);
		}
		FileInputStream fis = new FileInputStream(fPkcs12);
		KeyStore keyStore = null;
		try {
			// Need BC provider for PKCS #12, BKS and UBER
			if (Security.getProvider("BC") == null) {
				throw new Exception(" 不能Load入BouncyCastle! ");
			}
			keyStore = KeyStore.getInstance("PKCS12");
		} catch (KeyStoreException ex) {
			throw new Exception(" 不能正确解释pfx文件! ");
		} catch (NoSuchProviderException ex) {
			throw new Exception(" Security Provider配置有误! ");
		}
		try {
			// Load the file into the keystore
			keyStore.load(fis, keystorePrivateCryptoPassword.toCharArray());
			Enumeration<String> alias = keyStore.aliases();
			String aliasTmp = null;
			while (alias.hasMoreElements()) {
				aliasTmp = (String) alias.nextElement();
				if (keyStore.isKeyEntry(aliasTmp)) {
					key = (PrivateKey) keyStore.getKey(aliasTmp, keystorePrivateCryptoPassword.toCharArray());
					String privateKeyStr = Base64.getEncoder().encodeToString(key.getEncoded());
					keyStr = privateKeyStr;
				}
			}
		} catch (CertificateException ex) {
			throw new Exception(" 證書格式問題! ");
		} catch (NoSuchAlgorithmException ex) {
			throw new Exception(" 算法不支持! ");
		} catch (FileNotFoundException ex) {
			throw new Exception(" pfx文件沒找到 ");
		} catch (IOException ex) {
			throw new Exception(" 讀取pfx有誤! \n"+ex);
		}
        PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(keyStr));
        KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
        Key k = keyFactory.generatePrivate(keySpec);
        return k;
    }   
	
}

package test;

import java.io.File;
import java.io.IOException;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FileUtils;

public class testDeAESCBCPADDING5 {
	/**
	 * 密鑰算法
	 */
	public static final String KEY_ALGORITHM = "AES";
	/**
	 * 加密/解密算法/工作模式/填充方式
	 */
	public static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5PADDING";
	/**
	 * 測試機sp-example服務，cbc_iv CBC壓密向量值
	 */
	public static final String cbc_iv = "7kueW3rqLm55IEmJ";
	public static void main(String[] args) throws Exception {
		String secret_key = "f78c69734f6549f99b205505d8b290eb";
		//加密檔
		File f1 = new File("/Users/zhanqianjin/Downloads/CLI.psb2UtkoTe.9a6a698ef19f435590d6a285836074ee_cbc.zip");
		//解密檔
		File f2 = new File("/Users/zhanqianjin/Downloads/CLI.psb2UtkoTe.9a6a698ef19f435590d6a285836074ee.zip");
		byte[] encryptedData = FileUtils.readFileToByteArray(f1);
		byte[] b = decrypt(encryptedData,secret_key,cbc_iv);
		FileUtils.writeByteArrayToFile(f2, b);
	}
	
	/**
	* 加密數據
	* @param data 待加密數據
	* @param key 密鑰
	* @return byte[] 加密後的數據
	*/
	public static byte[] encrypt(byte[] data, String key, String ivstr) throws Exception {
		// 密鑰
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"),"AES");
		// 向量鰎值
		IvParameterSpec iv = new IvParameterSpec(ivstr.getBytes("UTF-8"));
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		// 初始化，設置為加密模式
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
		// 執行操作
		return cipher.doFinal(data);
	}
	
	/**
	* 解密數據
	* @param data 待解密數據
	* @param key 密鑰
	* @return byte[] 解密後的數據
	*/
	public static byte[] decrypt(byte[] data, String key, String ivstr) throws Exception {
		// 密鑰
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"),"AES");
		// 向量鰎值
		IvParameterSpec iv = new IvParameterSpec(ivstr.getBytes("UTF-8"));
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
		// 初始化，設置為解密模式
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
		// 執行操作
		return cipher.doFinal(data);
	}
}

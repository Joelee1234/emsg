package test;

import com.google.common.hash.Hashing;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import tw.gov.ndc.emsg.mydata.util.SpUtils;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipFile;


/**
 * 解壓縮且合併驗證DpData和Verify
 */
public class testDpDataAndVerify {
    private static Logger logger = LoggerFactory.getLogger(testDpDataAndVerify.class);
    private static Element root;
    private static List<String> name = new ArrayList<String>();
    private static Document document;
    // 下載後壓縮檔存放路徑
    private static String dirPath = "/Users/chenjiawei/Downloads/";
    private static String dlDirName = "";
    // 壓縮檔名稱
    private static String dirName = "myland_lcd49BZd571090409134727";
    // 檔案名稱
    //private static String pdfName;
    //private static String jsonName; // p7b和json都可以使用
    
    // 檔案路徑
    //private static String pdfPath;
    //private static String jsonPath;
    
    private static Map<String, String> pdfMap = new HashMap<>();
    private static Map<String, String> jsonMap = new HashMap<>();

    private static File manifestFile = null;

    public static void main(String[] args) {

        unzipFile();
        testVerify();
        testDpData();

    }

    /**
     * 解壓縮檔案
     */
    private static void unzipFile() {
        SpUtils utils = new SpUtils();
        File packDir = new File(dirPath + dirName + ".zip");
        // 產生解壓縮目的地的File物件
        String resName = FilenameUtils.removeExtension(packDir.getName());
        File targetFile = new File(packDir.getParent() + "/" + resName + "/");
        try {
            if (packDir.exists()) {
                utils.unzip(packDir, targetFile);
            }
            // 去除掉mac系統的隱藏檔
            File[] fs = targetFile.listFiles((dir, name) -> !name.equals(".DS_Store"));
            if (fs.length < 1) {
                utils.unzip(packDir, targetFile);
            }
            targetFileDeconstruction(fs);


        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 解構targetFile資料夾
     */
    private static void targetFileDeconstruction(File[] targetFiles) {

        for (File f : targetFiles) {
            if (!f.isDirectory()) {
                // 需要解析的pdf, json(p7b)
                String extension = FilenameUtils.getExtension(f.getName());
                switch (extension) {
                    case "pdf":
//                        pdfName = f.getName();
                    	String pdfPath = f.getPath();
                        String pdfName = f.getName();
                    	pdfMap.put(pdfName, pdfPath);
                       
                        break;
                    case "csv":
                    case "p7b":
                    case "json":
                    	String jsonName = f.getName();
                    	String jsonPath = f.getPath();
                    	jsonMap.put(jsonName, jsonPath);
                        break;
//                        jsonName = f.getName();
                }
            } else {
                targetFileDeconstruction(f.listFiles());
            }
        }

    }

    private static void testVerify() {
        SpUtils utils = new SpUtils();
        File jsonFile = null, pdfFile = null;
        File packDir = null;
        
        for(String jsonName : jsonMap.keySet()) {
        	jsonFile = new File(jsonMap.get(jsonName)) ;
        	if(packDir == null && jsonFile!=null && jsonFile.exists()){
        		packDir = jsonFile.getParentFile();
        		break;
        	}
        }
        for(String pdfName : pdfMap.keySet()) {
        	pdfFile = new File(pdfMap.get(pdfName)) ;
        	if(packDir == null && pdfFile!=null && pdfFile.exists()){
        		packDir = pdfFile.getParentFile();
        	}
        }

        if(packDir == null){
            // 無json和pdf，數位簽章必定失敗
            System.out.println("DP打包檔數位簽章驗證失敗");
            return;
        }


        manifestFile = new File(packDir.getPath() + "/META-INFO/manifest.xml");

        try {
            boolean verifyDpSignatur = utils.verifySignature(packDir);
            if (verifyDpSignatur) {
                System.out.println("DP打包檔數位簽章驗證成功");
            } else {
                System.out.println("DP打包檔數位簽章驗證失敗");
            }
        } catch (IOException | InvalidKeyException | CertificateException | SignatureException e) {
            e.printStackTrace();
        }
    }


    private static void testDpData() {
        /**
         * XML處理 dom4j
         */

        // 組成manifest存放路徑
//        String dirMeta = "/META-INFO/manifest.xml";
//        String manifestPathStr = dirPath + dirName + dirMeta;
//        File manifestfile = new File(manifestPathStr);
        File manifestfile = manifestFile;
        Map<String, String> hashmap = new HashMap<String, String>();
        try {
            SAXReader reader = new SAXReader();
            Document doc = reader.read(manifestfile);
            root = doc.getRootElement();
            List<Element> childElements = root.elements();
            Integer idx = new Integer(0);
            for (Element child : childElements) {
            	idx++;
                hashmap.put(child.elementText("filename"), child.elementText("digest"));
                System.out.println("[" + idx + "] filename= " + child.elementText("filename"));
                System.out.println("[" + idx + "] digest= " + child.elementText("digest"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        
        System.out.println(StringUtils.rightPad("", 20, "=="));
        /**
         * SHA-256驗證
         */

        try {
        	Integer idx = new Integer(0);
        	for(String pdfName : pdfMap.keySet()) {
        		String pdfPathStr = pdfMap.get(pdfName) ;
            	if (StringUtils.isNotEmpty(pdfName)) {
            		idx++;
            		byte[] b = Files.readAllBytes(Paths.get(pdfPathStr));
            		String sha256file = Hashing.sha256().hashBytes(b).toString();
            		System.out.println("[" + idx + "] SHA256-PDF file：" + Hashing.sha256().hashBytes(b).toString());
            		String sha256manifest = hashmap.get(pdfName);
            		if (sha256file.equalsIgnoreCase(sha256manifest)) {
            			System.out.println("[" + idx + "] ==SHA-256 PDF==：" + true);
            		} else {
            			System.out.println("[" + idx + "] ==SHA-256 PDF==：" + false);
            		}
            	}
            }
           
            // 有些資料集沒有json
        	for(String jsonName : jsonMap.keySet()) {
        		String jsonPathStr = jsonMap.get(jsonName) ;
	            if (StringUtils.isNotEmpty(jsonName)) {
	            	idx++;
	                byte[] bs = Files.readAllBytes(Paths.get(jsonPathStr));
	                String sha256filebs = Hashing.sha256().hashBytes(bs).toString();
	                System.out.println("[" + idx + "] SHA256-JSON file：" + Hashing.sha256().hashBytes(bs).toString());
	                String sha256manifestbs = hashmap.get(jsonName);
	                if (sha256filebs.equalsIgnoreCase(sha256manifestbs)) {
	                    System.out.println("[" + idx + "] ==SHA-256 JSON==：" + true);
	                } else {
	                    System.out.println("[" + idx + "] ==SHA-256 JSON==：" + false);
	                }
	            }
        	}


//            byte[] b = Files.readAllBytes(Paths.get(pdfPathStr));
//            byte[] bs = Files.readAllBytes(Paths.get(jsonPathStr));
//            String sha256file = Hashing.sha256().hashBytes(b).toString();
//            String sha256filebs = Hashing.sha256().hashBytes(bs).toString();
//            System.out.println("SHA256-0 file：\n" + Hashing.sha256().hashBytes(b).toString());
//            System.out.println("SHA256-1 file：\n" + Hashing.sha256().hashBytes(bs).toString());
//            String sha256manifest = hashmap.get(pdfName);
//            if (sha256file.equalsIgnoreCase(sha256manifest)) {
//                System.out.println("==SHA-256 0==:" + true);
//            } else {
//                System.out.println("==SHA-256 0==:" + false);
//            }
//            String sha256manifestbs = hashmap.get(jsonName);
//            if (sha256filebs.equalsIgnoreCase(sha256manifestbs)) {
//                System.out.println("==SHA-256 1==:" + true);
//            } else {
//                System.out.println("==SHA-256 1==:" + false);
//            }


        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

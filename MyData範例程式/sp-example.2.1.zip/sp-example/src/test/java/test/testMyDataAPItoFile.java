package test;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.Key;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.keys.AesKey;

import com.fasterxml.jackson.databind.ObjectMapper;

public class testMyDataAPItoFile {
	
	/**
	 * 1. mydata-api-jwe 為一個測試用的 jwe 內容 
	 * 
	 * 2. 驗證頗析JWE內容
	 * 
	 * 3. 驗證回傳data存成檔案
	 * 
	 * 4. 驗證檔案AES/CBC/PKCS5PADDING解密
	 */
	public static void main(String[] args) throws Exception {
		// mydata-api-jwe 為一個測試用的 jwe 內容，
		// 對照之secret_key為 2fd73fd1fe984f2596c0151917652690
		File jweFile = new File("doc","mydata-api-jwe");
		String jweEncryptedData = new String(Files.readAllBytes(jweFile.toPath()));
		String secret_key = "2fd73fd1fe984f2596c0151917652690";

		// 驗證JWE
		Key key = new AesKey(secret_key.getBytes());
		JsonWebEncryption jwe = new JsonWebEncryption();
        jwe.setAlgorithmConstraints(new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST,
                KeyManagementAlgorithmIdentifiers.A256KW));
        jwe.setContentEncryptionAlgorithmConstraints(new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST,
                ContentEncryptionAlgorithmIdentifiers.AES_256_CBC_HMAC_SHA_512));
        jwe.setKey(key);
		jwe.setCompactSerialization(jweEncryptedData);
		String jweDecryptedData = jwe.getPayload();
		System.out.println("jweDecryptedData = "+jweDecryptedData);
		
		// 拆解JWE內容
		ObjectMapper objectMapper = new ObjectMapper();
		Map<String,String> payload = objectMapper.readValue(jweDecryptedData, HashMap.class);
		String filename = payload.get("filename");
		String data = payload.get("data");
		System.out.println("==filename==:"+filename);
//		System.out.println("==data==:"+data);
		
		if(filename!=null&&data!=null) {
			/**
			 * 去檔頭
			 */
			data = data.substring("application/zip;data:".length());
			/**
			 * 打包檔暫存路徑
			 */
			String path = "/Users/mac/mydata-example/";
			File packFile = Paths.get(path+filename).toFile();
			if(packFile.exists()) packFile.delete();
			/**
			 * 將 data 做 Base64 decode 後儲存到 打包檔暫存路徑
			 */
			byte[] encryptedData = Base64.getUrlDecoder().decode(data);
			FileUtils.writeByteArrayToFile(packFile, encryptedData);

			if(!packFile.exists() || packFile.length() == 0) {
				System.out.println("資料打包檔解密失敗！");
				return;
			}
			if(!FilenameUtils.getExtension(packFile.getName()).equalsIgnoreCase("zip")) {
				System.out.println("打包檔格式不正確！");
				return;
			}
			System.out.println("打包檔下載成功 -> "+packFile.getAbsolutePath());
		}
		
	}
	
}

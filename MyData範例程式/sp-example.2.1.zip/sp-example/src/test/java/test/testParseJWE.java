package test;

import java.io.File;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class testParseJWE {
	
	private static Base64.Decoder decoder = Base64.getUrlDecoder();
	
	public static void main(String args[]) throws InvalidKeyException, NoSuchAlgorithmException, IOException {
		testParseJWE test = new testParseJWE();
		
		File jweFile = new File("doc","mydata-api-jwe");
		String jwe = new String(Files.readAllBytes(jweFile.toPath()));
		String secretKey = "2fd73fd1fe984f2596c0151917652690";
		
		String[] parts = jwe.split("\\.");
		System.out.println("parts.length -> "+parts.length);
		// JWE 格式為「header.encrypted_key.initialization_vector.ciphertext.au-thentication_tag」，
		// 五段資料以「.」隔開
		if(parts.length != 5) {
			System.out.println("JWE組成不正確。 parts.length != 5");
		}
		
		// header , {"alg":"A256KW","enc":"A256CBC-HS512"}
	    System.out.println("header(encrypted) -> "+ parts[0]);
	    System.out.println("header.1 -> "+ new String(decoder.decode(parts[0].getBytes())));
	    
	    // encryptedKey , encrypted content encryption key
	    System.out.println("CEK(encrypted) -> "+ parts[1]);
	    SecretKeySpec kekSpec = new SecretKeySpec(secretKey.getBytes(),"AES");
	    SecretKey cek = null;
	    if(parts[1].length() > 0) {
	        cek = unwrap(kekSpec, decoder.decode(parts[1]));
	        System.out.println("decryptedCEK.length -> "+cek.getEncoded().length);
	    }else {
	        // 使用 DIRECT 演算法時，不會產生 encryptedCEK 所以使用原訂的 AES key 做解密。
	        cek = kekSpec;
	    }
	    
	    // initialization_vector (IV)
	    System.out.println("IV(encrypted) -> "+ parts[2]);
	    System.out.println("IV -> "+ new String(decoder.decode(parts[2].getBytes())));
	    
	    // authenticate and decrypt
	    // 拆解 CEK
	    // compositeKeys[0] -> HMAC key
	    // compositeKeys[1] -> AES key
	    SecretKey[] compositeKeys = test.compositeKey(cek);
	
	    // 檢算 JWE
	    boolean authenticated = test.authenticate(parts,compositeKeys[0]);
	    if(authenticated) {
	        System.out.println("authenticationTag -> JWE 檢算成功！");
	        // 解密內容
	        byte[] payload = test.decryptCiphertext(
	                compositeKeys[1], // encKey, AES key
	                decoder.decode(parts[2].getBytes()),
	                decoder.decode(parts[3].getBytes()));
	        System.out.println("payload -> "+new String(payload,"UTF-8"));
	    }else {
	        System.out.println("authenticationTag -> JWE 檢算失敗！");
	    }
	}
	
	private static SecretKey unwrap(SecretKey kek, byte[] base64UrlDecodedEncryptedCEK) {
        try {
            Cipher cipher = Cipher.getInstance("AESWrap");
            cipher.init(Cipher.UNWRAP_MODE, kek);
            SecretKey cek = (SecretKey) cipher.unwrap(base64UrlDecodedEncryptedCEK, "AES", Cipher.SECRET_KEY);
            return cek;
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    
    // 將 CEK 拆分為 HMAC key 與 AES key
    public SecretKey[] compositeKey(SecretKey cek) {
        SecretKey[] compositeKey = new SecretKey[2];

        // HMAC key
        SecretKey macKey = null;
        // AES key
        SecretKey encKey = null;

        if (cek.getEncoded().length == 32) {
            // 128bit HMAC key
            macKey = new SecretKeySpec(cek.getEncoded(), 0, 16, "HMACSHA256");
            // 128bit AES key
            encKey = new SecretKeySpec(cek.getEncoded(), 16, 16, "AES");
        } else if (cek.getEncoded().length == 64) {
            // 256bit MAC key
            macKey = new SecretKeySpec(cek.getEncoded(), 0, 32, "HMACSHA512");
            // 256bit AES key
            encKey = new SecretKeySpec(cek.getEncoded(), 32, 32, "AES");
        } else {
            System.out.println("CEK 長度不正確。 使用 AES_128_CBC_HMAC_SHA_256 長度應為 32。 使用 AES_256_CBC_HMAC_SHA_512 長度應為 64");
            return null;
        }

        compositeKey[0] = macKey;
        compositeKey[1] = encKey;

        return compositeKey;
    }

    // 檢算 JWE
    public boolean authenticate(String[] jweParts, SecretKey macKey) throws NoSuchAlgorithmException, InvalidKeyException {
        String base64UrlEncodedHeader = jweParts[0];
        byte[] base64UrlDecodedIV = decoder.decode(jweParts[2]);
        byte[] base64UrlDecodedCiphertext = decoder.decode(jweParts[3]);
        byte[] base64UrlDecodedAuthTag = decoder.decode(jweParts[4]);

        // compute AAD
        byte[] aad = base64UrlEncodedHeader.getBytes(Charset.forName("ASCII"));
        // AAD length to 8 byte array
        byte[] al = ByteBuffer.allocate(8).putLong( (aad.length * 8) ).array();

        // Check MAC
        int hmacInputLength = aad.length + base64UrlDecodedIV.length + base64UrlDecodedCiphertext.length + al.length;
        byte[] hmacInput = ByteBuffer.allocate(hmacInputLength)
                .put(aad)
                .put(base64UrlDecodedIV)
                .put(base64UrlDecodedCiphertext)
                .put(al)
                .array();
        Mac mac = Mac.getInstance(macKey.getAlgorithm());
        mac.init(macKey);
        mac.update(hmacInput);
        byte[] hmac = mac.doFinal();
        byte[] expectedAuthTag = Arrays.copyOf(hmac, macKey.getEncoded().length);

        if(expectedAuthTag.length != base64UrlDecodedAuthTag.length) {
            System.out.println("authenticate FAILED!  expectedAuthTag.length != base64UrlDecodedAuthTag.length");
            return false;
        }
        int result = 0;
        for (int i = 0; i < expectedAuthTag.length; i++) {
            result |= expectedAuthTag[i] ^ base64UrlDecodedAuthTag[i];
        }

        return result == 0;
    }

    // 解密內容
    public byte[] decryptCiphertext(SecretKey encKey, byte[] base64UrlDecodedIV, byte[] base64UrlDecodedCiphertext) {
        byte[] result = null;
        try {
            //使用CBC模式，需要一个向量iv，可增加加密算法的强度
            IvParameterSpec iv = new IvParameterSpec(base64UrlDecodedIV);

            //Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            Cipher cipher = Cipher.getInstance("AES/CBC/NOPADDING");
            cipher.init(Cipher.DECRYPT_MODE, encKey, iv);

            result = cipher.doFinal(base64UrlDecodedCiphertext);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return result;
    }

}

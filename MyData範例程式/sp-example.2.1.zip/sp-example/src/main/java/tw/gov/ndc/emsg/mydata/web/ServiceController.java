package tw.gov.ndc.emsg.mydata.web;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.fasterxml.jackson.databind.ObjectMapper;

import sun.security.pkcs.PKCS7;
import sun.security.util.DerInputStream;
import tw.gov.ndc.emsg.mydata.util.SpUtils;

@Controller
@RequestMapping("/service")
public class ServiceController {
	private final Base64.Encoder base64Encoder = Base64.getEncoder();
	/**
	 * 加密/解密算法/工作模式/填充方式
	 */
	public static final String CIPHER_ALGORITHM_CBC = "AES/CBC/PKCS5PADDING";
	
	private final String clientId = "CLI.MaWMSTqB71";
	private final String clientSecrt = "KvloHv1DS3lMe53n";
	private final String clientCbcIv = "cFJ0feEe4icTRx9P";
	
	private SpUtils utils = new SpUtils();
	
	@GetMapping("/step3_web")
	public String step3_web(ModelMap model) {
		UUID uuid = UUID.randomUUID();
		model.addAttribute("txId", uuid);
		return "service_step3_web";
	}
	
	@PostMapping("/createData")
	public void createData(
			HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		
		String requestBodyStr = getBody(request);
		String secretKey = clientSecrt+clientSecrt;
		
		// 用戶資料以AES/CBC加密後，再以Base64編碼。
		byte[] encryptedData = base64Encoder.encode(utils.encrypt(requestBodyStr.getBytes(),secretKey,clientCbcIv));
        
        String outStr = "{\"data\":\""+ new String(encryptedData) +"\"}";
		response.setStatus(HttpServletResponse.SC_OK);
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
        out.print(outStr);
		out.close();
	}
	
	@PostMapping("/spsignature")
	public void postSpsignature(
			HttpServletRequest request, 
			HttpServletResponse response, 
			ModelMap model) throws Exception {
		Map<String,String> params = new HashMap<String,String>(); //放置擷取參數
		String requestBodyStr = getBody(request);
		JSONObject payloadObj = null;
		try {
			payloadObj = (JSONObject) JSONValue.parseWithException(requestBodyStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if(payloadObj!=null) {
			for (Object o : payloadObj.entrySet()) {
				@SuppressWarnings("rawtypes")
				Map.Entry e = (Map.Entry) o;
				String key = (String) e.getKey();
				String value = (String) e.getValue();
				params.put(key, value);
			}
		}
		if(params.get("tx_id")!=null) {
			String txId = params.get("tx_id").toString();
			if(params.get("data")!=null&&params.get("pkcs7")!=null) {
				//有data & pkcs7，則發送步驟3.1請求
				
				// Create a trust manager that does not validate certificate chains
				TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						X509Certificate[] certs = null;
						return certs;
					}
					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}};
				// Install the all-trusting trust manager
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

				// Create all-trusting host name verifier
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				};
				// Install the all-trusting host verifier
				HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				
				URL connectto = new URL("https://mydatadev.nat.gov.tw/mydata/service/spsignature/"+clientId);
		        HttpURLConnection conn = (HttpURLConnection) connectto.openConnection();
		        conn.setRequestMethod("POST");
		        conn.setRequestProperty("User-Agent","Mozilla/5.0");
		        conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		        conn.setUseCaches(false);
		        conn.setAllowUserInteraction(false);
		        conn.setInstanceFollowRedirects( false );
		        conn.setDoOutput( true );
		        conn.setConnectTimeout(30000);
		        
				OutputStream os = conn.getOutputStream();
	            	DataOutputStream writer = new DataOutputStream(os);
	            	String jsonString = getJSONString(params);
	            	writer.writeBytes(jsonString);
	            	writer.flush();
	            	writer.close();
	            	os.close();
	            	
	            	int responseCode = conn.getResponseCode();
	            System.out.println("Response Code : " + responseCode);
	            if(responseCode != 200) {
	            		response.setStatus(responseCode);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					return;
	            }else {
	            		// 明細頁url
	            		String url = "https://mydatadev.nat.gov.tw/mydata/service/spsignature/"+clientId+"/QVBJLjdRb3ZFMkdldjY=/"+txId+"?returnUrl=https%3A%2F%2Fmydatadev.nat.gov.tw%2Fsp-example%2Fsp%2Fservice_apply";
					String outStr = "{\"url\":\""+ url +"\"}";
					response.setStatus(HttpServletResponse.SC_OK);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					PrintWriter out = response.getWriter();
			        out.print(outStr);
					out.close();
					return;
	            }
			}else {
				//只有tx_id，則發送步驟3請求
				
				// Create a trust manager that does not validate certificate chains
				TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						X509Certificate[] certs = null;
						return certs;
					}
					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}};
				// Install the all-trusting trust manager
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

				// Create all-trusting host name verifier
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				};
				// Install the all-trusting host verifier
				HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				
				URL connectto = new URL("https://mydatadev.nat.gov.tw/mydata/service/spsignature/"+clientId);
		        HttpURLConnection conn = (HttpURLConnection) connectto.openConnection();
		        conn.setRequestMethod("POST");
		        conn.setRequestProperty("User-Agent","Mozilla/5.0");
		        conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		        conn.setUseCaches(false);
		        conn.setAllowUserInteraction(false);
		        conn.setInstanceFollowRedirects( false );
		        conn.setDoOutput( true );
		        conn.setConnectTimeout(30000);
		        
	            OutputStream os = conn.getOutputStream();
	            DataOutputStream writer = new DataOutputStream(os);
	            String jsonString = getJSONString(params);
	            writer.writeBytes(jsonString);
	            writer.flush();
	            writer.close();
	            os.close();
	            
	            int responseCode = conn.getResponseCode();
	            System.out.println("Response Code : " + responseCode);
	            if(responseCode != 200) {
	            		response.setStatus(responseCode);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					return;
	            }else {
	            		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		            StringBuilder sb = new StringBuilder();
		            String line;
		            while ((line = br.readLine()) != null) {
		                sb.append(line+"\n");
		            }
		            br.close();
		            
					response.setStatus(HttpServletResponse.SC_OK);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					PrintWriter out = response.getWriter();
			        out.print(sb.toString());
					out.close();
					return;
	            }
			}
		}else {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
			return;
		}
	}
	
	
	/**
	 * 驗證步驟3.1 傳送驗證資料
	 * client_id
	 * data
	 * pkcs7
	 * 
	 * @param clientId
	 * @param request
	 * @param response
	 * @param model
	 * @throws IOException
	 */	
	@PostMapping("/spsignature/check")
	public void postSpsignatureCheck(HttpServletRequest request, HttpServletResponse response, ModelMap model) throws Exception {
		Map<String,Object> params = new HashMap<String,Object>(); //放置擷取參數
		String requestBodyStr = getBody(request);
		JSONObject payloadObj = null;
		String txId = null;
		String salt = null;
		PrintWriter out;
		String outStr = "";
		try {
			payloadObj = (JSONObject) JSONValue.parseWithException(requestBodyStr);
		} catch (ParseException e) {
			outStr = "驗證傳送資料JSON頗析失敗!\n"+requestBodyStr;
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
            out = response.getWriter();
            out.print(outStr);
            out.close();
			return;
		}
		if(payloadObj!=null) {
			for (Object o : payloadObj.entrySet()) {
				@SuppressWarnings("rawtypes")
				Map.Entry e = (Map.Entry) o;
				String key = (String) e.getKey();
				String value = (String) e.getValue();
				params.put(key, value);
				System.out.println("key:"+key+", value="+value);
			}
		}
		if(params.get("tx_id")==null) {
			outStr = "tx_id為空值!";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
            out = response.getWriter();
            out.print(outStr);
            out.close();
			return;
		}
		if(params.get("data")==null||params.get("pkcs7")==null) {
			outStr = "data為空值或pkcs7為空值!";
			response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
            out = response.getWriter();
            out.print(outStr);
            out.close();
			return;
		}
		if(params.get("data")!=null&&params.get("pkcs7")!=null) {
			Base64.Decoder base64Decoder = Base64.getDecoder();
			// 簽章對象（加密本文）
			byte[] encryptedData = params.get("data").toString().getBytes();
	        
	        // decode & decrypt data
	        String secretKey = clientSecrt+clientSecrt;
	        byte[] dataJson;
	        try {
	        		dataJson = decrypt_cbc(base64Decoder.decode(encryptedData),secretKey,clientCbcIv);
		    } catch (Exception ex) {
				outStr = "data使用 AES/CBC/PKCS5PADDING 解密失敗，請確定帶入 clientSecrt 和 clientCbcIv 參數值";
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.setCharacterEncoding("UTF-8");
				response.setContentType("application/json; charset=UTF-8");
	            out = response.getWriter();
	            out.print(outStr);
	            out.close();
				return;
		    }

	        // parse data to Map
	        Map<String, String> data;
	        try {
	        	JSONParser parser = new JSONParser();
				JSONObject object = (JSONObject) parser.parse(new String(dataJson));
				ObjectMapper om = new ObjectMapper();
		        data = om.convertValue(object, Map.class);
	        } catch (Exception ex) {
				outStr = "dataJSON頗析失敗!\n"+ex;
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.setCharacterEncoding("UTF-8");
				response.setContentType("application/json; charset=UTF-8");
	            out = response.getWriter();
	            out.print(outStr);
	            out.close();
				return;
		    }
	        String pid = data.get("pid");
	        String holder = data.get("holder");
	        String birthday = data.get("birthday");
	        String email = data.get("email");
	        String mobile = data.get("mobile");
	        salt = data.get("salt");
	        
	        // data 參數格式或內容不正確，或是缺少必要參數。
	        if(StringUtils.isEmpty(salt) || StringUtils.isEmpty(pid) || StringUtils.isEmpty(birthday)) {
				outStr = "salt 或 pid 或 birthday 必要值為空值!";
				response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
				response.setCharacterEncoding("UTF-8");
				response.setContentType("application/json; charset=UTF-8");
	            out = response.getWriter();
	            out.print(outStr);
	            out.close();
				return;
	        }
	        try {
				// 生成 PKCS7 物件。
				PKCS7 pkcs7 = new PKCS7(new DerInputStream(base64Decoder.decode(params.get("pkcs7").toString())));
				 // 從 PKCS7 檔案中取出憑證。
				X509Certificate[] certs = pkcs7.getCertificates();
				// 驗證憑證有效性。
		        X509Certificate prevCert = null;
		        for(int i=0; i<certs.length; i++) {
		            X509Certificate cert = certs[i];
	
		            // 驗證憑證是否已過期。
		            cert.checkValidity();
		            // 驗證憑證於憑證鏈中的有效性。
		            if(prevCert != null) {
		                prevCert.verify(cert.getPublicKey());
		            }
		            // 向CA確認憑證合法。透過 OCSP or CRL。
		            String dn = cert.getSubjectDN().toString();
		            String serialNumber = (dn.split(",")[0]).split("=")[1];
		            /**
		             * UNDO ICSAPI
		             */
		            prevCert = cert;
		        }
		        // 驗簽章
		        if(pkcs7.verify(encryptedData) == null) {
					outStr = "pkcs7驗簽章失敗";
					response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
		            out = response.getWriter();
		            out.print(outStr);
		            out.close();
					return;
		        }
	        }catch(Exception ex) {
				outStr = "pkcs7驗簽章失敗!\n"+ex;
				response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
				response.setCharacterEncoding("UTF-8");
				response.setContentType("application/json; charset=UTF-8");
	            out = response.getWriter();
	            out.print(outStr);
	            out.close();
				return;
	        }
			outStr = "驗證成功！";
			response.setStatus(HttpServletResponse.SC_OK);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
            out = response.getWriter();
            out.print(outStr);
            out.close();
			return;
		}
	}		
	
	public static String getBody(HttpServletRequest request) throws IOException {
	    String body = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;
	    try {
	        InputStream inputStream = request.getInputStream();
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            char[] charBuffer = new char[128];
	            int bytesRead = -1;
	            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
	                stringBuilder.append(charBuffer, 0, bytesRead);
	            }
	        } else {
	            stringBuilder.append("");
	        }
	    } catch (IOException ex) {
	        throw ex;
	    } finally {
	        if (bufferedReader != null) {
	            try {
	                bufferedReader.close();
	            } catch (IOException ex) {
	                throw ex;
	            }
	        }
	    }

	    body = stringBuilder.toString();
	    return body;
	}
	

    public static String getJSONString(Map<String, String> params){
        JSONObject json = new JSONObject();
        for(String key:params.keySet()) {
            try {
                json.put(key, params.get(key));
            }catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return json.toString();
    }
	
	public static byte[] encrypt_cbc(byte[] data, String key, String ivstr) throws Exception {
		// 密鑰
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"),"AES");
		// 向量鰎值
		IvParameterSpec iv = new IvParameterSpec(ivstr.getBytes("UTF-8"));
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM_CBC);
		// 初始化，設置為加密模式
		cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);
		// 執行操作
		return cipher.doFinal(data);
	}
	
	public static byte[] decrypt_cbc(byte[] data, String key, String ivstr) throws Exception {
		// 密鑰
		SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"),"AES");
		// 向量鰎值
		IvParameterSpec iv = new IvParameterSpec(ivstr.getBytes("UTF-8"));
		// 實例化
		Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM_CBC);
		// 初始化，設置為解密模式
		cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
		// 執行操作
		return cipher.doFinal(data);
	}    
}

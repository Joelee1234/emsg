package tw.gov.ndc.emsg.mydata.config;

import java.io.IOException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint{
	
	private final Logger log = LoggerFactory.getLogger(CustomAuthenticationEntryPoint.class);
	
	@Value("${app.oidc.authorize.uri}")
	private String gspOpenIdAuthorizeUri;
	@Value("${app.frontend.context.url}")
	private String frontendContextUrl;
	
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		response.sendRedirect(frontendContextUrl);
	}

}

package tw.gov.ndc.emsg.mydata.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.xml.rpc.ServiceException;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.tempuri.WsAuthGSPLocator;
import org.tempuri.WsAuthGSPSoap;

@Controller
@RequestMapping("/login")
public class NHIController {
	
	@GetMapping("/test")
	public String test1(ModelMap model) {
		return "login_test";
	}
	
	@PostMapping("/nhi/post")
	public void post(
			HttpServletRequest request,
			HttpServletResponse response) throws NoSuchAlgorithmException, KeyManagementException {
		
		String requestBodyStr = null;
		try {
			requestBodyStr = getBody(request);
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println(requestBodyStr);
		
		
		Map<String,String> params = new HashMap<String,String>();
		JSONObject object = null;
		try {
			object = (JSONObject) JSONValue.parseWithException(requestBodyStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if(object!=null) {
			for (Object o : object.entrySet()) {
				@SuppressWarnings("rawtypes")
				Map.Entry e = (Map.Entry) o;
				String key = (String) e.getKey();
				String value = (String) e.getValue();
				params.put(key, value);
			}
		}
		String p_Orgid = params.get("p_Orgid");
		String p_OrgPass = params.get("p_OrgPass");
		String p_GetBasic = params.get("p_GetBasic");
		String p_PassCode = params.get("p_PassCode");
		String p_Random = params.get("p_Random");
		String p_Token = params.get("p_Token");
		String p_idno = params.get("p_idno");
		String p_unit = params.get("p_unit");
		
		WsAuthGSPSoap soap = null;
		try {
			soap = new WsAuthGSPLocator().getwsAuthGSPSoap();
		} catch (ServiceException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
     	String result = null;
		try {
			result = soap.userSign(p_Orgid, p_OrgPass, p_GetBasic, p_PassCode, p_Random, p_Token, p_idno, p_unit);
		} catch (RemoteException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

        System.out.println("Response = "+result);
        
        String outStr = "{\"response\":\"" + result + "\"}";
        response.setStatus(HttpServletResponse.SC_OK);
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/json; charset=UTF-8");
        PrintWriter out = null;
        try {
			out = response.getWriter();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        out.print(outStr);
        out.close();
        	
	}
	
	
	public static String getBody(HttpServletRequest request) throws IOException {
	    String body = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;
	    try {
	        InputStream inputStream = request.getInputStream();
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            char[] charBuffer = new char[128];
	            int bytesRead = -1;
	            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
	                stringBuilder.append(charBuffer, 0, bytesRead);
	            }
	        } else {
	            stringBuilder.append("");
	        }
	    } catch (IOException ex) {
	        throw ex;
	    } finally {
	        if (bufferedReader != null) {
	            try {
	                bufferedReader.close();
	            } catch (IOException ex) {
	                throw ex;
	            }
	        }
	    }

	    body = stringBuilder.toString();
	    return body;
	}


}

package org.tempuri;

public class WsAuthGSPSoapProxy implements org.tempuri.WsAuthGSPSoap {
  private String _endpoint = null;
  private org.tempuri.WsAuthGSPSoap wsAuthGSPSoap = null;
  
  public WsAuthGSPSoapProxy() {
    _initWsAuthGSPSoapProxy();
  }
  
  public WsAuthGSPSoapProxy(String endpoint) {
    _endpoint = endpoint;
    _initWsAuthGSPSoapProxy();
  }
  
  private void _initWsAuthGSPSoapProxy() {
    try {
      wsAuthGSPSoap = (new org.tempuri.WsAuthGSPLocator()).getwsAuthGSPSoap();
      if (wsAuthGSPSoap != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)wsAuthGSPSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)wsAuthGSPSoap)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (wsAuthGSPSoap != null)
      ((javax.xml.rpc.Stub)wsAuthGSPSoap)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public org.tempuri.WsAuthGSPSoap getWsAuthGSPSoap() {
    if (wsAuthGSPSoap == null)
      _initWsAuthGSPSoapProxy();
    return wsAuthGSPSoap;
  }
  
  public java.lang.String userSign(java.lang.String p_Orgid, java.lang.String p_OrgPass, java.lang.String p_GetBasic, java.lang.String p_PassCode, java.lang.String p_Random, java.lang.String p_Token, java.lang.String p_idno, java.lang.String p_unit) throws java.rmi.RemoteException{
    if (wsAuthGSPSoap == null)
      _initWsAuthGSPSoapProxy();
    return wsAuthGSPSoap.userSign(p_Orgid, p_OrgPass, p_GetBasic, p_PassCode, p_Random, p_Token, p_idno, p_unit);
  }
  
  
}
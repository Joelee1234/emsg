/**
 * WsAuthGSPSoap.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.tempuri;

public interface WsAuthGSPSoap extends java.rmi.Remote {
    public java.lang.String userSign(java.lang.String p_Orgid, java.lang.String p_OrgPass, java.lang.String p_GetBasic, java.lang.String p_PassCode, java.lang.String p_Random, java.lang.String p_Token, java.lang.String p_idno, java.lang.String p_unit) throws java.rmi.RemoteException;
}

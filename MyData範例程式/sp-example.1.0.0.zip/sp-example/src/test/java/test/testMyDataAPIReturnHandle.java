package test;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class testMyDataAPIReturnHandle {
	
	/**
	 * 1. mydata-api.json 為一個測試用的 jwt 內容 
	 * 	  參考： 玖、MyData-API Endpoint規格說明 三、MyData-API的回傳格式與加簽機制說明 （一）JWT格式說明
	 *  
	 * 2. 此處 secret_key 0471f681fa334dba87c0d47fccd76a47 為對照 /doc/mydata-api.json 內的 HMACSHA256 secret_key
	 * 3. 驗證方式，使用 HMACSHA256 ({header}.{payload}, secret_key)，比對 signature 字串
	 *    ㄧ致則表示未串改
	 *    不一致則資料異常
	 */
	public static void main(String[] args) throws Exception {
		String secret_key = "0471f681fa334dba87c0d47fccd76a47";
		String jwtjsonstr = readFileAsString("/Users/mac/Desktop/Eclipse_Work/workspace_oxygen/mydata_examples/sp-example/doc/mydata-api.json");
		String[] jwtjsonstrList = jwtjsonstr.split("[.]");
		/**
		 * 回傳JWT必為三段
		 */
		System.out.println("==jwtjsonstrList.length==:"+jwtjsonstrList.length);
		String unsigntoken = jwtjsonstrList[0]+"."+jwtjsonstrList[1];
		String jwtsignature = jwtjsonstrList[2];
		
		/**
		 * 回傳 HMACSHA256 ({header}.{payload}, secret_key)
		 */
		String signature = HMACSHA256(unsigntoken.getBytes(),secret_key.getBytes());
		System.out.println("==jwtsignature==:"+jwtsignature);
		System.out.println("==signature   ==:"+signature);
		
		/**
		 * 結果比對
		 */
		if(signature.equalsIgnoreCase(jwtsignature)) {
			System.out.println("==verify jwt==:"+true);
		}else {
			System.out.println("==verify jwt==:"+false);
		}
		
	}
	public static String readFileAsString(String fileName) throws Exception {
		String data = "";
		data = new String(Files.readAllBytes(Paths.get(fileName)));
		return data;
	}
	
	public static String HMACSHA256(byte[] data, byte[] key){
	      try  {
	         SecretKeySpec signingKey = new SecretKeySpec(key, "HmacSHA256");
	         Mac mac = Mac.getInstance("HmacSHA256");
	         mac.init(signingKey);
	         return byte2hex(mac.doFinal(data));
	      } catch (NoSuchAlgorithmException e) {
	         e.printStackTrace();
	      } catch (InvalidKeyException e) {
	        e.printStackTrace();
	      }
	      return null;
	}
	
	public static String byte2hex(byte[] b){
	    StringBuilder hs = new StringBuilder();
	    String stmp;
	    for (int n = 0; b!=null && n < b.length; n++) {
	        stmp = Integer.toHexString(b[n] & 0XFF);
	        if (stmp.length() == 1)
	            hs.append('0');
	        hs.append(stmp);
	    }
	    return hs.toString().toUpperCase();
	}
}

package test;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

import com.google.common.hash.Hashing;

public class testManifestVerify {
	public final static String ALGORITHM = "RSA";
	public final static String SIGNATURE_ALGORITHM = "MD5withRSA";
	
	/**
	 * 檔案為[MyData資料打包檔]解壓後，[DP資料打包檔]的內容
	 * 參考： 玖、MyData-API Endpoint規格說明 六、資料提供者的DP資料打包檔規格說明
	 * 使用內含憑證檔「certification.cer」取得公鑰驗簽
	 */
	public static void main(String[] args) throws Exception {
		String manifestPathStr = "/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/META-INFO/manifest.xml";
		String signaturePathStr = "/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/META-INFO/manifest.sha256withrsa";

		byte[] b = Files.readAllBytes(Paths.get(manifestPathStr));
		System.out.println("SHA256-0 file：" + Hashing.sha256().hashBytes(b).toString());
		byte[] signedData = Files.readAllBytes(Paths.get("/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/META-INFO/manifest.sha256withrsa"));
		String signAlg = "SHA256withRSA"; // 簽名類型
		Signature signature = Signature.getInstance(signAlg);
		signature.initVerify(getCAPublicKey("/Users/mac/Desktop/mydata-example/tmp/API.Mo23SDWhsn20191014094106/META-INFO/certificate.cer"));
		signature.update(b);		
		boolean isVerify = signature.verify(signedData);
		System.out.println("CA驗簽：" + isVerify);
	}

	public static String readFileAsString(String fileName) throws Exception {
		String data = "";
		data = new String(Files.readAllBytes(Paths.get(fileName)));
		return data;
	}
	
	/**
	 * getCAPublickKey
	 * 
	 * @return
	 * @throws Exception
	 */
	private static PublicKey getCAPublicKey(String cerpath) throws Exception {
		String keyStr = "";
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(new FileInputStream( cerpath ));
			keyStr = Base64.getUrlEncoder().encodeToString(cert.getPublicKey().getEncoded());
			// System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getUrlDecoder().decode(keyStr));
		KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
		PublicKey k = keyFactory.generatePublic(keySpec);
		return k;
	}	
}

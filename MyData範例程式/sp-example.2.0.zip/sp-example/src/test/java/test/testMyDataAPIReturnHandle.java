package test;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.security.Key;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwe.ContentEncryptionAlgorithmIdentifiers;
import org.jose4j.jwe.JsonWebEncryption;
import org.jose4j.jwe.KeyManagementAlgorithmIdentifiers;
import org.jose4j.keys.AesKey;
import org.jose4j.lang.JoseException;

public class testMyDataAPIReturnHandle {
	
	public static void main(String[] args) throws JoseException, IOException {
		String secret_key = "2fd73fd1fe984f2596c0151917652690";
		File jweFile = new File("doc","mydata-api-jwe");
		String jweData = new String(Files.readAllBytes(jweFile.toPath()));

		Key key = new AesKey(secret_key.getBytes());
		JsonWebEncryption jwe = new JsonWebEncryption();
        jwe.setAlgorithmConstraints(new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST,
                KeyManagementAlgorithmIdentifiers.A256KW));
        jwe.setContentEncryptionAlgorithmConstraints(new AlgorithmConstraints(AlgorithmConstraints.ConstraintType.WHITELIST,
                ContentEncryptionAlgorithmIdentifiers.AES_256_CBC_HMAC_SHA_512));
        jwe.setKey(key);
		jwe.setCompactSerialization(jweData);
		String jweInfo = jwe.getPayload();
		System.out.println("jweInfo = "+jweInfo);
		
	}

}

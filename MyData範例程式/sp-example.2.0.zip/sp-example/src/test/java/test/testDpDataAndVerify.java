package test;

import com.google.common.hash.Hashing;
import org.apache.commons.io.FilenameUtils;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;
import tw.gov.ndc.emsg.mydata.util.SpUtils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.SignatureException;
import java.security.cert.CertificateException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * 解壓縮且合併驗證DpData和Verify
 */
public class testDpDataAndVerify {
    private static Element root;
    private static List<String> name = new ArrayList<String>();
    private static Document document;
    // 下載後壓縮檔存放路徑
    private static String dirPath = "/Users/zhanqianjin/Downloads/";
    // 壓縮檔名稱為
    private static String resourceId = "G0p40r7KW0z30c5ZL80d54962";
    // 檔案名稱
    private static String pdfName;
    private static String jsonName; // p7b和json都可以使用
    // 檔案路徑
    private static String pdfPath ;
    private static String jsonPath;

    public static void main(String[] args) {

        unzipFile();
        testVerify();
        testDpData();

    }

    /**
     * 解壓縮檔案
     */
    private static void unzipFile() {
        SpUtils utils = new SpUtils();
        File packDir = new File(dirPath + resourceId + ".zip");

        // 產生解壓縮目的地的File物件
        String resName = FilenameUtils.removeExtension(packDir.getName());
        File targetFile = new File(packDir.getParent() + "/" + resName + "/");
        if (!targetFile.exists()) {
            targetFile.mkdir();
        }

        try {
            // 去除掉mac系統的隱藏檔
            File[] fs = targetFile.listFiles((dir, name) -> !name.equals(".DS_Store"));
            if (fs.length < 1) {
                utils.unzip(packDir, targetFile);
            } else {
                System.out.println("does not need to unzip file");
            }
            targetFileDeconstruction(targetFile.listFiles());

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * 解構targetFile資料夾
     */
    private static void targetFileDeconstruction(File[] targetFiles){
        for(File f : targetFiles){
            if(!f.isDirectory()) {
                // 需要解析的pdf, json(p7b)
                String extension = FilenameUtils.getExtension(f.getName());
                switch (extension){
                    case "pdf" :
                        pdfName = f.getName();
                        break;
                    case "p7b"  :
                    case "json" :
                        jsonName = f.getName();
                }
            }

        }
        pdfPath = dirPath + resourceId + "/" + pdfName;
        jsonPath = dirPath + resourceId + "/" + jsonName;
    }

    private static void testVerify() {
        SpUtils utils = new SpUtils();
        File packDir = new File(dirPath + resourceId);

        try {
            boolean verifyDpSignatur = utils.verifySignature(packDir);
            if (verifyDpSignatur) {
                System.out.println("DP打包檔數位簽章驗證成功");
            } else {
                System.out.println("DP打包檔數位簽章驗證失敗");
            }
        } catch (IOException | InvalidKeyException | CertificateException | SignatureException e) {
            e.printStackTrace();
        }
    }


    private static void testDpData() {
        /**
         * XML處理 dom4j
         */

        // 組成manifest存放路徑
        String dirMeta = "/META-INFO/manifest.xml";
        String manifestPathStr = dirPath + resourceId + dirMeta;
        File manifestfile = new File(manifestPathStr);
        Map<String, String> hashmap = new HashMap<String, String>();
        try {
            SAXReader reader = new SAXReader();
            Document doc = reader.read(manifestfile);
            root = doc.getRootElement();
            List<Element> childElements = root.elements();
            for (Element child : childElements) {
                hashmap.put(child.elementText("filename"), child.elementText("digest"));
                System.out.println("filename=\n" + child.elementText("filename"));
                System.out.println("digest=\n" + child.elementText("digest"));
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        /**
         * SHA-256驗證
         */

        String pdfPathStr = pdfPath;
        String jsonPathStr = jsonPath;

        try {
            byte[] b = Files.readAllBytes(Paths.get(pdfPathStr));
            byte[] bs = Files.readAllBytes(Paths.get(jsonPathStr));
            String sha256file = Hashing.sha256().hashBytes(b).toString();
            String sha256filebs = Hashing.sha256().hashBytes(bs).toString();
            System.out.println("SHA256-0 file：\n" + Hashing.sha256().hashBytes(b).toString());
            System.out.println("SHA256-1 file：\n" + Hashing.sha256().hashBytes(bs).toString());
            String sha256manifest = hashmap.get(pdfName);
            if (sha256file.equalsIgnoreCase(sha256manifest)) {
                System.out.println("==SHA-256 0==:" + true);
            } else {
                System.out.println("==SHA-256 0==:" + false);
            }
            String sha256manifestbs = hashmap.get(jsonName);
            if (sha256filebs.equalsIgnoreCase(sha256manifestbs)) {
                System.out.println("==SHA-256 1==:" + true);
            } else {
                System.out.println("==SHA-256 1==:" + false);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

}

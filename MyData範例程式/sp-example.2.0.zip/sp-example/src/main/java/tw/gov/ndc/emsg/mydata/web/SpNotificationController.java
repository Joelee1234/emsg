package tw.gov.ndc.emsg.mydata.web;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.PublicKey;
import java.security.Signature;
import java.security.SignatureException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.FilenameUtils;
import org.apache.http.HttpResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import tw.gov.ndc.emsg.mydata.util.SpUtils;


/**
 * SP-API 實作
 * 捌、SP-API Endpoint規格說明
 *
 */
@Controller
@RequestMapping("/notification")
public class SpNotificationController {

	private static final Logger logger = LoggerFactory.getLogger(SpNotificationController.class);


	@Value("${mydata.api.url}")
	private String mydataHost;		// MyData主機網址
	@Value("${sp.temp.directory}")
	private String spTempDir;		// SP暫存MyData打包檔的路徑。

	@Autowired
	private RestTemplate restTemplate;
	@Autowired
	private ThreadPoolTaskExecutor threadPoolTaskExecutor;

	
	/**
	 * SP-API
	 * 捌、SP-API Endpoint規格說明（一）MyData發出請求 - 告知SP準備來捉取資料檔
	 * Content-Type: application/json
	 * 
	 * @param params permission_ticket - String 
	 * @param params secret_key - String
	 * @param params unable_to_deliver - ArrayList 
	 * 
	 * 成功 HTTP/1.1 200 OK 
	 * 失敗 HTTP/1.1 403 Forbidden 
	 */
	@PostMapping
	public void postNotify(@RequestBody Map<String,Object> params,
						   HttpServletResponse httpResponse) {
		
		String permissionTicket = (String)params.get("permission_ticket");
		String txId = (String)params.get("tx_id");
		String secretKey = (String)params.get("secret_key");
		List<String> unableToDeliver = (ArrayList<String>)params.get("unable_to_deliver");

		logger.debug("permission_ticket ... {}", permissionTicket);
		logger.debug("txId ................ {}", txId);
		logger.debug("secret_key .......... {}", secretKey);
		logger.debug("unable_to_deliver ... {}", unableToDeliver);


		if(unableToDeliver!=null&&unableToDeliver.size()>0) {
			// TODO 處理異常狀況，有部份資料集無法取得。
			String unableToDeliverResourceId = unableToDeliver.stream().collect(Collectors.joining(","));
			logger.warn("unableToDeliver resourceId -> {}", unableToDeliverResourceId);
			return;
		}
		
		// 另起執行緒處理。
		threadPoolTaskExecutor.execute(() -> {
			/**
			 * 此處故意等3秒後執行以待，檔案處理
			 */
			try {
				Thread.sleep(3000l);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
			
			SpUtils utils = new SpUtils();

			// 呼叫 MyData-API
			String mydataApiUrl = utils.getMyDataApiUrl(mydataHost);
			logger.debug("mydataApiUrl -> {}", mydataApiUrl);

			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.ALL.APPLICATION_JSON);
			headers.set("permission_ticket", permissionTicket);
			HttpEntity entity = new HttpEntity(headers);
			HttpStatus statusCode = null;
			ResponseEntity<String> response = null;
			try {
				response = restTemplate.exchange(mydataApiUrl, HttpMethod.GET, entity, String.class);
				statusCode = response.getStatusCode();
			}catch (HttpStatusCodeException exception) {
				statusCode = exception.getStatusCode();
			}
			logger.info("Http Status Code -> {}", statusCode);

			if(HttpStatus.TOO_MANY_REQUESTS == statusCode) {
				HttpHeaders hs = response.getHeaders();
				Integer retryAfter = 60;
				if(hs.containsKey("Retry-After")) {
					retryAfter = Integer.valueOf(hs.get("Retry-After").get(0));
					logger.info("MyData回覆429  Retry-After -> {}", retryAfter);
					
				}else {
					logger.warn("MyData回覆429  但無 Retry-After 值！");
				}
				// TODO 等待後再發動請求。
				
				logger.info("Http Status Code -> {}", statusCode);
				return;
			}else if(HttpStatus.OK == statusCode || HttpStatus.CREATED == statusCode) {
				//UNDO
				logger.info("Http Status Code -> {}", statusCode);
			}else {
				logger.info("Http Status Code -> {}", statusCode);
				return;
			}

			String mydataJwt = response.getBody();
			String[] jwtInfo = mydataJwt.split("[.]");
			logger.info("MyData JWT -> {} , parts:{}", mydataJwt, jwtInfo.length);

			if(jwtInfo.length != 3) {
				logger.warn("JWT 格式不正確。");
				return;
			}

			// 驗證 JWT 簽章
			String jwtSignature = jwtInfo[2];
			boolean isSignatureOk = utils.verifyJwtSignature(mydataJwt, secretKey);
			if(!isSignatureOk) {
				logger.warn("JWT簽章驗證失敗！");
				return;
			}else {
				logger.info("JWT簽章驗證成功！");
			}

			// 拆解 JWT payload
			Map<String,String> payload = null;
			try {
				//logger.warn("payload=\n"+utils.base64DecodeToString(jwtInfo[1]));
				payload = utils.parseJsonToMap(utils.base64DecodeToString(jwtInfo[1]));
			} catch (IOException e) {
				e.printStackTrace();
				return;
			}
			String fileName = payload.get("filename");
			String dataString = payload.get("data");
			logger.warn("dataString -> {}",dataString);
			// Base64編碼後的資料檔內容
			String base64EncodedData = dataString.substring("application/zip;data:".length());
			logger.warn("base64EncodedData -> {}",base64EncodedData);
			byte[] encryptedData = utils.base64DecodeToBytes(base64EncodedData);
			// MyData打包檔暫存路徑
			File packFile = Paths.get(spTempDir,fileName).toFile();
			if(packFile.exists()) packFile.delete();
			logger.debug("MyData打包檔暫存路徑 -> {}", packFile.getAbsolutePath());

			// 解密後並儲存資料檔
			try {
				utils.decryptToFile(encryptedData, secretKey, packFile);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if(!packFile.exists() || packFile.length() == 0) {
				logger.warn("MyData資料打包檔解密失敗！");
				return;
			}
			if(!FilenameUtils.getExtension(packFile.getName()).equalsIgnoreCase("zip")) {
				logger.warn("MyData打包檔格式不正確！");
				return;
			}

			logger.info("MyData打包檔下載成功 -> {}", packFile.getAbsolutePath());

			// 解壓縮 MyData 打包檔
			File packDir = packFile.getParentFile();
			try {
				utils.unzip(packFile, packFile.getParentFile());
			} catch (IOException e) {;
				e.printStackTrace();
			}
			// MyData打包檔中的 manifest.xml
			File manifestFile = utils.manifestFileOfMyDataPackFile(packDir);
			logger.info("MyData打包檔中的 manifest.xml -> {}", manifestFile.getAbsolutePath());

			// 解壓縮 DP打包檔
			File[] dpPackFiles = packDir.listFiles(new FileFilter() {
				@Override
				public boolean accept(File pathname) {
					return pathname.isFile() && pathname.getName().toLowerCase().endsWith("zip");
				}
			});
			Arrays.stream(dpPackFiles).forEach(dpPackFile -> {
				File dpPackDir = dpPackFile.getParentFile();
				try {
					utils.unzip(dpPackFile, dpPackDir);
					// TODO 驗證DP打包檔內的憑證檔及數位簽章。
					boolean verifyDpSignatur = utils.verifySignature(dpPackDir);
					if(verifyDpSignatur) {
						logger.info("DP打包檔數位簽章驗證成功");
					}else {
						logger.warn("DP打包檔數位簽章驗證失敗");
					}
				} catch (IOException | InvalidKeyException | CertificateException | SignatureException e) {
					e.printStackTrace();
				}
			});
			
		});


		//ResponseEntity<String> restTemplate.getForEntity(mydataApiUrl, String.class, );


		/**
		 * SP需自行紀錄，以待驗證用
		 * 1. permission_ticket
		 * 2. secret_key
		 * 3. unable_to_deliver
		 */
		
		/**
		 * 服務狀態回復
		 * 正常 200
		 * 錯誤 403
		 */
		boolean check = true;
		
		if(check) {
			httpResponse.setStatus(HttpServletResponse.SC_OK);
		}else {
			httpResponse.setStatus(HttpServletResponse.SC_FORBIDDEN);
		}
	}
}

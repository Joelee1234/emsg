package tw.gov.ndc.emsg.mydata.web;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.simple.JSONObject;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/service")
public class ServiceController {
	private final Base64.Encoder base64Encoder = Base64.getEncoder();
	
	private final String clientId = "CLI.MaWMSTqB71";
	private final String clientSecrt = "KvloHv1DS3lMe53n";
	private final String clientCbcIv = "cFJ0feEe4icTRx9P";
	
	@GetMapping("/step3_web")
	public String step3_web(ModelMap model) {
		UUID uuid = UUID.randomUUID();
		model.addAttribute("txId", uuid);
		return "service_step3_web";
	}
	
	@PostMapping("/createData")
	public void createData(
			HttpServletRequest request,
			HttpServletResponse response) throws IOException {
		
		String requestBodyStr = getBody(request);
		String secretKey = clientSecrt+clientSecrt;
		
		// 用戶資料以AES/CBC加密後，再以Base64編碼。
		byte[] encryptedData = base64Encoder.encode(createEncryptedData(requestBodyStr.getBytes(),secretKey,clientCbcIv));
        
        String outStr = "{\"data\":\""+ new String(encryptedData) +"\"}";
		response.setStatus(HttpServletResponse.SC_OK);
		response.setCharacterEncoding("UTF-8");
		response.setContentType("application/json; charset=UTF-8");
		PrintWriter out = response.getWriter();
        out.print(outStr);
		out.close();
	}
	
	@PostMapping("/spsignature")
	public void postSpsignature(
			HttpServletRequest request, 
			HttpServletResponse response, 
			ModelMap model) throws Exception {
		Map<String,String> params = new HashMap<String,String>(); //放置擷取參數
		String requestBodyStr = getBody(request);
		JSONObject payloadObj = null;
		try {
			payloadObj = (JSONObject) JSONValue.parseWithException(requestBodyStr);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		if(payloadObj!=null) {
			for (Object o : payloadObj.entrySet()) {
				@SuppressWarnings("rawtypes")
				Map.Entry e = (Map.Entry) o;
				String key = (String) e.getKey();
				String value = (String) e.getValue();
				params.put(key, value);
			}
		}
		if(params.get("tx_id")!=null) {
			String txId = params.get("tx_id").toString();
			if(params.get("data")!=null&&params.get("pkcs7")!=null) {
				//有data & pkcs7，則發送步驟3.1請求
				
				// Create a trust manager that does not validate certificate chains
				TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						X509Certificate[] certs = null;
						return certs;
					}
					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}};
				// Install the all-trusting trust manager
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

				// Create all-trusting host name verifier
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				};
				// Install the all-trusting host verifier
				HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				
				URL connectto = new URL("https://mydatadev.nat.gov.tw/mydata-v2/service/spsignature/"+clientId);
		        HttpURLConnection conn = (HttpURLConnection) connectto.openConnection();
		        conn.setRequestMethod("POST");
		        conn.setRequestProperty("User-Agent","Mozilla/5.0");
		        conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		        conn.setUseCaches(false);
		        conn.setAllowUserInteraction(false);
		        conn.setInstanceFollowRedirects( false );
		        conn.setDoOutput( true );
		        conn.setConnectTimeout(30000);
		        
				OutputStream os = conn.getOutputStream();
	            	DataOutputStream writer = new DataOutputStream(os);
	            	String jsonString = getJSONString(params);
	            	writer.writeBytes(jsonString);
	            	writer.flush();
	            	writer.close();
	            	os.close();
	            	
	            	int responseCode = conn.getResponseCode();
	            System.out.println("Response Code : " + responseCode);
	            if(responseCode != 200) {
	            		response.setStatus(responseCode);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					return;
	            }else {
	            		// 明細頁url
	            		String url = "https://mydatadev.nat.gov.tw/mydata-v2/service/spsignature/"+clientId+"/QVBJLjdRb3ZFMkdldjY=/"+txId+"?returnUrl=https%3A%2F%2Fmydatadev.nat.gov.tw%2Fsp-example%2Fsp%2Fservice_apply";
					String outStr = "{\"url\":\""+ url +"\"}";
					response.setStatus(HttpServletResponse.SC_OK);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					PrintWriter out = response.getWriter();
			        out.print(outStr);
					out.close();
					return;
	            }
			}else {
				//只有tx_id，則發送步驟3請求
				
				// Create a trust manager that does not validate certificate chains
				TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
					public java.security.cert.X509Certificate[] getAcceptedIssuers() {
						X509Certificate[] certs = null;
						return certs;
					}
					public void checkClientTrusted(X509Certificate[] certs, String authType) {
					}
					public void checkServerTrusted(X509Certificate[] certs, String authType) {
					}
				}};
				// Install the all-trusting trust manager
				SSLContext sc = SSLContext.getInstance("SSL");
				sc.init(null, trustAllCerts, new java.security.SecureRandom());
				HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

				// Create all-trusting host name verifier
				HostnameVerifier allHostsValid = new HostnameVerifier() {
					public boolean verify(String hostname, SSLSession session) {
						return true;
					}
				};
				// Install the all-trusting host verifier
				HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
				
				URL connectto = new URL("https://mydatadev.nat.gov.tw/mydata-v2/service/spsignature/"+clientId);
		        HttpURLConnection conn = (HttpURLConnection) connectto.openConnection();
		        conn.setRequestMethod("POST");
		        conn.setRequestProperty("User-Agent","Mozilla/5.0");
		        conn.setRequestProperty("Content-Type","application/x-www-form-urlencoded");
		        conn.setUseCaches(false);
		        conn.setAllowUserInteraction(false);
		        conn.setInstanceFollowRedirects( false );
		        conn.setDoOutput( true );
		        conn.setConnectTimeout(30000);
		        
	            OutputStream os = conn.getOutputStream();
	            DataOutputStream writer = new DataOutputStream(os);
	            String jsonString = getJSONString(params);
	            writer.writeBytes(jsonString);
	            writer.flush();
	            writer.close();
	            os.close();
	            
	            int responseCode = conn.getResponseCode();
	            System.out.println("Response Code : " + responseCode);
	            if(responseCode != 200) {
	            		response.setStatus(responseCode);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					return;
	            }else {
	            		BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
		            StringBuilder sb = new StringBuilder();
		            String line;
		            while ((line = br.readLine()) != null) {
		                sb.append(line+"\n");
		            }
		            br.close();
		            
					response.setStatus(HttpServletResponse.SC_OK);
					response.setCharacterEncoding("UTF-8");
					response.setContentType("application/json; charset=UTF-8");
					PrintWriter out = response.getWriter();
			        out.print(sb.toString());
					out.close();
					return;
	            }
			}
		}else {
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			response.setCharacterEncoding("UTF-8");
			response.setContentType("application/json; charset=UTF-8");
			return;
		}
	}
	
	public static String getBody(HttpServletRequest request) throws IOException {
	    String body = null;
	    StringBuilder stringBuilder = new StringBuilder();
	    BufferedReader bufferedReader = null;
	    try {
	        InputStream inputStream = request.getInputStream();
	        if (inputStream != null) {
	            bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
	            char[] charBuffer = new char[128];
	            int bytesRead = -1;
	            while ((bytesRead = bufferedReader.read(charBuffer)) > 0) {
	                stringBuilder.append(charBuffer, 0, bytesRead);
	            }
	        } else {
	            stringBuilder.append("");
	        }
	    } catch (IOException ex) {
	        throw ex;
	    } finally {
	        if (bufferedReader != null) {
	            try {
	                bufferedReader.close();
	            } catch (IOException ex) {
	                throw ex;
	            }
	        }
	    }

	    body = stringBuilder.toString();
	    return body;
	}
	
	// 產生加密本文。
    public byte[] createEncryptedData(byte[] plainData, String key, String ivstr) throws IOException {
        // 以 AES/CBC/PKCS5PADDING 演算法加密明文本文。
        byte[] encrypteData = null;
        try {
            //使用CBC模式，需要一个向量iv，可增加加密算法的强度
            IvParameterSpec iv = new IvParameterSpec(ivstr.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"),"AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            encrypteData = cipher.doFinal(plainData);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return encrypteData;
    }

    public static String getJSONString(Map<String, String> params){
        JSONObject json = new JSONObject();
        for(String key:params.keySet()) {
            try {
                json.put(key, params.get(key));
            }catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        return json.toString();
    }
}

/**
 * 
 */
package tw.gov.ndc.emsg.mydata.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

/**
 * @author wesleyzhuang
 *
 */
@Configuration
public class ThreadTaskConfig {


	private int corePoolSize = 1;
	private int maxPoolSize = 5;
	private int queueCapacity = 20;
	private int keepAliveSeconds = 30;

	/**
	 * SNMP所需的執行緒數量，以監控設備的數量為依據。
	 * @return
	 */
	@Bean
    public ThreadPoolTaskExecutor threadPoolTaskExecutor() {
		ThreadPoolTaskExecutor t = new ThreadPoolTaskExecutor();
        t.setCorePoolSize(corePoolSize);	//线程池维护线程的最少数量
        t.setMaxPoolSize(maxPoolSize);	//线程池维护线程的最大数量
        t.setQueueCapacity(queueCapacity);	//线程池所使用的缓冲队列
        t.setKeepAliveSeconds(keepAliveSeconds);	//线程池维护线程所允许的空闲时间
        return t;
	}

}

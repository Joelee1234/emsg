/**
 * 
 */
package com.ndc.common.validator;

/**
 * 執行新增資料時進行驗證。
 * 定義用來使用於分組驗證機制（validation groups）。
 * @author wesleyzhuang
 *
 */
public interface ValidateOnCreate {

}

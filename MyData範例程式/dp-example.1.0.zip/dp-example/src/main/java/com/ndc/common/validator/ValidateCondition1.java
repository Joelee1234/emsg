/**
 * 
 */
package com.ndc.common.validator;

/**
 * 用來識別驗證時機
 * @author wesleyzhuang
 *
 */
public interface ValidateCondition1 {

}

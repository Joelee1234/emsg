package tw.gov.ndc.emsg.mydata.web;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.bean.IntrospectEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

@RestController
@RequestMapping("/resource")
public class ResourceConyroller {

	private static final Logger logger = LoggerFactory.getLogger(ResourceConyroller.class);
	private static DecimalFormat formatter = new DecimalFormat("#.#");
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	private GspOidcClient gspClient;
	@Autowired
	private NonceHelper nonceHelper;
	@Value("${gsp.oidc.resource.id}")
	private String resourceId;
	@Value("${gsp.oidc.resource.secret}")
	private String resourceSecret;
	@Value("${app.download.path.temp}")
	private String downPath;


	/**
	 * 資料下載處理：參考「資料提供者技術文件 捌、DP-API Endpoint 規格準則」和 [流程示意圖]
	 */
	@GetMapping
	public ResponseEntity<byte[]> getResourceDataHandleProcessor(
			@RequestHeader Map<String,String> headers,
			@RequestParam(name="heartbeat", required=false, defaultValue="false") Boolean heartbeat,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		logger.debug("heartbeat ......... {}", heartbeat);
		logger.info("headers ......... {}", headers.size());

		headers.keySet().iterator().forEachRemaining(key -> {
			logger.info("map.key -> {} , {}", key, headers.get(key));
		});

		/**
		 * MyData發出heartbeat請求判斷
		 * 請參考：「資料提供者技術文件 捌、DP-API Endpoint 規格準則」 三、DP-API Heartbeat 機制說明
		 */
		if(heartbeat) {
			// TODO 實作確認 DP-API 狀態之程式碼。若 DP-API 狀態正常則回覆 200 OK, 若狀態異常則回覆 500 INTERNAL_SERVER_ERROR
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));

			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.OK);
			//return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}


		/**
		 * HTTP Header 'Authorization' 值為 'Bearer {access_token}'。
		 * 因此取得 access_token 的方法，即是將 Bearer 字串去除即可。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String authorization = headers.get("authorization");
		String accessToken = authorization.replace("Bearer ", "");
		logger.debug("access_token ......... {}", accessToken);

		/**
		 * HTTP Header 'transaction_uid' 代表交易鍵值，用於讓DP方便識別資料查詢請求為同一次交易。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String transactionUid = headers.get("transaction_uid");
		logger.debug("transaction_uid ...... {}", transactionUid);

		/**
		 * HTTP Header 'custom_param' 代表自訂查詢鍵值，custom_param只是示意用字，實際參數依各自DP資料集查詢需要而不同。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String customParam = headers.get("custom_param");
		logger.debug("custom_param ......... {}", customParam);

		/**
		 * 驗證access_token，反查access_token
		 * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 三、Introspection Endpoint」
		 */
		if( ! isValidAccessToken(accessToken)) {
			// 反查失敗！ 回覆 401 SC_UNAUTHORIZED。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
		}

		/**
		 * 取得用戶基本資料。
		 * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 四、UserInfo Endpoint」
		 */
		UserInfoEntity userInfoEntity = getUserInfo(accessToken);
		// 示意：取得用戶身份證字號。
		String userUid = userInfoEntity.getUid();
		if(userUid == null || userUid.isEmpty()) {
			// 無法取得用戶身份證字號！ 回覆 401 SC_UNAUTHORIZED。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
		}
		logger.debug("userUid ...... {}", userUid);

		/**
		 * 若查詢個人資料需要帶入自訂參數，則驗證其格式及有效性。
		 */
		if( ! isValidCustomParam(customParam)) {
			// 缺少必要參數或是參數驗證失敗！ 回覆 400 SC_BAD_REQUEST。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.BAD_REQUEST);
		}

		// 示意：取得用戶個人資料。
		Object userData = findUserData(userUid, customParam);
		if(userData == null) {
			// 示意：查無資料！ 回覆 204 SC_NO_CONTENT。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.NO_CONTENT);
		}

		/**
		 * 示意：產生DP打包檔。
		 * 根據MyData傳送的Content-Type，判斷回傳的內容
		 * application/zip -----> 將json和pdf打包成zip檔案
		 */
		String contentType = headers.get("content-type");
		if(contentType != null
				&& contentType.equalsIgnoreCase("application/zip")) {

			// TODO 產生資料集打包檔

			// 示意：回傳資料集打包檔。
			File packingFile = new File("/packingfiles",resourceId+".zip");
			if(packingFile.exists()) {
				/**
				 * 示意：DP回覆請求成功 – 即時回應
				 */
				InputStream fileInputStream = new FileInputStream(packingFile);
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				IOUtils.copy(fileInputStream, byteArrayOutputStream);
				byte[] data = byteArrayOutputStream.toByteArray();

				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/zip"));
				responseHeaders.setContentLength(data.length);
				responseHeaders.set("Content-disposition", "attachment; filename="+resourceId+".zip");

				return new ResponseEntity<>(data, responseHeaders, HttpStatus.OK);
			}else {
				/**
				 * 示意：DP回覆請求成功 – 資料檔案未準備好，等候處理。 回覆 429 TOO_MANY_REQUESTS
				 */
				String waitSeconds = "30";
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/json"));
				responseHeaders.set("Retry-After", waitSeconds);

				return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.TOO_MANY_REQUESTS);
			}
		}else {
			/**
			 * DP回覆請求失敗
			 */
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
		}
	}

	// 示意：驗證 custom_param 的格式及有效性。。
	private boolean isValidCustomParam(String customParam) {
		// TODO 執行驗證自訂參數格式是否正確，或是是否為合理有效值。
		return true;
	}


	// 示意：以 access_token 向 GSP 反查 token 的有效性。
	private boolean isValidAccessToken(String accessToken) throws IOException {
		IntrospectEntity introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
		if(introspectEntity == null) {
			logger.debug("無法透過 Introspection Endpoint 順利反查 access_token 的有效性。");
			return false;
		}

		if(introspectEntity.getActive()) {
			/**
			 * 示意 access_token 驗證成功
			 */
			logger.debug("sub ........... {}", introspectEntity.getSub());
			logger.debug("scop .......... {}", introspectEntity.getScope());
			logger.debug("clientId ...... {}", introspectEntity.getClientId());
			return true;
		}else {
			logger.debug("經反查 Introspection Endpoint 驗證 access_token 不是有效的token。");
			return false;
		}
	}

	// 示意：以 access_token 向 GSP 反查用戶基本資料。
	private UserInfoEntity getUserInfo(String accessToken) throws IOException {
		// 以access_token去要求user_info
		UserInfoEntity userInfoEntity = gspClient.requestUserInfo(accessToken);
		if (userInfoEntity != null) {
			logger.debug("sub .............. {}", userInfoEntity.getSub());         // 與id_token相同
			logger.debug("account .......... {}", userInfoEntity.getAccount());     // egov帳號
			logger.debug("uid .............. {}", userInfoEntity.getUid());         // 身份證字號
			logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid());  // 身份證字號是否已驗證
			logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
			logger.debug("gender ........... {}", userInfoEntity.getGender());
			logger.debug("name ............. {}", userInfoEntity.getName());
			logger.debug("email ............ {}", userInfoEntity.getEmail());
			logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
			logger.debug("phone_number ..... {}", userInfoEntity.getPhoneNumber());
		}
		return userInfoEntity;
	}

	// 示意：以用戶身份證字號查詢用戶個人資料。
	private Object findUserData(String userUid, String customParam) {
		return new Object();
	}


}

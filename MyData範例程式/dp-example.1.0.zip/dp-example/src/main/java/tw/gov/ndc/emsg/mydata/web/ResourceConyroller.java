package tw.gov.ndc.emsg.mydata.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.bean.IntrospectEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;

@Controller
@RequestMapping("/resource")
public class ResourceConyroller {
	private static final Logger logger = LoggerFactory.getLogger(ResourceConyroller.class);
	private static DecimalFormat formatter = new DecimalFormat("#.#");
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
	@Autowired
	private GspOidcClient gspClient;
	@Autowired
	private NonceHelper nonceHelper;
	@Value("${gsp.oidc.resource.id}")
	private String resourceId;
	@Value("${gsp.oidc.resource.secret}")
	private String resourceSecret;
	@Value("${app.download.path.temp}")
	private String downPath;
	
	/**
	 * 資料下載處理：參考「資料提供者技術文件 捌、DP-API Endpoint 規格準則」和 [流程示意圖]
	 */
	@GetMapping
	public void getResourceDataHandleProcessor(
			HttpServletRequest request, 
			HttpServletResponse response) throws IOException {
		/**
		 * MyData發出heartbeat請求判斷
		 * 請參考：「資料提供者技術文件 捌、DP-API Endpoint 規格準則」 三、DP-API Heartbeat 機制說明
		 */
		boolean heartbeat = false;
		if(request.getParameter("heartbeat")!=null&&request.getParameter("heartbeat").equalsIgnoreCase("true")) {
			heartbeat = true;
		}
		/**
		 * heartbeat=true，不處理內容，僅做系統狀態回應
		 */
		if(heartbeat) {
			response.setStatus(HttpServletResponse.SC_OK);
		}else {
			/**
			 * header參數處理
			 */
		    Map<String, String> map = new HashMap<String, String>();
		    Enumeration headerNames = request.getHeaderNames();
		    while (headerNames.hasMoreElements()) {
		        String key = (String) headerNames.nextElement();
		        String value = request.getHeader(key);
		        map.put(key, value);
		    }
		    /**
		     * 取得 access_token 資料
		     */
		    String authorization = map.get("Authorization");
		    String accessToken = authorization.replace("Bearer ", "");
		    /**
		     * 驗證access_token，反查access_token
		     * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 三、Introspection Endpoint」
		     */
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					/**
					 * access_token驗證成功
					 */
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					/**
					 * access_token驗證失敗
					 */
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			
			/**
			 * 取得 user info 
			 * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 四、UserInfo Endpoint」
			 */
			UserInfoEntity userInfoEntity = null;
			try {
				// 以access_token去要求user_info
				userInfoEntity = gspClient.requestUserInfo(accessToken);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (userInfoEntity != null) {
				logger.debug("sub .............. {}", userInfoEntity.getSub()); // 與id_token相同
				logger.debug("account .......... {}", userInfoEntity.getAccount()); // egov帳號
				logger.debug("uid .............. {}", userInfoEntity.getUid()); // 身份證字號
				logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); // 身份證字號是否已驗證
				logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
				logger.debug("gender ........... {}", userInfoEntity.getGender());
				logger.debug("name ............. {}", userInfoEntity.getName());
				logger.debug("email ............ {}", userInfoEntity.getEmail());
				logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
				logger.debug("phone_number ..... {}", userInfoEntity.getPhoneNumber());
			} else {
				logger.debug("userInfoEntity is NULL");
				try {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			
			/**
			 * 根據MyData傳送的Content-Type，判斷回傳的內容
			 * 1. application/json ----> 僅回傳json
			 * 2. application/pdf -----> 僅回傳pdf
			 * 3. application/zip -----> 將json和pdf打包成zip檔案
			 */
			if(introspectEntity!=null&&userInfoEntity!=null) {
			    String contentType = map.get("Content-Type");
			    if(contentType!=null&&contentType.equalsIgnoreCase("application/json")) {
			    		/**
			    		 * DP回覆請求成功 – 即時回應
			    		 */
			    		response.setStatus(HttpServletResponse.SC_OK);
					response.setHeader("Content-Type", "application/json");
					OutputStream os = response.getOutputStream();
					String outStr = "";
					os.write(outStr.getBytes("UTF-8"));
					response.getOutputStream().flush();
					response.getOutputStream().close();
					
					/**
					 * DP回覆請求成功 – 等候處理
					 */
					long waittime = 1000l; //秒
					// response.sendError(429,"Too Many Requests");
					// response.setHeader("Content-Type", "application/json");
					// response.setHeader("Retry-After", String.valueOf(waittime));
					
					/**
					 * DP回覆請求失敗
					 */
					// response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
					
			    }else if(contentType!=null&&contentType.equalsIgnoreCase("application/pdf")) {
			    		/**
			    		 * DP回覆請求成功 – 即時回應
			    		 */
			    		response.setStatus(HttpServletResponse.SC_OK);
					response.setHeader("Content-Type", "application/pdf");
					response.setHeader("Content-Disposition", "attachment; filename={filename}");
					OutputStream os = response.getOutputStream();
					String outStr = "";
					os.write(outStr.getBytes("UTF-8"));
					response.getOutputStream().flush();
					response.getOutputStream().close();
					
					/**
					 * DP回覆請求成功 – 等候處理
					 */
					long waittime = 1000l; //秒
					// response.sendError(429,"Too Many Requests");
					// response.setHeader("Content-Type", "application/json");
					// response.setHeader("Retry-After", String.valueOf(waittime));
					
					/**
					 * DP回覆請求失敗
					 */
					// response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
			    }if(contentType!=null&&contentType.equalsIgnoreCase("application/zip")) {
			    		/**
			    		 * DP回覆請求成功 – 即時回應
			    		 */
			    		response.setStatus(HttpServletResponse.SC_OK);
					response.setHeader("Content-Type", "application/zip");
					response.setHeader("Content-Disposition", "attachment; filename={filename}");
					File localFile = new File("/User/mac/xxxxxx.zip");
					InputStream file_input = new FileInputStream(localFile);
					org.apache.commons.io.IOUtils.copy(file_input, response.getOutputStream());
					response.getOutputStream().flush();
					response.getOutputStream().close();
					
					/**
					 * DP回覆請求成功 – 等候處理
					 */
					long waittime = 1000l; //秒
					// response.sendError(429,"Too Many Requests");
					// response.setHeader("Content-Type", "application/json");
					// response.setHeader("Retry-After", String.valueOf(waittime));
					
					/**
					 * DP回覆請求失敗
					 */
					// response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
			    }else {
					/**
					 * DP回覆請求失敗
					 */			    	
			    		response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
			    }
			}
		}		
	}
	
}

package tw.gov.ndc.emsg.mydata.web;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.bean.IntrospectEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;
import tw.gov.ndc.emsg.mydata.util.DpPackFileUtils;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.*;
import java.security.cert.CertificateException;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Map;

@RestController
@RequestMapping("/mydata-dp")
public class ResourceController {

	private static final Logger logger = LoggerFactory.getLogger(ResourceController.class);
	private static DecimalFormat formatter = new DecimalFormat("#.#");
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	private GspOidcClient gspClient;
	@Autowired
	private NonceHelper nonceHelper;
	@Value("${app.download.path.temp}")
	private String downPath;

	@Autowired
	private Environment environment;
	@Autowired
	private ServletContext servletContext;


	@GetMapping("/{resource}")
	public ResponseEntity<byte[]> getResourceDataHandleProcessor(
			@PathVariable("resource") String resource,
			@RequestHeader Map<String,String> headers,
			@RequestParam(name="heartbeat", required=false, defaultValue="false") Boolean heartbeat,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		logger.debug("handle resource {} by GET", resource);
		return handleResource(resource,headers,heartbeat);
	}

	/**
	 * 資料下載處理：參考「資料提供者技術文件 捌、DP-API Endpoint 規格準則」和 [流程示意圖]
	 */
	@PostMapping("/{resource}")
	public ResponseEntity<byte[]> postResourceDataHandleProcessor(
			@PathVariable("resource") String resource,
			@RequestHeader Map<String,String> headers,
			@RequestParam(name="heartbeat", required=false, defaultValue="false") Boolean heartbeat,
			HttpServletRequest request,
			HttpServletResponse response) throws IOException {

		logger.debug("handle resource {} by POST", resource);
		return handleResource(resource,headers,heartbeat);
	}

	private ResponseEntity<byte[]> handleResource(
			String resource,
			Map<String,String> headers,
			Boolean heartbeat) throws IOException {

		logger.info("resource .......,.. {}", resource);
		logger.info("heartbeat ......... {}", heartbeat);
		logger.trace("headers ........... {}", headers.size());

		headers.keySet().iterator().forEachRemaining(key -> {
			logger.debug("header -> {} : {}", key, headers.get(key));
		});

		/**
		 * MyData發出heartbeat請求判斷
		 * 請參考：「資料提供者技術文件 捌、DP-API Endpoint 規格準則」 三、DP-API Heartbeat 機制說明
		 */
		if(heartbeat) {
			// TODO 實作確認 DP-API 狀態之程式碼。若 DP-API 狀態正常則回覆 200 OK, 若狀態異常則回覆 500 INTERNAL_SERVER_ERROR
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.OK);
			//return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.INTERNAL_SERVER_ERROR);
		}

		/**
		 * HTTP Header 'Authorization' 值為 'Bearer {access_token}'。
		 * 因此取得 access_token 的方法，即是將 Bearer 字串去除即可。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String authorization = headers.get("authorization");
		String accessToken = authorization.replace("Bearer ", "");
		logger.info("access_token ......... {}", accessToken);

		/**
		 * HTTP Header 'transaction_uid' 代表交易鍵值，用於讓DP方便識別資料查詢請求為同一次交易。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String transactionUid = headers.get("transaction_uid");
		logger.info("transaction_uid ...... {}", transactionUid);

		/**
		 * HTTP Header 'custom_param' 代表自訂查詢鍵值，custom_param只是示意用字，實際參數依各自DP資料集查詢需要而不同。
		 * 請參閱「資料提供者技術文件 捌、二、DP-API 請求及回覆規格說明」
		 */
		String customParam = headers.get("custom_param");
		logger.debug("custom_param ......... {}", customParam);


		// ------ Begin, 向GSP驗證access_token及取得user info ------

		/**
		 * 驗證access_token，反查access_token.
		 * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 三、Introspection Endpoint」
		 *
		 */
		String resourceId = environment.getProperty(resource+".resourceId");
		String resourceSecret = environment.getProperty(resource+".resourceSecret");
		logger.debug("resourceId ....... {} , {}", resourceId, resource);
		logger.debug("resourceSecret ... {} , {}", resourceSecret, resource);

		if( ! isValidAccessToken(accessToken, resourceId, resourceSecret)) {
			logger.warn("不是有效的 access_token -> {}", accessToken);
			// 反查失敗！ 回覆 401 SC_UNAUTHORIZED。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
		}

		/**
		 * 取得用戶基本資料。
		 * 「資料提供者技術文件 柒、授權主機 API Endpoint 規格說明 四、UserInfo Endpoint」
		 */
		UserInfoEntity userInfoEntity = getUserInfo(accessToken);
		String userUid = null;
		// 示意：取得用戶身份證字號。
		if(userInfoEntity == null) {
			logger.warn("無法反查 userInfo -> accessToken:{}", accessToken);
			// 無法取得用戶身份證字號！ 回覆 401 SC_UNAUTHORIZED。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
		}else {
			userUid = userInfoEntity.getUid();
			if(userUid == null || userUid.isEmpty()) {
				logger.warn("無法反查 userInfo -> accessToken:{}", accessToken);
				// 無法取得用戶身份證字號！ 回覆 401 SC_UNAUTHORIZED。
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/json"));
				return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.UNAUTHORIZED);
			}
			logger.debug("userUid ...... {}", userUid);
		}

		// ------ End, 向GSP驗證access_token及取得user info ------


		// ------ Begin, 查詢個人資料並產生打包檔後回傳 ------

		/**
		 * 若查詢個人資料需要帶入自訂參數，則驗證其格式及有效性。
		 */
		if( ! isValidCustomParam(customParam)) {
			// 缺少必要參數或是參數驗證失敗！ 回覆 400 SC_BAD_REQUEST。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.BAD_REQUEST);
		}

		// 示意：取得用戶個人資料。
		File userDataDir = findUserData(userUid, customParam, resource);
		logger.debug("userDataDir -> {}", userDataDir.getAbsolutePath());
		if(userDataDir == null || !userDataDir.exists()) {
			// 示意：查無資料！ 回覆 204 SC_NO_CONTENT。
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.NO_CONTENT);
		}

		/**
		 * 示意：產生DP打包檔。
		 * 根據MyData傳送的Content-Type，判斷回傳的內容
		 * application/zip -----> 將json和pdf打包成zip檔案
		 */
		String contentType = headers.get("content-type");
		logger.trace("header.content-type -> {}", contentType);
		if(contentType != null
				&& contentType.equalsIgnoreCase("application/zip")) {

			// 產生資料集打包檔
			File packFile = handlePackFile(resource);

			if(packFile == null) {
				/**
				 * DP回覆查無資料 204
				 */
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/json"));
				return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.NO_CONTENT);
			}

			// 示意：回傳資料集打包檔。
			if(packFile.exists() && packFile.length() > 0) {
				/**
				 * 示意：DP回覆請求成功 – 即時回應
				 */
				InputStream fileInputStream = new FileInputStream(packFile);
				ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
				IOUtils.copy(fileInputStream, byteArrayOutputStream);
				byte[] data = byteArrayOutputStream.toByteArray();

				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/zip"));
				responseHeaders.setContentLength(data.length);
				responseHeaders.set("Content-disposition", "attachment; filename="+resourceId+".zip");

				logger.info("成功回傳DP資料打包檔 -> accessToken:{} , transactionUid:{}", accessToken, transactionUid);

				return new ResponseEntity<>(data, responseHeaders, HttpStatus.OK);
			}else {
				/**
				 * 示意：DP回覆請求成功 – 資料檔案未準備好，等候處理。 回覆 429 TOO_MANY_REQUESTS
				 */
				String waitSeconds = "30";
				HttpHeaders responseHeaders = new HttpHeaders();
				responseHeaders.setContentType(MediaType.valueOf("application/json"));
				responseHeaders.set("Retry-After", waitSeconds);

				return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.TOO_MANY_REQUESTS);
			}
		}else {

			logger.warn("Content-Type 不是 application/zip 拒絕存取。 -> resource:{}, accessToken:{}, transactionUid:{}", resource, accessToken, transactionUid);

			/**
			 * DP回覆拒絕存取。 403
			 */
			HttpHeaders responseHeaders = new HttpHeaders();
			responseHeaders.setContentType(MediaType.valueOf("application/json"));
			return new ResponseEntity<>(new byte[0], responseHeaders, HttpStatus.FORBIDDEN);
		}

		// ------ End, 查詢個人資料並產生打包檔後回傳 ------
	}


	// 示意：產生DP資料打包檔。 資料檔預先準備於 resources/datafile/ 目錄下。
	private File handlePackFile(String resource) {

		final String storePassword = "dp1688";
		final String keyAlias = "dp-example";
		//final Path jksPath = Paths.get("dp-example/src/main/resources/keys/dpexample.keystore");
		//final Path certPath = Paths.get("dp-example/src/main/resources/keys/certificate.cer");
		Path jksPath = Paths.get(servletContext.getRealPath("/WEB-INF/keys/dpexample.keystore"));
		Path certPath = Paths.get(servletContext.getRealPath("/WEB-INF/keys/certificate.cer"));


		KeyStore keyStore = null;
		PrivateKey privateKey = null;
		try {

			keyStore = KeyStore.getInstance("JKS");
			keyStore.load(new FileInputStream(jksPath.toFile()), storePassword.toCharArray());
			privateKey = (PrivateKey) keyStore.getKey(keyAlias, storePassword.toCharArray());

		} catch (KeyStoreException e) {
			e.printStackTrace();
			return null;
		} catch (CertificateException e) {
			e.printStackTrace();
			return null;
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
			return null;
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		} catch (UnrecoverableKeyException e) {
			e.printStackTrace();
			return null;
		}

		File dataDir = Paths.get(servletContext.getRealPath("/WEB-INF/datafile/"+resource)).toFile();
		if(!dataDir.exists()) {
			logger.warn("資料集目錄不存在！ -> {}", dataDir.getAbsolutePath());
			return null;
		}

		// 協助產生DP資料集打包檔之工具程式。
		DpPackFileUtils utils = new DpPackFileUtils(dataDir);

		try {

			// 計算摘要值，產生 manifest.xml
			File manifestFile = utils.createManifestXml();
			logger.info("manifest.xml created in {}", manifestFile.getAbsolutePath());

			// 對 manifest.xml 進行加簽演算，產生 manifest.sha256withrsa 數位簽章檔。
			File signatureFile = utils.createSignatureFile(manifestFile, privateKey);
			logger.info("manifest.sha256withrsa created in {}", signatureFile.getAbsolutePath());

			// 將憑證檔Copy到META-INFO目錄下。
			File certFile = new File(utils.getMetaInfoDir(), "certificate.cer");
			FileUtils.copyFile(certPath.toFile(), certFile);
			logger.info("certificate.cer created in {}", certFile.getAbsolutePath());

			// 驗證數位簽章是否合法。
			boolean isQualified = utils.verifySignature();
			logger.info("manifest.xml {} qualified.", isQualified?"is":"is not");

			// 建立打包檔
			File targetFile = Paths.get(servletContext.getRealPath("/WEB-INF/packfile/"+resource+".zip")).toFile();
			utils.createPackFile(targetFile);
			logger.info("產生打包檔 -> {}", targetFile.getAbsolutePath());

			return targetFile;

		} catch (IOException e) {
			e.printStackTrace();
		} catch (InvalidKeyException e) {
			e.printStackTrace();
		} catch (CertificateException e) {
			e.printStackTrace();
		} catch (SignatureException e) {
			e.printStackTrace();
		}

		return null;
	}


	// 示意：驗證 custom_param 的格式及有效性。。
	private boolean isValidCustomParam(String customParam) {
		// TODO 執行驗證自訂參數格式是否正確，或是是否為合理有效值。
		return true;
	}


	// 示意：以 access_token 向 GSP 反查 token 的有效性。
	private boolean isValidAccessToken(String accessToken, String resourceId, String resourceSecret) throws IOException {
//		return true;
		IntrospectEntity introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
		if(introspectEntity == null) {
			logger.debug("無法透過 Introspection Endpoint 順利反查 access_token 的有效性。");
			return false;
		}

		if(introspectEntity.getActive()) {
			/**
			 * 示意 access_token 驗證成功
			 */
			logger.debug("sub ........... {}", introspectEntity.getSub());
			logger.debug("scop .......... {}", introspectEntity.getScope());
			logger.debug("clientId ...... {}", introspectEntity.getClientId());
			return true;
		}else {
			logger.debug("經反查 Introspection Endpoint 驗證 access_token 不是有效的token。");
			return false;
		}
	}

	// 示意：以 access_token 向 GSP 反查用戶基本資料。
	private UserInfoEntity getUserInfo(String accessToken) throws IOException {
		// 以access_token去要求user_info
//		UserInfoEntity entity = new UserInfoEntity();
//		entity.setUid("12345");
//		return entity;
		UserInfoEntity userInfoEntity = gspClient.requestUserInfo(accessToken);
		if (userInfoEntity != null) {
			logger.debug("sub .............. {}", userInfoEntity.getSub());         // 與id_token相同
			logger.debug("account .......... {}", userInfoEntity.getAccount());     // egov帳號
			logger.debug("uid .............. {}", userInfoEntity.getUid());         // 身份證字號
			logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid());  // 身份證字號是否已驗證
			logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
			logger.debug("gender ........... {}", userInfoEntity.getGender());
			logger.debug("name ............. {}", userInfoEntity.getName());
			logger.debug("email ............ {}", userInfoEntity.getEmail());
			logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
			logger.debug("phone_number ..... {}", userInfoEntity.getPhoneNumber());
		}
		return userInfoEntity;
	}

	// 示意：以用戶身份證字號查詢用戶個人資料。
	private File findUserData(String userUid, String customParam, String aliasName) {
		// TODO 示意：查詢並產生個人資料檔案。
		File dataDir = Paths.get(servletContext.getRealPath("/WEB-INF/datafile/"+aliasName)).toFile();
		return dataDir;
	}


}

package tw.gov.ndc.emsg.mydata.util;

import com.google.common.hash.Hashing;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.XMLWriter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.nio.file.Files;
import java.security.*;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.util.Arrays;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * 協助建立DP資料打包檔
 */
public class DpPackFileUtils {

    private static final Logger logger = LoggerFactory.getLogger(DpPackFileUtils.class);

    private File dataDir;
    private File metaInfoDir;

    private boolean rewriteEnabled = false;

    /**
     * 預設 rewriteEnable = false。
     * @param dataDir  資料檔目錄
     */
    public DpPackFileUtils(File dataDir) {
        this(dataDir, false);
    }

    /**
     *
     * @param dataDir  資料檔目錄。
     * @param rewriteEnabled  如果檔案已存在是否重新產生。
     */
    public DpPackFileUtils(File dataDir, boolean rewriteEnabled) {
        this.dataDir = dataDir;
        this.rewriteEnabled = rewriteEnabled;
        // META-INFO子目錄不存在的話就建立。
        checkMetaInfoDir();
    }

    /**
     * 建立 META-INFO 子目錄
     * @return
     */
    private File checkMetaInfoDir() {
        metaInfoDir = new File(dataDir, "META-INFO");
        if(!metaInfoDir.exists()) {
            metaInfoDir.mkdir();
        }
        return metaInfoDir;
    }

    /**
     * 取得 META-INFO 子目錄物件。
     * @return
     */
    public File getMetaInfoDir() {
        return metaInfoDir;
    }

    /**
     * 產生 manifest.xml 檔。
     * @return
     */
    public File createManifestXml() throws IOException {
        // 列出資料檔目錄下的所有資料檔。
        File[] files = dataDir.listFiles(new FileFilter() {
            @Override
            public boolean accept(File pathname) {
                return pathname.isFile();
            }
        });

        File manifestFile = new File(metaInfoDir, "manifest.xml");
        if(rewriteEnabled && manifestFile.exists()) {
            manifestFile.delete();
        }else if(manifestFile.exists() && manifestFile.length() > 0) {
            logger.debug("摘要檔已存在，不執行重新產生。 -> {}", manifestFile.getAbsolutePath());
            return manifestFile;
        }

        Document xmldoc = DocumentHelper.createDocument();
        final Element root = xmldoc.addElement("files");

        Arrays.stream(files)
                .filter(f -> f.length() > 0)
                .forEach(f -> {
                    try {
                        byte[] b = Files.readAllBytes(f.toPath());
                        String hash = Hashing.sha256().hashBytes(b).toString();
                        logger.trace("hash -> {}", hash);

                        Element elFile = root.addElement("file");
                        Element elName = elFile.addElement("filename");
                        elName.addText(f.getName());
                        Element elDigest = elFile.addElement("digest");
                        elDigest.addText(hash);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }
        });

        XMLWriter writer = new XMLWriter( new FileWriter(manifestFile));
        writer.write(xmldoc);
        writer.close();

        return manifestFile;
    }

    /**
     * 產生數位簽章檔 manifest.sha256withrsa。
     * @param privateKey
     * @return
     * @throws IOException
     * @throws InvalidKeyException
     */
    public File createSignatureFile(File manifestFile, PrivateKey privateKey) throws IOException, InvalidKeyException {
        if(manifestFile == null || !manifestFile.exists()) {
            throw new FileNotFoundException("manifest.xml 檔案不存在");
        }

        File signatureFile = new File(metaInfoDir, "manifest.sha256withrsa");
        if(rewriteEnabled && signatureFile.exists()) {
            signatureFile.delete();
        }else if(signatureFile.exists() && signatureFile.length() > 0) {
            logger.debug("數位簽章檔已存在，不執行重新產生。 -> {}", signatureFile.getAbsolutePath());
            return signatureFile;
        }

        byte[] bs = Files.readAllBytes(manifestFile.toPath());

        try {

            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initSign(privateKey);
            signature.update(bs);
            // 加簽後輸出至 manifest.sha256withrsa
            FileUtils.writeByteArrayToFile(signatureFile, signature.sign());

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (SignatureException e) {
            e.printStackTrace();
        }

        return signatureFile;
    }


    /**
     * 驗證數位簽章是否合法
     * @return
     */
    public boolean verifySignature() throws CertificateException, FileNotFoundException, InvalidKeyException, SignatureException {
        // 憑證檔
        File certFile = new File(metaInfoDir, "certificate.cer");
        // 從憑證檔中取出憑證內容
        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        Certificate cert = cf.generateCertificate(new FileInputStream(certFile));

        // TODO 向GCA或其它憑證中心驗證憑證的有效性。因為用於測試的不是合法申請的憑證，所以此處略過驗證憑證有效性的動作。

        // 從憑證檔中取出公鑰
        PublicKey publicKey = cert.getPublicKey();

        try {
            // 數位簽章檔
            File signatureFile = new File(metaInfoDir, "manifest.sha256withrsa");
            byte[] signedData = Files.readAllBytes(signatureFile.toPath());
            // 被驗證的原娟檔 manifest.xml
            File manifestFile = new File(metaInfoDir, "manifest.xml");
            byte[] bs = Files.readAllBytes(manifestFile.toPath());

            Signature signature = Signature.getInstance("SHA256withRSA");
            signature.initVerify(publicKey);
            signature.update(bs);

            return signature.verify(signedData);

        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return false;
    }

    /**
     * 產生DP資料打包檔，zip檔。
     * @param targetFile  產生zip檔的位置。
     * @return
     */
    public void createPackFile(File targetFile) throws IOException {
        if(rewriteEnabled && targetFile.exists()) {
            targetFile.delete();
        }else if(targetFile.exists() && targetFile.length() > 0) {
            logger.debug("打包檔已存在，不執行重新產生。 -> {}", targetFile.getAbsolutePath());
            return;
        }

        final ZipOutputStream zout = new ZipOutputStream(new FileOutputStream(targetFile));
        final File baseDir = dataDir;

        handleZip(zout, dataDir, dataDir);

        zout.close();
    }


    private void handleZip(ZipOutputStream zout, File sourceDir, File baseDir) {
        File[] fs = sourceDir.listFiles();
        for (File f : fs) {
            if(!f.canRead() || f.length()==0) {
                logger.warn("檔案沒有讀取權限或是檔案大小為0");
                continue;
            }
            try {

                String name = f.getAbsolutePath();
                name = name.substring(baseDir.getAbsolutePath().length());

                if(f.isDirectory()) {
                    handleZip(zout, f, baseDir);
                    continue;
                }

                zout.putNextEntry(new ZipEntry(name));

                FileInputStream fin = new FileInputStream(f);
                IOUtils.copy(fin, zout);
                zout.closeEntry();
                fin.close();

            } catch (IOException e) {
                e.printStackTrace();
            }
        }
    }

}

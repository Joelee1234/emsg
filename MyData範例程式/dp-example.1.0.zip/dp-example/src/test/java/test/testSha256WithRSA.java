package test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.UnrecoverableKeyException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.spec.X509EncodedKeySpec;
import java.util.ArrayList;
import java.util.Base64;

import org.apache.commons.io.FileUtils;

import net.lingala.zip4j.core.ZipFile;
import net.lingala.zip4j.exception.ZipException;
import net.lingala.zip4j.model.ZipParameters;
import net.lingala.zip4j.util.Zip4jConstants;

public class testSha256WithRSA {

	public final static String ALGORITHM = "RSA";
	public final static String SIGNATURE_ALGORITHM = "MD5withRSA";
	
	public static void main(String[] args) throws Exception {
		/**
		 * Java Key Store 憑證庫
		 */
		String jksPath = "/Users/mac/mydata.jks"; // jks file path
		/**
		 * 憑證庫密碼
		 */
		String jksPassword = "xxxxxxxxxxxxx"; // jks keyStore password
		/**
		 * 憑證別名
		 */
		String certAlias = "mydata.nat.gov.tw";
		/**
		 * 憑證密碼
		 */
		String certPassword = "xxxxxxxxxxxxx"; // cert password
		KeyStore keyStore = KeyStore.getInstance("JKS");
		keyStore.load(new FileInputStream(jksPath), jksPassword.toCharArray());
		PrivateKey privateKey = (PrivateKey) keyStore.getKey(certAlias, certPassword.toCharArray());
		System.out.println("私鑰：" + Base64.getEncoder().encodeToString(privateKey.getEncoded()));
		String signAlg = "SHA256withRSA"; // 簽名類型
		byte[] b = Files.readAllBytes(Paths.get("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/manifest.xml"));
		Signature signature = Signature.getInstance(signAlg);
		signature.initSign(privateKey);
		signature.update(b);
		String signedData = Base64.getEncoder().encodeToString(signature.sign()).replace("\r\n", "").replace("\n", "");
		System.out.println("簽名     ：" + signedData);
		String manifestPathStr = "/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz/META-INF/signature.sha256withrsa";
		FileUtils.writeStringToFile(new File(manifestPathStr), signedData,"UTF-8");
		
		/**
		 * PEM憑證公鑰驗簽
		 */
		signature.initVerify(getCAPublicKey());
		signature.update(b);
		boolean isVerify = signature.verify(Base64.getDecoder().decode(signedData));
		System.out.println("CA驗簽：" + isVerify);
		
		/**
		 * zip檔產生
		 */
		ArrayList<File> localFiles = new ArrayList<File>();
		File f1 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.UZQkKbsOpz.zip");
		File f2 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/API.zH584wn59r.zip");
		
		//File f3 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/manifest.xml");
		//File f4 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/signature.sha256withrsa");
		//File f5 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/certification.cer");
		localFiles.add(f1);
		localFiles.add(f2);
		//localFiles.add(f3);
		//localFiles.add(f4);
		//localFiles.add(f5);
		packZip(new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ_2.zip"),localFiles);		
	}

	/**
	 * 憑證取的公鑰
	 * @return
	 * @throws Exception
	 */
	private static PublicKey getCAPublicKey() throws Exception {
		String keyStr = "";
		try {
			CertificateFactory cf = CertificateFactory.getInstance("X.509");
			Certificate cert = cf.generateCertificate(new FileInputStream("/Users/mac/mydatanatgovtw.crt"));
			keyStr = Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded());
			// System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		} catch (Exception ex) {
			ex.printStackTrace();
		}
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64.getDecoder().decode(keyStr));
		KeyFactory keyFactory = KeyFactory.getInstance(ALGORITHM);
		PublicKey k = keyFactory.generatePublic(keySpec);
		return k;
	}
	
	/**
	 * zip檔，封裝
	 */
	private static File packZip(File output, ArrayList<File> sources)
			throws IOException, ZipException {
		if (!output.getParentFile().exists()) {
			output.getParentFile().mkdirs();
		}
		ZipFile zipFile = new ZipFile(output);
		ZipParameters parameters = new ZipParameters();
		parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
		//parameters.setEncryptFiles(true);
		//parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		//parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		zipFile.addFiles(sources, parameters);
		parameters.setRootFolderInZip("META-INF");
		File f3 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/manifest.xml");
		File f4 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/signature.sha256withrsa");
		File f5 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/certification.cer");
		ArrayList<File> localFiles = new ArrayList<File>();
		localFiles.add(f3);
		localFiles.add(f4);
		localFiles.add(f5);
		zipFile.addFiles(localFiles, parameters);
		return output;
	}
	
	/**
	 * zip檔，封裝(添加密碼)
	 */
	private File packZipWithPassword(File output, ArrayList<File> sources, String password)
			throws IOException, ZipException {
		if (!output.getParentFile().exists()) {
			output.getParentFile().mkdirs();
		}
		ZipFile zipFile = new ZipFile(output);
		ZipParameters parameters = new ZipParameters();
		parameters.setCompressionMethod(Zip4jConstants.COMP_DEFLATE);
		parameters.setCompressionLevel(Zip4jConstants.DEFLATE_LEVEL_NORMAL);
		parameters.setEncryptFiles(true);
		parameters.setEncryptionMethod(Zip4jConstants.ENC_METHOD_AES);
		parameters.setAesKeyStrength(Zip4jConstants.AES_STRENGTH_256);
		parameters.setPassword(password);
		zipFile.addFiles(sources, parameters);
		parameters.setRootFolderInZip("META-INF");
		File f3 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/manifest.xml");
		File f4 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/signature.sha256withrsa");
		File f5 = new File("/Users/mac/Desktop/mydata-example/CLI.klmZFqH5SQ/META-INF/certification.cer");
		ArrayList<File> localFiles = new ArrayList<File>();
		localFiles.add(f3);
		localFiles.add(f4);
		localFiles.add(f5);
		zipFile.addFiles(localFiles, parameters);
		return output;
	}	
}

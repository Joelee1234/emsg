package test;

import org.apache.commons.io.FileUtils;
import org.slf4j.LoggerFactory;
import org.slf4j.Logger;
import tw.gov.ndc.emsg.mydata.util.DpPackFileUtils;

import java.io.File;
import java.io.FileInputStream;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.util.Arrays;

public class TestCreatePackFile {

    private static final Logger logger = LoggerFactory.getLogger(TestCreatePackFile.class);


    public static void main(String[] args) throws Exception {

        final TestCreatePackFile app = new TestCreatePackFile();
        String[] dpArray = {
                "dp01","dp02","dp03","dp04","dp05"
                ,"dp06","dp07","dp08","dp09","dp10"
                ,"dp11","dp12","dp13","dp14","dp15"
                ,"dp16","dp17","dp18"
        };

        Arrays.stream(dpArray).forEach(dpName -> {
            try {
                app.execute(dpName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }


    public void execute(String dpName) throws Exception {

        final String keyPassword = "dpexample168";
        final String storePassword = "dp1688";
        final String keyAlias = "dp-example";
        final Path jksPath = Paths.get("dp-example/WebContent/WEB-INF/keys/dpexample.keystore");
        final Path certPath = Paths.get("dp-example/WebContent/WEB-INF/keys/certificate.cer");

        //final String dpName = "dp01";

        logger.info("keystore directiory ...... {}", jksPath.toAbsolutePath().toString());

        KeyStore keyStore = KeyStore.getInstance("JKS");
        keyStore.load(new FileInputStream(jksPath.toFile()), storePassword.toCharArray());

        PrivateKey privateKey = (PrivateKey) keyStore.getKey(keyAlias, storePassword.toCharArray());
        //PublicKey publicKey = keyStore.getCertificate(keyAlias).getPublicKey();

        // DP資料集檔案產製目錄。
        File dataDir = dataFileRootDir(dpName);
        if(!dataDir.exists()) {
            logger.warn("資料集目錄不存在！ -> {}", dataDir.getAbsolutePath());
            return;
        }
        // 協助產生DP資料集打包檔之工具程式。
        DpPackFileUtils utils = new DpPackFileUtils(dataDir,true);

        // 計算摘要值，產生 manifest.xml
        File manifestFile = utils.createManifestXml();
        logger.info("manifest.xml created in {}", manifestFile.getAbsolutePath());

        // 對 manifest.xml 進行加簽演算，產生 manifest.sha256withrsa 數位簽章檔。
        File signatureFile = utils.createSignatureFile(manifestFile, privateKey);
        logger.info("manifest.sha256withrsa created in {}", signatureFile.getAbsolutePath());

        // 將憑證檔Copy到META-INFO目錄下。
        File certFile = new File(utils.getMetaInfoDir(), "certificate.cer");
        FileUtils.copyFile(certPath.toFile(), certFile);
        logger.info("certificate.cer created in {}", certFile.getAbsolutePath());

        // 驗證數位簽章是否合法。
        boolean isQualified = utils.verifySignature();
        logger.info("manifest.xml {} qualified.", isQualified?"is":"is not");

        // 建立打包檔
        File targetFile = Paths.get("dp-example/WebContent/WEB-INF/packfile/"+dpName+".zip").toFile();
        utils.createPackFile(targetFile);
        logger.info("產生打包檔 -> {}", targetFile.getAbsolutePath());

    }

    public File dataFileRootDir(String dpName) {
        return Paths.get("dp-example/WebContent/WEB-INF/datafile/"+dpName).toFile();
    }


}

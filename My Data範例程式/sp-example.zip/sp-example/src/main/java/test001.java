import java.io.IOException;
import java.util.Base64;

import tw.gov.ndc.emsg.mydata.util.DESedeCoder;
import tw.gov.ndc.emsg.mydata.util.RSAUtil;

public class test001 {

	public static void main(String[] args) throws Exception {
		String encryptedData = "ck9IHORf/kK3cdLoF9gesG1Sr68GW99tPGXJx/WMEGxTdZ+thUchlvVYBxzOQ0A/Xf841W1XgZi1N2yqaq7avcaNkVV4bijeOpTZnQssHp5rd6JY1jZ+IaPOq4Zh/VDYFJC9vrZH7NpJx/h5lrfWQKUqIojPBY9F/hAkV+8iov0=";
		String publicKeyStr = RSAUtil.getPublicKeyStr();
		// 取得Triple DES初始化密鑰
		System.out.println("公鑰：" + publicKeyStr);
		System.out.println("解密前：" + encryptedData);
		String decryptedData = RSAUtil.decryptByPublicKey(encryptedData, publicKeyStr);
		System.out.println("解密後：" + decryptedData);
	}

}

package tw.gov.ndc.emsg.mydata.entity;

import java.util.Date;
import java.util.List;

public class PrenatalExt{
	private String pid;
	private Integer count;
	private Date expectedDate;
	private List<PrenatalCare> prenatalCareList;
	public String getPid() {
		return pid;
	}
	public void setPid(String pid) {
		this.pid = pid;
	}
	public Integer getCount() {
		return count;
	}
	public void setCount(Integer count) {
		this.count = count;
	}
	public Date getExpectedDate() {
		return expectedDate;
	}
	public void setExpectedDate(Date expectedDate) {
		this.expectedDate = expectedDate;
	}
	public List<PrenatalCare> getPrenatalCareList() {
		return prenatalCareList;
	}
	public void setPrenatalCareList(List<PrenatalCare> prenatalCareList) {
		this.prenatalCareList = prenatalCareList;
	}
	
}

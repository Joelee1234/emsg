package tw.gov.ndc.emsg.mydata.config;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.bean.NonceEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.TokenRecord;

@Component
public class CustomAuthenticationEntryPoint implements AuthenticationEntryPoint{
	
	private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationEntryPoint.class);
	
	@Value("${app.oidc.authorize.uri}")
	private String gspOpenIdAuthorizeUri;
	@Value("${app.frontend.context.url}")
	private String frontendContextUrl;
	@Value("${gsp.oidc.client.id}")
	private String clientId;	
	@Autowired
	private GspOidcClient gspHelper;
	@Autowired
	private NonceHelper nonceHelper;		
	
	@Autowired
	private GspOidcClient gspClient;	
	
	@Override
	public void commence(HttpServletRequest request, HttpServletResponse response,
			AuthenticationException authException) throws IOException, ServletException {
		//tygh.sme.children-care(SP 桃園醫院，兒童健康手冊)
		List<String> needScopeList = Arrays.asList("openid","profile","offline_access","tygh.resource.vaccine.read","tygh.resource.vaccine.insert","tygh.resource.vaccine.update");
		HttpSession session = request.getSession();
		String accessToken = "";
		if(request.getParameter("accessToken")!=null&&request.getParameter("accessToken").trim().length()>0&&!request.getParameter("accessToken").equalsIgnoreCase("null")) {
			accessToken = request.getParameter("accessToken").trim();
			session.setAttribute("accessToken", accessToken);
			List<String> scopeList = new ArrayList<String>();
			//查詢授權記錄
			List<TokenRecord> tokenRecords = null;
			List<TokenRecord> retTokenRecords = new ArrayList<TokenRecord>();
			try {
				tokenRecords = gspClient.requestTokenRecords(accessToken);
				logger.debug("tokenRecords ... {}", tokenRecords);
				if(tokenRecords!=null&&tokenRecords.size()>0) {
					tokenRecords.forEach(p -> {
						logger.debug("key ................ {}", p.getKey());
						logger.debug("clientId ........... {}", p.getClientId());
						logger.debug("creationTime ....... {}", DateFormatUtils.format(p.getCreationTime(), "yyyy-MM-dd HH:mm:ss"));
						logger.debug("expiration ......... {}", p.getExpiration());
						logger.debug("subjectId .......... {}", p.getSubjectId());
						logger.debug("type ............... {}", p.getType());
						logger.debug("data ............... {}", p.getData());
						if(p.getTokenData()!=null) {
							logger.debug("data.subjectId ..... {}", p.getTokenData().getSubjectId());
							logger.debug("data.clientId ...... {}", p.getTokenData().getClientId());
							logger.debug("data.scopes ........ {}", p.getTokenData().getScopes());
							logger.debug("data.creationTime .. {}", DateFormatUtils.format(p.getTokenData().getCreationTime(),"yyyy-MM-dd HH:mm:ss"));
							logger.debug("data.expiration .... {}", p.getTokenData().getExpiration());
							if(p.getExpiration()==null) {
								scopeList.addAll(p.getTokenData().getScopes());
							}
						}
						if(p.getExpiration()==null) {
							retTokenRecords.add(p);
						}
					});
					if(scopeList!=null&&scopeList.size()>0) {
						System.out.println("---   scopeList  ----:"+scopeList);
						System.out.println("--- needScopeList ---:"+needScopeList);
						if(scopeList.containsAll(needScopeList)) {
							//TODO Login
							//nonce -> 方便用來綁定session或是token。oidc會原值返回。
							NonceEntity nonce = nonceHelper.sessionIdOrToken(request.getSession().getId())
														.timestamp(new Date())
														.build();
							String nonceString = nonceHelper.encodeNonce(nonce);
							String state = "home";		
							String redirectUrl = gspHelper.authorizationUrl(needScopeList, nonceString, state);
							response.sendRedirect(redirectUrl);
						} else {
							response.sendRedirect(frontendContextUrl+"/sp/tychSP_chBook");
						}
					}else {
						response.sendRedirect(frontendContextUrl+"/sp/tychSP_chBook");
					}
				}else {
					response.sendRedirect(frontendContextUrl+"/sp/tychSP_chBook");
				}
			} catch (Exception e) {
				response.sendRedirect(frontendContextUrl+"/sp/tychSP_chBook");
			}			
			
		}else {
			response.sendRedirect(frontendContextUrl+"/sp/tychSP_chBook");
		}
	}
}	

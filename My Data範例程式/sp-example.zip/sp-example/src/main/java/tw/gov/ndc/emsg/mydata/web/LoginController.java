package tw.gov.ndc.emsg.mydata.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.OidcConfig;
import tw.gov.ndc.emsg.mydata.gspclient.bean.NonceEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.TokenRecord;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;
import tw.gov.ndc.emsg.mydata.entity.Authcode;
import tw.gov.ndc.emsg.mydata.entity.AuthcodeExample;
import tw.gov.ndc.emsg.mydata.mapper.AuthcodeMapper;


@Controller
@RequestMapping("/login")
public class LoginController {
	private static Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired
	private GspOidcClient gspHelper;
	@Autowired
	private NonceHelper nonceHelper;	
	
	/*@Autowired
	private AuthcodeMapper authcodeMapper;*/
	
	/**
	 * https://login.cp.gov.tw/v01/connect/authorize
	 */
	@Value("${app.oidc.authorize.uri}")
	private String authorizeUri;
	
	//桃園署立醫院，孕婦健康手冊
	@Value("${gsp.oidc.client.id}")
	private String clientId;	
	@Value("${app.oidc.redirect.uri}")
	private String redirectUri;
	
	@Value("${app.oidc.response.type}")
	private String responseType;
	@Value("${app.oidc.response.mode}")
	private String responseMode;	
	@Value("${app.frontend.context.url}")
	private String frontendContextUrl;	
	@Autowired
	private GspOidcClient gspClient;	
	
	private OidcConfig config;
	
	@GetMapping
	public void getLogin(HttpServletRequest request,
			HttpServletResponse response,
			ModelMap model) {
		//tygh.sme.children-care(SP 桃園醫院，兒童健康手冊)
		List<String> needScopeList = Arrays.asList("openid","profile","offline_access","tygh.resource.vaccine.read","tygh.resource.vaccine.insert","tygh.resource.vaccine.update");
		//List<String> needScopeList = Arrays.asList("openid","profile","tygh.resource.vaccine.read","tygh.resource.vaccine.insert","tygh.resource.vaccine.update");	
		/**
		 * pid = 身分證字號，
		 * client_id = 
		 * tygh.sme.prenatal-care(SP 桃園署立醫院，孕婦健康手冊), 
		 * tygh.sme.children-care(SP 桃園署立醫院，孕婦健康手冊),
		 * mydata.portal(SP 國發會MyData入口網)
		 */
		List<Authcode> authcodes = null;
		String pid = request.getParameter("pid");
		if(pid!=null&&pid.trim().length()>0&&!pid.trim().equalsIgnoreCase("null")) {
			/*AuthcodeExample example =new AuthcodeExample();
			example.createCriteria().andPidEqualTo(pid).andClientIdEqualTo(clientId);
			example.setOrderByClause("ctime desc");
			authcodes = authcodeMapper.selectByExample(example);*/
		}
		if(authcodes==null||authcodes.size()==0) {
			try {
				response.sendRedirect(frontendContextUrl+"/sp/service_description");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}else{
			//tygh.sme.children-care(SP 桃園醫院，兒童健康手冊)
			String accessToken = authcodes.get(0).getAccessToken();
			if(accessToken!=null&&accessToken.trim().length()>0&&!accessToken.equalsIgnoreCase("null")) {
				/*
				 * 取得 user_info
				 */
				UserInfoEntity userInfoEntity = null;
				try {
					//以access_token去要求user_info
					if(accessToken != null) {
						userInfoEntity = gspClient.requestUserInfo(accessToken);
					}
				} catch (ClientProtocolException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}
				if(userInfoEntity != null) {
					/*doAutoLogin(userInfoEntity.getUid(),userInfoEntity.getUid(),request);
					HttpSession session = request.getSession();
					session.setAttribute("accessToken", accessToken);
					//return "redirect:/sp/service_in";
					try {
						response.sendRedirect(frontendContextUrl+"/sp/service_in");
					} catch (IOException e) {
						e.printStackTrace();
					}*/
					//TODO Login
					//nonce -> 方便用來綁定session或是token。oidc會原值返回。
					NonceEntity nonce = nonceHelper.sessionIdOrToken(request.getSession().getId())
												.timestamp(new Date())
												.build();
					String nonceString = nonceHelper.encodeNonce(nonce);
					String state = "app";		
					String redirectUrl = gspHelper.authorizationUrl(needScopeList, nonceString, state);
					try {
						response.sendRedirect(redirectUrl);
					} catch (IOException e) {
						e.printStackTrace();
					}
				}else {
					try {
						response.sendRedirect(frontendContextUrl+"/sp/service_description");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
	}
	
	public Map<String,String> getAuthorizationUrlMap(HttpServletRequest request){
		Map<String,String> retMap = new HashMap<String,String>();
		
		//nonce -> 方便用來綁定session或是token。oidc會原值返回。
		NonceEntity nonce = nonceHelper.sessionIdOrToken(request.getSession().getId())
									.timestamp(new Date())
									.build();
		String redirect_url = "";
		String nonceString = nonceHelper.encodeNonce(nonce);
		String state = "demo";
		//scope -> 用來指定要求的授權項目。
		List<String> scopeList = null;		
		//tygh.sme.prenatal-care(SP 桃園署立醫院，孕婦健康手冊)
		scopeList = Arrays.asList("openid","profile","offline_access","offline_access","tygh.resource.prenatal.read");
		redirect_url = "http://develop.riease.com/tygh/prenatal-care/authcode";
		String authorizationUrl = GetAuthorizationUrl(clientId,redirectUri,responseMode,responseType,scopeList, nonceString, state);
		retMap.put(clientId, authorizationUrl);
		return retMap;
	}
	
	/**
	 * GSP OpenID Connect的登入授權網址。
	 * @param scope	指定授權項目
	 * @param nonce	備註資訊
	 * @param state	狀態資訊
	 * @return
	 */
	public String GetAuthorizationUrl(String clientId,String redirectUri,String responseMode,String responseType,List<String> scopeList, String nonce, String state) {		
		StringBuilder sb = new StringBuilder();
		sb.append(authorizeUri)
			.append("?client_id=").append(clientId)
			.append("&redirect_uri=").append(redirectUri)
			.append("&response_mode=").append(responseMode)
			.append("&response_type=").append(responseType);
		final StringJoiner sj = new StringJoiner(" ");
		scopeList.forEach(p -> {
			sj.add(p);
		});
		if(StringUtils.isNotEmpty(sj.toString())) {
			sb.append("&scope=").append(sj.toString());
		}
		if(StringUtils.isNotEmpty(nonce)) {
			sb.append("&nonce=").append(nonce); 
		}
		if(StringUtils.isNotEmpty(state)) {
			sb.append("&state=").append(state);
		}
		return sb.toString();
	}
	
	private void doAutoLogin(String username, String password, HttpServletRequest request) {
	    try {
	        // Must be called from request filtered by Spring Security, otherwise SecurityContextHolder is not updated
	        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(username, password,Collections.emptyList());
	        token.setDetails(new WebAuthenticationDetails(request));
	        /*CustomAuthenticationProvider customAuthenticationProvider = new CustomAuthenticationProvider();
	        Authentication authentication = customAuthenticationProvider.authenticate(token);
	        logger.debug("Logging in with [{}]", authentication.getPrincipal());*/
	        SecurityContextHolder.getContext().setAuthentication(token);
	    } catch (Exception e) {
	        SecurityContextHolder.getContext().setAuthentication(null);
	        logger.error("Failure in autoLogin", e);
	    }

	}	
	
}

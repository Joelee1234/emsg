package tw.gov.ndc.emsg.mydata.web;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/logout")
public class LogoutController {
	
	private static Logger logger = LoggerFactory.getLogger(LogoutController.class);
	
	@GetMapping
	public String getLogout(HttpServletRequest request,HttpServletResponse response,ModelMap model) {
		return "redirect:/signout.do";
	}
}

package tw.gov.ndc.emsg.mydata.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.crypto.SecretKey;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.servlet.http.Cookie;

import org.json.simple.JSONObject;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.json.simple.JSONArray;
import org.json.simple.JSONValue;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
//import com.riease.common.helper.HttpClientHelper;
import com.riease.common.helper.HttpClientHelper;
import com.riease.common.helper.ZipUtil;

import tw.gov.ndc.emsg.mydata.entity.Account;
import tw.gov.ndc.emsg.mydata.entity.Child;
import tw.gov.ndc.emsg.mydata.entity.ChildExample;
import tw.gov.ndc.emsg.mydata.entity.Growth;
import tw.gov.ndc.emsg.mydata.entity.VaccinationRecord;
import tw.gov.ndc.emsg.mydata.entity.Vaccine;
import tw.gov.ndc.emsg.mydata.entity.VaccineExample;
import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.OidcConfig;
import tw.gov.ndc.emsg.mydata.gspclient.bean.NonceEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;
import tw.gov.ndc.emsg.mydata.mapper.AuthcodeMapper;
import tw.gov.ndc.emsg.mydata.mapper.ChildMapper;
import tw.gov.ndc.emsg.mydata.mapper.GrowthMapper;
import tw.gov.ndc.emsg.mydata.mapper.VaccinationRecordMapper;
import tw.gov.ndc.emsg.mydata.mapper.VaccineMapper;
import tw.gov.ndc.emsg.mydata.util.DESedeCoder;
import tw.gov.ndc.emsg.mydata.util.RSAUtil;

@Controller
@RequestMapping("/sp")
public class SpController {
	private static final Logger logger = LoggerFactory.getLogger(SpController.class);
	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
	
	@Value("${gsp.oidc.client.id}")
	private String clientId;		
	@Value("${gsp.oidc.client.secret}")
	private String clientSecret;
	@Autowired
	private GspOidcClient gspHelper;
	@Autowired
	private NonceHelper nonceHelper;
	
	private final Base64.Encoder encoder = Base64.getEncoder();
	
	/*
	 * @Autowired private AuthcodeMapper authcodeMapper;
	 * 
	 * @Autowired private VaccineMapper vaccineMapper;
	 * 
	 * @Autowired private ChildMapper childMapper;
	 * 
	 * @Autowired private VaccinationRecordMapper vaccinationRecordMapper;
	 * 
	 * @Autowired private GrowthMapper growthMapper;
	 */

	@Value("${app.oidc.dp.uri}")
	private String dpuri;
	@Value("${app.oidc.dp.download.uri}")
	private String dpdownloaduri;

	// app.oidc.dp.async.download.uri
	@Value("${app.oidc.dp.async.uri}")
	private String asyncdpuri;
	// app.oidc.dp.async.download.uri
	@Value("${app.oidc.dp.async.download.uri}")
	private String asyncdpdownloaduri;
	/**
	 * https://login.cp.gov.tw/v01/connect/authorize
	 */
	@Value("${app.oidc.authorize.uri}")
	private String authorizeUri;

	@Value("${app.oidc.response.type}")
	private String responseType;
	@Value("${app.oidc.response.mode}")
	private String responseMode;
	@Value("${app.jwt.secret}")
	private String jwtSecret;
	@Value("${app.download.path.temp}")
	private String downPath;
	
	//私鑰
	//@Value("${keystore.private.crypto}")
	//private String keystorePrivateCrypto=null;	
	//私鑰密碼
	//@Value("keystore.private.crypto.password}")
	//private static String keystorePrivateCryptoPassword=null;
	//公鑰
	@Value("${keystore.public.crypto}")
	private String keystorePublicCrypto;
	
	private OidcConfig config;

	@GetMapping("/error")
	public String getError(ModelMap model) {
		return "dp_error";
	}

	/**
	 * 導向服務說明頁，此頁內含登入機制
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@GetMapping("/service_description")
	public String getSpChBookDesc(HttpServletRequest request, HttpServletResponse response, ModelMap model) {
		HttpSession session = request.getSession();

		// nonce -> 方便用來綁定session或是token。oidc會原值返回。
		NonceEntity nonce = nonceHelper.sessionIdOrToken(request.getSession().getId()).timestamp(new Date()).build();
		List<String> scopeList = null;

		scopeList = Arrays.asList("openid", "profile", "offline_access", "tygh.resource.vaccine.read",
				"tygh.resource.vaccine.insert", "tygh.resource.vaccine.update");
		String nonceString = nonceHelper.encodeNonce(nonce);
		String state = "home";
		String redirectUrl = gspHelper.authorizationUrl(scopeList, nonceString, state);
		System.out.println("== redirectUrl ==:" + redirectUrl);
		model.addAttribute("redirectUrl", redirectUrl);
		session.setAttribute("redirectUrl", redirectUrl);

		return "service_description";
	}


	/**
	 * 加值服務頁
	 * @param model
	 * @return
	 */
	@GetMapping("/service_in")
	public String getSpChBook_in(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		String uid = auth.getName();
		model.addAttribute("uid", uid);

		/**
		 * 向DP要求資料前，先記Log auditEvent=4
		 */
		String contentType="application/json";
		HttpClient httpClient = null;
		String respStr = null;
		List<Header> headers = new ArrayList<Header>();
		if(contentType != null && !contentType.isEmpty()) {
			Header header = new BasicHeader(HttpHeaders.CONTENT_TYPE, contentType);
			headers.add(header);
			Header header1 = new BasicHeader("Authorization", "Basic "+basicAuthenticationSchema(clientId,clientSecret));
			headers.add(header1);
		}		
		httpClient = httpClient("https://mydata.nat.gov.tw/mydatalog/v01/log",headers,20);
		String body = "";
		Map<String, String> logMap = new HashMap<String, String>();
		logMap.put("providerKey","MYDATATEST");
		logMap.put("userName","測試帳號");
		logMap.put("uid","H296197830");
		logMap.put("clientId","CLI.mydata.portal"); //本服務的clientId
		logMap.put("resourceId","API.WE8hJHljiN"); //要取資料DP的resourceId
		logMap.put("auditEvent","4");//要求Log
		logMap.put("scope","A");
		logMap.put("ip","127.0.0.1");
		try {
			body = new ObjectMapper().writeValueAsString(logMap);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		try {
			StringEntity entity = new StringEntity(body);
			HttpPost post = new HttpPost("https://mydata.nat.gov.tw/mydatalog/v01/log");
			post.setEntity(entity);
			
			HttpResponse httpResponse = httpClient.execute(post);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			if(HttpStatus.SC_OK == statusCode) {
				HttpEntity resp = httpResponse.getEntity();
				InputStream in = resp.getContent();
				StringWriter sw = new StringWriter();
				IOUtils.copy(in, sw, "UTF-8");
				sw.close();
				in.close();
				respStr = sw.toString();
			}else {
				logger.warn("HttpStatus : "+statusCode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}		
		
		
		/**
		 * 導向dp,取得dp回應JSON資料
		 */
		// http://develop.riease.com/db-example/dp/service_description
		String dpPrenatalUrl = dpuri;
		Map<String, String> paramMap = new HashMap<String, String>();
		String accessToken = session.getAttribute("accessToken") == null ? null
				: (String) session.getAttribute("accessToken");
		String dpDownloadUrl = dpdownloaduri + "?accessToken=" + accessToken;
		model.addAttribute("dpDownloadUrl", dpDownloadUrl);
		String asyncdpurl = asyncdpuri + "?accessToken=" + accessToken;
		model.addAttribute("asyncdpurl", asyncdpurl);
		String asyncdpdownloadurl = asyncdpdownloaduri + "?accessToken=" + accessToken;
		model.addAttribute("asyncdpdownloadurl", asyncdpdownloadurl);
		paramMap.put("accessToken", accessToken);
		model.addAttribute("accessToken", accessToken);

		String PostJsonString = "";
		try {
			PostJsonString = new ObjectMapper().writeValueAsString(paramMap);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		// Cookie
		Cookie[] cookies = request.getCookies();
		Cookie[] requestLocalCookies = new Cookie[cookies.length];
		List<Cookie> lcs = new ArrayList<Cookie>();
		String jSessionId = "";
		for (int i = 0; i < cookies.length; i++) {
			Cookie c = cookies[i];
			if (!c.getName().equals("JSESSIONID")) {
				continue;
			}
			jSessionId = c.getValue();
			Cookie newCookie = new Cookie(c.getName(), c.getValue());
			newCookie.setDomain("localhost");
			newCookie.setPath("/");
			newCookie.setMaxAge(c.getMaxAge());
			lcs.add(newCookie);
		}
		requestLocalCookies = lcs.toArray(new Cookie[] {});
		HttpClientHelper h = new HttpClientHelper();
		String r2 = h.post(dpPrenatalUrl, PostJsonString, requestLocalCookies);


		try {
			/**
			 * 無回應
			 */
			if (r2 == null || r2.trim().length() == 0 || r2.equalsIgnoreCase("null")) {
				/*
				 * try { response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
				 * "Access Denied"); } catch (IOException e) { e.printStackTrace(); }
				 */
				return "redirect:/sp/service_description";
			}

			/**
			 * 有回應，剖析回應json
			 */
			JSONObject json2 = (JSONObject) JSONValue.parseWithException(r2);
			JSONArray childList = (JSONArray) ((JSONObject) json2.get("data")).get("childList");
			JSONArray growthList = null;
			JSONArray vaccinationRecordList = null;
			if (childList != null && childList.size() > 0) {
				growthList = (JSONArray) ((JSONObject) childList.get(0)).get("growthList");
				vaccinationRecordList = (JSONArray) ((JSONObject) childList.get(0)).get("vaccinationRecordList");
			}
			JSONObject account = (JSONObject) ((JSONObject) json2.get("data")).get("account");
			model.addAttribute("childList", childList);
			session.setAttribute("childList", childList);
			model.addAttribute("growthList", growthList);
			session.setAttribute("growthList", growthList);
			model.addAttribute("vaccinationRecordList", vaccinationRecordList);
			session.setAttribute("vaccinationRecordList", vaccinationRecordList);
			
			model.addAttribute("account", account);
			session.setAttribute("account", account);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		/**
		 * 收到DP資料後，Log auditEvent=6
		 */
		if(contentType != null && !contentType.isEmpty()) {
			Header header = new BasicHeader(HttpHeaders.CONTENT_TYPE, contentType);
			headers.add(header);
			Header header1 = new BasicHeader("Authorization", "Basic "+basicAuthenticationSchema(clientId,clientSecret));
			headers.add(header1);
		}		
		httpClient = httpClient("https://mydata.nat.gov.tw/mydatalog/v01/log",headers,20);
		body = "";
		Map<String, String> logMap1 = new HashMap<String, String>();
		logMap1.put("providerKey","MYDATATEST");
		logMap1.put("userName","測試帳號");
		logMap1.put("uid","H296197830");
		logMap1.put("clientId","CLI.mydata.portal"); //本服務的clientId
		logMap1.put("resourceId","API.WE8hJHljiN"); //要取資料DP的resourceId
		logMap1.put("auditEvent","6");//要求Log
		logMap1.put("scope","A");
		logMap1.put("ip","127.0.0.1");
		try {
			body = new ObjectMapper().writeValueAsString(logMap1);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		try {
			StringEntity entity = new StringEntity(body);
			HttpPost post = new HttpPost("https://mydata.nat.gov.tw/mydatalog/v01/log");
			post.setEntity(entity);
			
			HttpResponse httpResponse = httpClient.execute(post);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			if(HttpStatus.SC_OK == statusCode) {
				HttpEntity resp = httpResponse.getEntity();
				InputStream in = resp.getContent();
				StringWriter sw = new StringWriter();
				IOUtils.copy(in, sw, "UTF-8");
				sw.close();
				in.close();
				respStr = sw.toString();
			}else {
				logger.warn("HttpStatus : "+statusCode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}	
		return "service_in";
	}

	/**
	 * 測試使用JWT方式驗證及接收資料(部份資料)
	 * 
	 * @param model
	 * @return
	 */
	@PostMapping("/service_in/jwt")
	public String getCheckJwt(ModelMap model, HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		/**
		 * 導向dp,取得dp回應JSON資料
		 */
		// http://develop.riease.com/db-example/dp/service_description
		String dpPrenatalUrl = dpuri + "/jwt";
		Map<String, String> paramMap = new HashMap<String, String>();
		String accessToken = session.getAttribute("accessToken") == null ? null
				: (String) session.getAttribute("accessToken");
		String dpDownloadUrl = dpdownloaduri + "?accessToken=" + accessToken;
		model.addAttribute("dpDownloadUrl", dpDownloadUrl);
		paramMap.put("accessToken", accessToken);
		model.addAttribute("accessToken", accessToken);
		String PostJsonString = "";
		try {
			PostJsonString = new ObjectMapper().writeValueAsString(paramMap);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		// Cookie
		Cookie[] cookies = request.getCookies();
		Cookie[] requestLocalCookies = new Cookie[cookies.length];
		List<Cookie> lcs = new ArrayList<Cookie>();
		String jSessionId = "";
		for (int i = 0; i < cookies.length; i++) {
			Cookie c = cookies[i];
			if (!c.getName().equals("JSESSIONID")) {
				continue;
			}
			jSessionId = c.getValue();
			Cookie newCookie = new Cookie(c.getName(), c.getValue());
			newCookie.setDomain("localhost");
			newCookie.setPath("/");
			newCookie.setMaxAge(c.getMaxAge());
			lcs.add(newCookie);
		}
		requestLocalCookies = lcs.toArray(new Cookie[] {});
		HttpClientHelper h = new HttpClientHelper();
		String r2 = h.post(dpPrenatalUrl, PostJsonString, requestLocalCookies);
		try {
			if (r2 == null || r2.trim().length() == 0 || r2.equalsIgnoreCase("null")) {
				return "redirect:/sp/service_description";
			}

			JSONObject json2 = (JSONObject) JSONValue.parseWithException(r2);
			String data_token = (String) ((JSONObject) json2.get("data")).get("data_token");
			String token = data_token;
			Account account = new Account();
			try {
				// JWT secret = vkWj0iDkmS
				Algorithm algorithm = Algorithm.HMAC256(jwtSecret);
				JWTVerifier verifier = JWT.require(algorithm).build(); // Reusable verifier instance
				DecodedJWT jwt = verifier.verify(token);
				account.setAccountId(jwt.getClaim("accountId").asString());
				account.setAddress(jwt.getClaim("address").asString());
				account.setLoginId(jwt.getClaim("loginId").asString());
				account.setPid(jwt.getClaim("pid").asString());
				account.setName(jwt.getClaim("name").asString());
			} catch (UnsupportedEncodingException exception) {
				// UTF-8 encoding not supported
			} catch (JWTVerificationException exception) {
				// Invalid signature/claims
			}
			model.addAttribute("account", account);
			session.setAttribute("account", account);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return "checkJwt";
	}
	
	/**
	 * 大量批次資料，下載並解壓密
	 * @param model
	 * @param request
	 * @param response
	 * @throws Exception
	 */
	@GetMapping("/service_in/async/download")
	public void spDownloadDpFile(ModelMap model, HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		HttpSession session = request.getSession();
		String accessToken = session.getAttribute("accessToken") == null ? null
				: (String) session.getAttribute("accessToken");
		String asyncdpdownloadurl = asyncdpdownloaduri + "?accessToken=" + accessToken;

		String uid = "";
		UserInfoEntity userInfoEntity = null;
		try {
			// 以access_token去要求user_info
			userInfoEntity = gspHelper.requestUserInfo(accessToken);
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (userInfoEntity != null) {
			logger.debug("sub .............. {}", userInfoEntity.getSub()); // 與id_token相同
			logger.debug("account .......... {}", userInfoEntity.getAccount()); // egov帳號
			logger.debug("uid .............. {}", userInfoEntity.getUid()); // 身份證字號
			logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); // 身份證字號是否已驗證
			logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
			logger.debug("gender ........... {}", userInfoEntity.getGender());
			logger.debug("name ............. {}", userInfoEntity.getName());
			logger.debug("email ............ {}", userInfoEntity.getEmail());
			logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
			if (userInfoEntity.getUid() != null) {
				uid = userInfoEntity.getUid();
			}
		} else {
			logger.debug("userInfoEntity is NULL");
			try {
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		//要解壓縮的目的目錄
		String sourceDir = downPath + "/" + uid;
		File delOldFile = new File(sourceDir);
		if(delOldFile.exists()) {
			File[] childdelOldFiles = delOldFile.listFiles();
			if(childdelOldFiles!=null&&childdelOldFiles.length>0) {
				for(File delfile:childdelOldFiles) {
					System.out.println("delete old file="+delfile.getAbsolutePath());
					delfile.delete();
				}
			}
			delOldFile.deleteOnExit();
		}
		File delOldzipFile = new File(sourceDir+".zip");
		delOldzipFile.deleteOnExit();
		
		/**
		 * 向DP下載檔案
		 */
		URL url = new URL(asyncdpdownloadurl);
		try {
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("GET");
			InputStream in = connection.getInputStream();
			FileOutputStream out = new FileOutputStream(downPath + "/" + uid + ".zip");
			copy(in, out, 1024);
			out.close();
		}catch (IOException e) {  
			response.setContentType("text/html;charset=UTF-8");
			try (PrintWriter outpage = response.getWriter()) {
				outpage.println("<!DOCTYPE html>");
				outpage.println("<html>");
				outpage.println("<head>");
				outpage.println("<title>批量處理檔案尚未產生</title>");
				outpage.println("</head>");
				outpage.println("<body>");
				outpage.println("<h1>批量處理檔案尚未產生，請稍後再執行抓取！</h1>");
				outpage.println("</body>");
				outpage.println("</html>");
			}
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
		/**
		 * 解壓
		 */
		// 開啟欲解壓縮的檔案
		//ZipUtil.unzip(downPath + "/" + uid + ".zip", downPath);
		File inFileDir = new File(downPath + "/" + uid);
		inFileDir.mkdirs();
        try {
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(downPath + "/" + uid + ".zip"));
            ZipInputStream zis = new ZipInputStream(bis);
            BufferedOutputStream bos = null;
            //byte[] b = new byte[1024];
            ZipEntry entry = null;
            while ((entry=zis.getNextEntry()) != null) {
                 String entryName = entry.getName();
                 bos = new BufferedOutputStream(new FileOutputStream(downPath + "/" + uid + "/"+ entryName));
                 int b = 0;
                 while ((b = zis.read()) != -1) {
                      bos.write(b);
                 }
                 bos.flush();
                 bos.close();
            }
            zis.close();
        } catch (IOException e) {
    	   		e.printStackTrace();
        }
		
		/**
		 * 解密
		 */
		//1. 找出所有需處理檔案
		File[] sourceDirFiles = new File(sourceDir).listFiles();
		//2. 讀DESedeKey.dat
		if((new File(sourceDir+"/DESedeKey.dat")).exists()) {
			String encryptedData = DESedeCoder.readFile(sourceDir+"/DESedeKey.dat");
			//取的公鑰
			RSAUtil rsaUtil = new RSAUtil();
			//rsaUtil.setKeystorePrivateCrypto(keystorePrivateCrypto);
			//rsaUtil.setKeystorePrivateCryptoPassword(keystorePrivateCryptoPassword);
			rsaUtil.setKeystorePublicCrypto(keystorePublicCrypto);
			
			String publicKeyStr = rsaUtil.getPublicKeyStr();
			// 取得Triple DES初始化密鑰
			System.out.println("公鑰：" + publicKeyStr);
			System.out.println("解密前：" + encryptedData);
			String decryptedData = rsaUtil.decryptByPublicKey(encryptedData.trim(), publicKeyStr.trim());
			System.out.println("解密後：" + decryptedData);
			byte[] key = Base64.getDecoder().decode(decryptedData);
			if(sourceDirFiles!=null&&sourceDirFiles.length>0) {
				for(int i=0;i<sourceDirFiles.length;i++) {
					File f = sourceDirFiles[i];
					if(!f.getName().equalsIgnoreCase("DESedeKey.dat")) {
						Path path = Paths.get(f.getAbsolutePath());
						byte[] data = Files.readAllBytes(path);
						FileUtils.writeByteArrayToFile(new File(f.getAbsolutePath()), DESedeCoder.decrypt(data, key));
					}
				}
			}
		}
		
		response.setContentType("text/html;charset=UTF-8");
		try (PrintWriter outpage = response.getWriter()) {
			outpage.println("<!DOCTYPE html>");
			outpage.println("<html>");
			outpage.println("<head>");
			outpage.println("<title>批量服務已接收</title>");
			outpage.println("</head>");
			outpage.println("<body>");
			outpage.println("<h1>批量服務已接收！</h1>");
			outpage.println("</body>");
			outpage.println("</html>");
		}
	}

	public static void copy(InputStream input, OutputStream output, int bufferSize) throws IOException {
		byte[] buf = new byte[bufferSize];
		int n = input.read(buf);
		while (n >= 0) {
			output.write(buf, 0, n);
			n = input.read(buf);
		}
		output.flush();
	}
	
	/*
	 * 符合 HTTP Basic authentication schema 將 clientId:clientSecret 字串以Base64編碼。
	 * @param clientId
	 * @param clientSecret
	 * @return
	 */
	private String basicAuthenticationSchema(String clientId, String clientSecret) {
		StringBuilder sb = new StringBuilder();
		sb.append(clientId).append(":").append(clientSecret);
		try {
			//return encoder.encodeToString(sb.toString().getBytes("UTF-8"));
			return encoder.encodeToString(sb.toString().getBytes());
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}	
	
	private HttpClient httpClient(String url, List<Header> headers, int timeout) {
		return httpClient(url,headers,null,timeout);
	}
	
	private HttpClient httpClient(String url, List<Header> headers, CookieStore cookieStore, int timeout) {
		RequestConfig config = RequestConfig.custom()
				  .setConnectTimeout(timeout * 1000)
				  .setConnectionRequestTimeout(timeout * 1000)
				  .setSocketTimeout(timeout * 1000).build();
		
		HttpClient httpClient = null;
		if(url.startsWith("https://")) {
			SSLContextBuilder sslContextBuilder = SSLContexts.custom();
			try {
				sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
					@Override
					public boolean isTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
						return true;
					}
				});
				
				SSLContext sslContext = sslContextBuilder.build();
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				        sslContext, new HostnameVerifier() {

							@Override
							public boolean verify(String host, SSLSession ssl) {
								return true;
							}
				        	
				        });
				
				Registry<ConnectionSocketFactory> socketFactoryRegistry = 
						RegistryBuilder.<ConnectionSocketFactory>create().register("https", sslsf).build();
				
				PoolingHttpClientConnectionManager cm = 
						new PoolingHttpClientConnectionManager(socketFactoryRegistry);
				
				HttpClientBuilder httpClientBuilder = HttpClients.custom();
				httpClientBuilder.setConnectionManager(cm);
				if(headers != null) {
					httpClientBuilder.setDefaultHeaders(headers);
				}
				if(cookieStore != null) {
					httpClientBuilder.setDefaultCookieStore(cookieStore);
				}
				if(config != null) {
					httpClientBuilder.setDefaultRequestConfig(config);
				}
				
				httpClient = httpClientBuilder.build();
				
			} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e1) {
				e1.printStackTrace();
			}
		}else {
			HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
			if(headers != null) {
				httpClientBuilder.setDefaultHeaders(headers);
			}
			if(cookieStore != null) {
				httpClientBuilder.setDefaultCookieStore(cookieStore);
			}
			if(config != null) {
				httpClientBuilder.setDefaultRequestConfig(config);
			}
			
			httpClient = httpClientBuilder.build();
		}
		return httpClient;
	}
}

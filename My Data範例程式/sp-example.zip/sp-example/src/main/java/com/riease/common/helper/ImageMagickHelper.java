package com.riease.common.helper;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.im4java.core.ConvertCmd;
import org.im4java.core.IM4JavaException;
import org.im4java.core.IMOperation;
import org.im4java.core.IdentifyCmd;
import org.im4java.process.Pipe;
import org.im4java.process.ProcessStarter;


/**
 * 變更圖檔尺寸等屬性之工具物件。可取代ImageHelper及ImageScaleHelper的功能。<br>
 * 但系統需先行安裝ImageMagick程式。<br>
 * 相關lib: im4java-version.jar
 * @author wesleyzhuang
 *
 */
public class ImageMagickHelper {
	
	private static Logger logger = LoggerFactory.getLogger(ImageMagickHelper.class);
	
	private String searchPath = null;
	
	/**
	 * 參數帶入ImageMagick的安裝路徑下的bin目錄路徑
	 * @param searchPath
	 */
	public ImageMagickHelper(String searchPath) {
		this.searchPath = searchPath;
	}
	
	/**
	 * 以指定寬高，來變更尺寸（pixel）<br>
	 * 若指定尺寸比例與原圖比例不符時，仍以原圖尺寸比例為調整基準，調整時以比例變化較小的邊為基準，以確保圖可完整呈現。 <br>
	 * 如：若寬邊的比例變化較少，則以寬邊為基準，反之以高邊為基準。
	 * @param destWidth
	 * @param destHeight
	 * @param input
	 * @param output
	 * @throws IOException 
	 * @throws IM4JavaException 
	 * @throws InterruptedException 
	 * @throws FileNotFoundException 
	 */
	public void resizeTo(int destWidth, int destHeight, File input, File output) throws IOException, InterruptedException, IM4JavaException {
		if(input.exists()) {
			if(output.exists()) output.delete();
			if(output.createNewFile()) {
				//指定ImageMagick的安裝路徑下的bin目錄
				ProcessStarter.setGlobalSearchPath(searchPath);
				//設定cmd物件
				ConvertCmd cmd = new ConvertCmd();
				IMOperation op = new IMOperation();
				op.addImage(input.getAbsolutePath());
				op.resize(destWidth,destHeight);
				//縮圖
				op.addImage(output.getAbsolutePath());
				//開始執行
				cmd.run(op);
			}
		}else {
			throw new FileNotFoundException(input.getAbsolutePath()+" not found!");
		}
	}
	
	/**
	 * 以指定寬，來變更尺寸（pixel）
	 * @param destWidth
	 * @param input
	 * @param output
	 * @throws IOException 
	 * @throws IM4JavaException 
	 * @throws InterruptedException 
	 */
	public void resizeByWidth(int destWidth, File input, File output) throws IOException, InterruptedException, IM4JavaException {
		//計算寬邊變更比例，並以此比例計算新的長邊尺寸
		//BufferedImage img = ImageIO.read(input);
		Properties p = identify(input);
		int imgWidth = Integer.parseInt(p.getProperty("width"));
		int imgHeight = Integer.parseInt(p.getProperty("height"));
		double sx = (double) destWidth / imgWidth;
		int destHeight = (int) (sx * imgHeight);
		resizeTo(destWidth, destHeight, input, output);
	}
	
	/**
	 * 以指定高，來變更尺寸（pixel）
	 * @param destHeight
	 * @param input
	 * @param output
	 * @throws IOException 
	 * @throws IM4JavaException 
	 * @throws InterruptedException 
	 */
	public void resizeByHeight(int destHeight, File input, File output) throws IOException, InterruptedException, IM4JavaException {
		//計算寬邊變更比例，並以此比例計算新的長邊尺寸
		Properties p = identify(input);
		int imgWidth = Integer.parseInt(p.getProperty("width"));
		int imgHeight = Integer.parseInt(p.getProperty("height"));
		double sy = (double) destHeight / imgHeight;
		int destWidth = (int) (sy * imgWidth);
		resizeTo(destWidth, destHeight, input, output);
	}
	
	
	/**
	 * 將所帶入的目標尺寸，以原圖尺寸比例計算後重新調整，調整後的目標尺寸符合原圖尺寸比例。<br>
	 * 調整時以比例變化較小的邊為基準，以確保圖可完整呈現。如：若寬邊的比例變化較少，則以寬邊為基準，反之以高邊為基準。
	 * @param input			原圖
	 * @param destSize		目標尺寸。 destSize[0]:寬	destHeight[1]:高
	 * @return newDestSize	調整後的目標尺寸。 destSize[0]:寬	destHeight[1]:高
	 * @throws IM4JavaException 
	 * @throws InterruptedException 
	 */
	public Integer[] calculateWithScaleRatio(File input, Integer[] destSize) throws InterruptedException, IM4JavaException {
		int destWidth = destSize[0];
		int destHeight = destSize[1];
		logger.debug("dest width=["+destWidth+"], height=["+destHeight+"] input file=["+input.getAbsolutePath()+"]");
		
		if(destWidth == -1 || destHeight == -1) {
			Integer[] r = new Integer[2];
			r[0] = -1;	//width
			r[1] = -1;	//height
			return r;
		}
		try {
			Properties p = identify(input);
			int imgWidth = Integer.parseInt(p.getProperty("width"));
			int imgHeight = Integer.parseInt(p.getProperty("height"));
			double sx = (double) destWidth / imgWidth;
			double sy = (double) destHeight / imgHeight;
			if (sx > sy) {
				sx = sy;
				destWidth = (int) (sx * imgWidth);
			} else {
				sy = sx;
				destHeight = (int) (sy * imgHeight);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		Integer[] r = new Integer[2];
		r[0] = destWidth;
		r[1] = destHeight;
		logger.debug("calculate result width=["+destWidth+"], height=["+destHeight+"]");
		return r;
	}
	
		
	/**
	 * 識別圖檔資訊 <br>
	 * 回傳三個資訊：
	 * 	type：圖檔格式，如JPEG。
	 * 	width：寬pixel。
	 * 	height：高pixel。
	 * @param imgfile
	 * @return	
	 * @throws IOException
	 * @throws InterruptedException
	 * @throws IM4JavaException
	 */
	public Properties identify(File imgfile) throws IOException, InterruptedException, IM4JavaException {
		if(imgfile.exists()) {
			//指定ImageMagick的安裝路徑下的bin目錄
			ProcessStarter.setGlobalSearchPath(searchPath);
			//設定cmd物件
			IdentifyCmd cmd = new IdentifyCmd();
			ByteArrayOutputStream out = new ByteArrayOutputStream();
			Pipe pipeOut = new Pipe(null,out);
			cmd.setOutputConsumer(pipeOut);
			IMOperation op = new IMOperation();
			op.addImage(imgfile.getAbsolutePath());
			//開始執行
			cmd.run(op);
			String str = new String(out.toByteArray());
			String[] info = str.split(" ");
			if(info.length >= 3) {
				String[] size = info[2].split("x");
				Properties p = new Properties();
				p.setProperty("type", info[1]);
				p.setProperty("width", size[0]);
				p.setProperty("height", size[1]);
				return p;
			}else {
				return null;
			}
		}else {
			return null;
		}
	}
	
	/**
	 * input圖檔的尺寸與目標尺寸比例不同時，以填滿目標尺寸為原則來進行縮放。
	 * 以input圖的小邊為依據，等比縮放至小邊與目標尺寸相同後，再進行靠中置中裁切至與目標尺寸比例相同，且裁切後的圖將佔滿目標尺寸。
	 * 
	 * @param input		輸入圖檔
	 * @param output	輸出圖檔
	 * @param destSize	目標尺寸。 destSize[0]:寬	destHeight[1]:高
	 * @throws IM4JavaException 
	 * @throws InterruptedException 
	 * @throws IOException 
	 */
	public void resizeAndCrop(File input, File output, Integer[] destSize) throws IOException, InterruptedException, IM4JavaException {
		if(!input.exists() || destSize == null) {
			logger.warn("Input or Output file NOT exist. Or destSize is NULL.");
			return;
		}
		//指定ImageMagick的安裝路徑下的bin目錄
		ProcessStarter.setGlobalSearchPath(searchPath);
		//設定cmd物件
		ConvertCmd cmd = new ConvertCmd();
		IMOperation op = new IMOperation();
		op.addImage(input.getAbsolutePath());
		
		//以小邊為依據計算縮放後的尺寸，與原圖尺寸比例相同，但為了符合目標尺寸所以需要進行裁切。
		//小邊與目標尺寸相同，大邊一定會大於目標尺寸		
		Properties p = identify(input);
		int imgWidth = Integer.parseInt(p.getProperty("width"));
		int imgHeight = Integer.parseInt(p.getProperty("height"));
		logger.debug("input image size, width:{}, height:{}",imgWidth,imgHeight);
		
		//原圖的width:height。
		double ratio = (double)imgWidth/(double)imgHeight;
		//目標的width:height。
		double ratio2 = (double)destSize[0]/(double)destSize[1];
		
		//大邊偏差值
		int offset = 0;
		//
		if(ratio >= ratio2) { 
			//以height的縮放比例為依據，計算width值
			double sy = (double)destSize[1] / imgHeight;
			int newWidth = (int)(sy*imgWidth);
			//計算偏差值
			offset = newWidth-destSize[0];
			//縮放
			op.resize(newWidth,destSize[1]);
			logger.debug("resize to {}x{}",newWidth,destSize[1]);
			//裁切
			op.crop(destSize[0],destSize[1],(offset/2));
			logger.debug("crop to {}x{}, offset:{}",destSize[0],destSize[1],offset);
		}else { 
			//以width的縮放比例為依據，計算height值
			double sx = (double)destSize[0] / imgWidth;
			int newHeight = (int)(sx*imgHeight);
			//計算偏差值
			offset = newHeight-destSize[1];
			//縮放
			op.resize(destSize[0],newHeight);
			logger.debug("resize to {}x{}",destSize[0],newHeight);
			//裁切
			op.crop(destSize[0],destSize[1],0,(offset/2));
			logger.debug("crop to {}x{}, offset:{}",destSize[0],destSize[1],offset);
		}
		
		op.addImage(output.getAbsolutePath());
		//開始執行
		cmd.run(op);
	}

}

/**
 * 
 */
package com.riease.common.sysinit.security.jcaptcha;

import java.awt.Color;
import java.awt.Font;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.octo.captcha.CaptchaFactory;
import com.octo.captcha.component.image.backgroundgenerator.BackgroundGenerator;
import com.octo.captcha.component.image.backgroundgenerator.UniColorBackgroundGenerator;
import com.octo.captcha.component.image.color.RandomListColorGenerator;
import com.octo.captcha.component.image.fontgenerator.FontGenerator;
import com.octo.captcha.component.image.fontgenerator.RandomFontGenerator;
import com.octo.captcha.component.image.textpaster.GlyphsPaster;
import com.octo.captcha.component.image.textpaster.TextPaster;
import com.octo.captcha.component.image.textpaster.glyphsvisitor.GlyphsVisitors;
import com.octo.captcha.component.image.textpaster.glyphsvisitor.OverlapGlyphsUsingShapeVisitor;
import com.octo.captcha.component.image.textpaster.glyphsvisitor.TranslateAllToRandomPointVisitor;
import com.octo.captcha.component.image.textpaster.glyphsvisitor.TranslateGlyphsVerticalRandomVisitor;
import com.octo.captcha.component.image.wordtoimage.ComposedWordToImage;
import com.octo.captcha.component.image.wordtoimage.WordToImage;
import com.octo.captcha.component.word.DictionaryReader;
import com.octo.captcha.component.word.FileDictionary;
import com.octo.captcha.component.word.wordgenerator.DictionaryWordGenerator;
import com.octo.captcha.component.word.wordgenerator.WordGenerator;
import com.octo.captcha.engine.CaptchaEngine;
import com.octo.captcha.engine.GenericCaptchaEngine;
import com.octo.captcha.image.gimpy.GimpyFactory;
import com.octo.captcha.service.captchastore.CaptchaStore;
import com.octo.captcha.service.captchastore.FastHashMapCaptchaStore;
import com.octo.captcha.service.image.DefaultManageableImageCaptchaService;
import com.octo.captcha.service.image.ImageCaptchaService;

/**
 * 以spring配置Jcaptcha
 * @author wesleyzhuang
 *
 */
@Configuration
public class AppJcaptchaConfig {

	private static Logger logger = LoggerFactory.getLogger(AppJcaptchaConfig.class);
	
	@Value("${jcaptcha.minGuarantedStorageDelayInSeconds:180}")
	private int minGuarantedStorageDelayInSeconds;
	
	@Value("${jcaptcha.maxCaptchaStoreSize:100000}")
	private int maxCaptchaStoreSize;
	
	@Value("${jcaptcha.captchaStoreLoadBeforeGarbageCollection:75000}")
	private int captchaStoreLoadBeforeGarbageCollection;
	
	@Value("${jcaptcha.font.minSize:50}")
	private int minFontSize;
	
	@Value("${jcaptcha.font.maxSize:50}")
	private int maxFontSize;
	
	@Value("${jcaptcha.background.width:200}")
	private int backgroundWidth;
	
	@Value("${jcaptcha.background.height:70}")
	private int backgroundHeight;
	
	@Value("${jcaptcha.background.color:#FFFFFF}")
	private String backgroundColor;
	
	@Value("${jcaptcha.text.minLength:7}")
	private int textMinLength;
	
	@Value("${jcaptcha.text.maxLength:7}")
	private int textMaxLength;
	
	
	@Bean
	public ImageCaptchaService imageCaptchaService() {
		DefaultManageableImageCaptchaService service = 
				new DefaultManageableImageCaptchaService(
						captchaStore(),
						captchaEngine(),
						minGuarantedStorageDelayInSeconds,
						maxCaptchaStoreSize,
						captchaStoreLoadBeforeGarbageCollection);
		return service;
	}
	
	@Bean
	public CaptchaStore captchaStore() {
		CaptchaStore store = new FastHashMapCaptchaStore();
		return store;
	}
	
	@Bean
	public CaptchaEngine captchaEngine() {
		CaptchaFactory[] fs = new CaptchaFactory[] {
			captchaFactory()	
		};
		CaptchaEngine engine = new GenericCaptchaEngine(fs);
		return engine;
	}
	
	@Bean
	public CaptchaFactory captchaFactory() {
		CaptchaFactory factory = new GimpyFactory(
				wordGenerator(),
				wordToImage());
		return factory;
	}
	
	@Bean
	public WordGenerator wordGenerator() {
		//toddlist.properties -> 包含在 jcaptcha-2.0-alpha-1-SNAPSHOT.jar 中。
		DictionaryReader dictionary = new FileDictionary("toddlist");
		WordGenerator generator = new DictionaryWordGenerator(dictionary);
		return generator;
	}
	
	@Bean
	public WordToImage wordToImage() {
		FontGenerator fontGenerator = new RandomFontGenerator(
				minFontSize, maxFontSize, 
				new Font[] { new Font("nyala", 1, 50), new Font("Bell MT", 0, 50), new Font("Credit valley", 1, 50) }, 
				false);
		
		BackgroundGenerator backGenerator = new UniColorBackgroundGenerator(
				backgroundWidth, backgroundHeight, parseHexColor(backgroundColor));
		
		TextPaster textPaster = new GlyphsPaster(
				textMinLength, textMaxLength, 
				new RandomListColorGenerator(
					new Color[] { 
						new Color(23, 170, 27), 
						new Color(220, 34, 11), 
						new Color(23, 67, 172) }), 
				new GlyphsVisitors[] { 
					new TranslateGlyphsVerticalRandomVisitor(1.0D), 
					new OverlapGlyphsUsingShapeVisitor(3.0D), 
					new TranslateAllToRandomPointVisitor() }
				);
		
		
		WordToImage word2image = 
				new ComposedWordToImage(
						fontGenerator,
						backGenerator,
						textPaster);
		
		return word2image;
	}
	
	/*
	 * 將CSS使用的16進位表示法的色碼，轉換為java.awt.Color物件
	 */
	private Color parseHexColor(String hexColor) {
		Integer val = Integer.parseInt(hexColor.substring(1),16);
		Color color = new Color(val); 
		return color;
	}
	
}

import java.io.FileInputStream;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.util.Base64;

public class test006 {	
	private static String keystorePublicCrypto="/Users/mac/Desktop/keylist/emsg_tester.cer";
	public static void main(String[] args) {
		
		try{
		    CertificateFactory cf = CertificateFactory.getInstance("X.509");
		    Certificate cert = cf.generateCertificate(new FileInputStream(keystorePublicCrypto));
		    System.out.println(cert);
		    System.out.println(Base64.getEncoder().encodeToString(cert.getPublicKey().getEncoded()));
		}catch(Exception ex){
		    ex.printStackTrace();
		}
	}
}

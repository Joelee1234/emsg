import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import tw.gov.ndc.emsg.mydata.entity.Growth;

public class test01 {

	public static void main(String[] args) {
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		for(int i=0;i<10;i++) {
			String inpstr = "2017-"+i+"-01";
			Date t3;
			try {
				t3 = formatter.parse(inpstr);
				System.out.println(t3);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

}

/**
 * 
 */
package com.riease.common.validator;

/**
 * 檢核驗證碼
 * @author wesleyzhuang
 *
 */
public interface ValidateVcode {

}

package tw.gov.ndc.emsg.mydata.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.servlet.http.Cookie;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.CookieStore;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.cookie.ClientCookie;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.message.BasicHeader;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class FileCreateAndPostLogThread extends Thread{
	private static Logger logger = LoggerFactory.getLogger(FileCreateAndPostLogThread.class);	
	private final Base64.Encoder encoder = Base64.getEncoder();
	@Value("${gsp.oidc.client.id}")
	private String resourceId;		
	@Value("${gsp.oidc.client.secret}")
	private String resourceSecret;	
	
	public void run(){
		/**
		 * 1.產生檔案
		 * 2.上傳檔案
		 * 3.上傳已傳送Log
		 */
		//TODO 1.產生檔案
		//TODO 2.上傳檔案
		//TODO 上傳已傳送Log
		String contentType="application/json";
		HttpClient httpClient = null;
		String respStr = null;
		List<Header> headers = new ArrayList<Header>();
		if(contentType != null && !contentType.isEmpty()) {
			Header header = new BasicHeader(HttpHeaders.CONTENT_TYPE, contentType);
			headers.add(header);
			Header header1 = new BasicHeader("Authorization", "Basic "+basicAuthenticationSchema(resourceId,resourceSecret));
			headers.add(header1);
		}

		httpClient = httpClient("https://mydata.nat.gov.tw/mydatalog/v01/log",headers,20);
		String body = "";
		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put("providerKey","MYDATATEST");
		paramMap.put("userName","測試帳號");
		paramMap.put("uid","H296197830");
		paramMap.put("clientId","CLI.mydata.portal");
		paramMap.put("resourceId","API.WE8hJHljiN");
		paramMap.put("auditEvent","5");
		paramMap.put("scope","A");
		paramMap.put("ip","127.0.0.1");
		try {
			body = new ObjectMapper().writeValueAsString(paramMap);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		try {
			StringEntity entity = new StringEntity(body);
			HttpPost post = new HttpPost("https://mydata.nat.gov.tw/mydatalog/v01/log");
			post.setEntity(entity);
			
			HttpResponse httpResponse = httpClient.execute(post);
			int statusCode = httpResponse.getStatusLine().getStatusCode();
			if(HttpStatus.SC_OK == statusCode) {
				HttpEntity resp = httpResponse.getEntity();
				InputStream in = resp.getContent();
				StringWriter sw = new StringWriter();
				IOUtils.copy(in, sw, "UTF-8");
				sw.close();
				in.close();
				respStr = sw.toString();
			}else {
				logger.warn("HttpStatus : "+statusCode);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
	
	
	/*
	 * 符合 HTTP Basic authentication schema 將 clientId:clientSecret 字串以Base64編碼。
	 * @param clientId
	 * @param clientSecret
	 * @return
	 */
	private String basicAuthenticationSchema(String clientId, String clientSecret) {
		StringBuilder sb = new StringBuilder();
		sb.append(clientId).append(":").append(clientSecret);
		try {
			//return encoder.encodeToString(sb.toString().getBytes("UTF-8"));
			return encoder.encodeToString(sb.toString().getBytes());
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		}
	}	
	
	private HttpClient httpClient(String url, List<Header> headers, int timeout) {
		return httpClient(url,headers,null,timeout);
	}
	
	private HttpClient httpClient(String url, List<Header> headers, CookieStore cookieStore, int timeout) {
		RequestConfig config = RequestConfig.custom()
				  .setConnectTimeout(timeout * 1000)
				  .setConnectionRequestTimeout(timeout * 1000)
				  .setSocketTimeout(timeout * 1000).build();
		
		HttpClient httpClient = null;
		if(url.startsWith("https://")) {
			SSLContextBuilder sslContextBuilder = SSLContexts.custom();
			try {
				sslContextBuilder.loadTrustMaterial(null, new TrustStrategy() {
					@Override
					public boolean isTrusted(X509Certificate[] chain, String authType)
							throws CertificateException {
						return true;
					}
				});
				
				SSLContext sslContext = sslContextBuilder.build();
				SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(
				        sslContext, new HostnameVerifier() {

							@Override
							public boolean verify(String host, SSLSession ssl) {
								return true;
							}
				        	
				        });
				
				Registry<ConnectionSocketFactory> socketFactoryRegistry = 
						RegistryBuilder.<ConnectionSocketFactory>create().register("https", sslsf).build();
				
				PoolingHttpClientConnectionManager cm = 
						new PoolingHttpClientConnectionManager(socketFactoryRegistry);
				
				HttpClientBuilder httpClientBuilder = HttpClients.custom();
				httpClientBuilder.setConnectionManager(cm);
				if(headers != null) {
					httpClientBuilder.setDefaultHeaders(headers);
				}
				if(cookieStore != null) {
					httpClientBuilder.setDefaultCookieStore(cookieStore);
				}
				if(config != null) {
					httpClientBuilder.setDefaultRequestConfig(config);
				}
				
				httpClient = httpClientBuilder.build();
				
			} catch (NoSuchAlgorithmException | KeyStoreException | KeyManagementException e1) {
				e1.printStackTrace();
			}
		}else {
			HttpClientBuilder httpClientBuilder = HttpClientBuilder.create();
			if(headers != null) {
				httpClientBuilder.setDefaultHeaders(headers);
			}
			if(cookieStore != null) {
				httpClientBuilder.setDefaultCookieStore(cookieStore);
			}
			if(config != null) {
				httpClientBuilder.setDefaultRequestConfig(config);
			}
			
			httpClient = httpClientBuilder.build();
		}
		return httpClient;
	}
}

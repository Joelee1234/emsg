package tw.gov.ndc.emsg.mydata.web;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.UnsupportedEncodingException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.http.client.ClientProtocolException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.encoding.Md5PasswordEncoder;
import org.springframework.security.authentication.encoding.MessageDigestPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;
import com.riease.common.sysinit.controller.BaseRestController;
import com.riease.common.sysinit.rest.RestResponseBean;
import tw.gov.ndc.emsg.mydata.entity.Account;
import tw.gov.ndc.emsg.mydata.entity.AccountExample;
import tw.gov.ndc.emsg.mydata.entity.Child;
import tw.gov.ndc.emsg.mydata.entity.ChildExample;
import tw.gov.ndc.emsg.mydata.entity.ChildExt;
import tw.gov.ndc.emsg.mydata.entity.ChileExtList;
import tw.gov.ndc.emsg.mydata.entity.Growth;
import tw.gov.ndc.emsg.mydata.entity.GrowthExample;
import tw.gov.ndc.emsg.mydata.entity.Prenatal;
import tw.gov.ndc.emsg.mydata.entity.PrenatalCare;
import tw.gov.ndc.emsg.mydata.entity.PrenatalCareExample;
import tw.gov.ndc.emsg.mydata.entity.PrenatalExample;
import tw.gov.ndc.emsg.mydata.entity.PrenatalExt;
import tw.gov.ndc.emsg.mydata.entity.VaccinationRecord;
import tw.gov.ndc.emsg.mydata.entity.VaccinationRecordExample;
import tw.gov.ndc.emsg.mydata.gspclient.GspOidcClient;
import tw.gov.ndc.emsg.mydata.gspclient.NonceHelper;
import tw.gov.ndc.emsg.mydata.gspclient.bean.IntrospectEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.NonceEntity;
import tw.gov.ndc.emsg.mydata.gspclient.bean.TokenRecord;
import tw.gov.ndc.emsg.mydata.gspclient.bean.UserInfoEntity;
import tw.gov.ndc.emsg.mydata.util.DESedeCoder;
import tw.gov.ndc.emsg.mydata.util.RSAUtil;
import tw.gov.ndc.emsg.mydata.web.DpController.TableHeader;

@Controller
@RequestMapping("/dp")
public class DpController extends BaseRestController {
	private static final Logger logger = LoggerFactory.getLogger(DpController.class);
	private static DecimalFormat formatter = new DecimalFormat("#.#");
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
	private static SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Value("${baidu.tongji.url}")
	private String baiduUrl;
	@Value("${app.frontend.context.url}")
	private String frontendContextUrl;
	@Value("${app.jwt.secret}")
	private String jwtSecret;

	@Autowired
	private GspOidcClient gspHelper;
	@Autowired
	private NonceHelper nonceHelper;

	/*
	 * @Autowired private AccountMapper accountMapper;
	 * 
	 * @Autowired private ChildMapper childMapper;
	 * 
	 * @Autowired private GrowthMapper growthMapper;
	 * 
	 * @Autowired private PrenatalMapper prenatalMapper;
	 * 
	 * @Autowired private PrenatalCareMapper prenatalCareMapper;
	 * 
	 * @Autowired private VaccinationRecordMapper vaccinationRecordMapper;
	 */

	@Value("${gsp.oidc.client.id}")
	private String clientId;
	@Value("${app.oidc.redirect.uri}")
	private String redirectUri;
	@Value("${gsp.oidc.client.secret}")
	private String clientSecret;
	@Value("${app.oidc.logout.redirect.uri}")
	private String logoutRedirectUri;
	@Value("${gsp.oidc.resource.id}")
	private String resourceId;
	@Value("${gsp.oidc.resource.secret}")
	private String resourceSecret;

	@Value("${app.download.path.temp}")
	private String downPath;

	@Autowired
	private GspOidcClient gspClient;

	@Value("${keystore.crypto}")
	private String keystoreCrypto;	
	@Value("keystore.crypto.password}")
	private String keystoreCryptoPassword;	
	
	// 私鑰
	@Value("${keystore.private.crypto}")
	private String keystorePrivateCrypto;
	// 私鑰密碼
	@Value("${keystore.private.crypto.password}")
	private String keystorePrivateCryptoPassword;
	// 公鑰
	@Value("${keystore.public.crypto}")
	private String keystorePublicCrypto;

	private String uid;

	/**
	 * 加值服務類提供資料
	 * 
	 * @param model
	 * @return
	 */
	@PostMapping("/provider")
	public ResponseEntity<RestResponseBean> postDpChildhoodVaccination(@RequestBody Map<String, Object> params,
			BindingResult result, HttpServletRequest request, HttpServletResponse response) {
		String pid = "";
		/*
		 * if(params.get("pid")!=null){ pid = params.get("pid").toString(); }
		 */
		/**
		 * 反查access_token
		 */
		String accessToken = "";
		if (params.get("accessToken") != null) {
			accessToken = params.get("accessToken").toString();
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			/*
			 * 取得 user_info
			 */
			/*
			 * UserInfoEntity userInfoEntity = null; try { //以access_token去要求user_info
			 * userInfoEntity = gspClient.requestUserInfo(accessToken); } catch
			 * (ClientProtocolException e) { e.printStackTrace(); } catch (IOException e) {
			 * e.printStackTrace(); } if(userInfoEntity != null) {
			 * logger.debug("sub .............. {}", userInfoEntity.getSub()); //與id_token相同
			 * logger.debug("account .......... {}", userInfoEntity.getAccount()); //egov帳號
			 * logger.debug("uid .............. {}", userInfoEntity.getUid()); //身份證字號
			 * logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid());
			 * //身份證字號是否已驗證 logger.debug("birthdate ........ {}",
			 * userInfoEntity.getBirthdate()); logger.debug("gender ........... {}",
			 * userInfoEntity.getGender()); logger.debug("name ............. {}",
			 * userInfoEntity.getName()); logger.debug("email ............ {}",
			 * userInfoEntity.getEmail()); logger.debug("email_verified ... {}",
			 * userInfoEntity.getEmailVerified()); if(userInfoEntity.getUid()!=null) { pid =
			 * userInfoEntity.getUid(); } }else { logger.debug("userInfoEntity is NULL");
			 * try { response.sendError(HttpServletResponse.SC_UNAUTHORIZED,
			 * "Access Denied"); } catch (IOException e) { e.printStackTrace(); } }
			 */

		} else {
			try {
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		/**
		 * 非即時回應類型，可用Thread
		 * 1.產生檔案
		 * 2.上傳檔案
		 * 3.上傳已傳送Log
		 * 
		 * 即時回應類型
		 * 將Thread內要求執行於此即可
		 */
		FileCreateAndPostLogThread  fileCreateAndPostLogThread = new FileCreateAndPostLogThread();
		fileCreateAndPostLogThread.start();
		
		/**
		 * 非即時回應類型，回應檔名(陣列，可多筆)及等待時間(秒)
		 * 
		 * 即時回應類型，可將資料放於Map回應即可
		 */
		List<String> uploadFiles = new ArrayList<String>();
		uploadFiles.add("prenatal.pdf");

		Map<String, Object> data = new HashMap<>();
		data.put("upload_files", uploadFiles);
		data.put("wait_times", 60);
		return responseOK(data);
	}

	/**
	 * 加值類服務資料提供(JWT封裝資料方法)
	 * 
	 * @param params
	 * @param result
	 * @param request
	 * @param response
	 * @return
	 */
	@PostMapping("/provider/jwt")
	public ResponseEntity<RestResponseBean> postCheckJwt(@RequestBody Map<String, Object> params, BindingResult result,
			HttpServletRequest request, HttpServletResponse response) {
		String pid = "";
		/**
		 * 反查access_token
		 */
		String accessToken = "";
		if (params.get("accessToken") != null) {
			accessToken = params.get("accessToken").toString();
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		} else {
			try {
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * 資料庫資料存取 此處不使用資料庫資料，Java內預設資料
		 */
		Account account = null;
		account = new Account();
		account.setAccountId("D85D2CE6-16DC-41BF-8EBC-EE43B1E736AE");
		account.setLoginId("H296197830");
		account.setAddress("桃園市桃園區莊敬路二段38號");
		account.setPid("H296197830");
		account.setName("李小花");
		String token = "";
		try {
			// JWT secret = vkWj0iDkmS (SP--> DP必須成對)
			Algorithm algorithm = Algorithm.HMAC256(jwtSecret);
			token = JWT.create().withClaim("accountId", account.getAccountId())
					.withClaim("loginId", account.getLoginId()).withClaim("address", account.getAddress())
					.withClaim("pid", account.getPid()).withClaim("name", account.getName()).sign(algorithm);
		} catch (IllegalArgumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		Map<String, Object> data = new HashMap<>();
		data.put("data_token", token);
		return responseOK(data);
	}

	/**
	 * 資料綁成檔案下載方式
	 * 
	 * @param accessToken
	 * @param request
	 * @param response
	 */
	@GetMapping("/provider/download")
	public void postDpChildhoodVaccinationDownload(@RequestParam("accessToken") String accessToken,
			HttpServletRequest request, HttpServletResponse response) {
		HttpSession session = request.getSession();
		String pid = "";
		if (accessToken != null) {
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}

			/*
			 * 取得 user_info
			 */
			UserInfoEntity userInfoEntity = null;
			try {
				// 以access_token去要求user_info
				userInfoEntity = gspClient.requestUserInfo(accessToken);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (userInfoEntity != null) {
				logger.debug("sub .............. {}", userInfoEntity.getSub()); // 與id_token相同
				logger.debug("account .......... {}", userInfoEntity.getAccount()); // egov帳號
				logger.debug("uid .............. {}", userInfoEntity.getUid()); // 身份證字號
				logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); // 身份證字號是否已驗證
				logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
				logger.debug("gender ........... {}", userInfoEntity.getGender());
				logger.debug("name ............. {}", userInfoEntity.getName());
				logger.debug("email ............ {}", userInfoEntity.getEmail());
				logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
				if (userInfoEntity.getUid() != null) {
					pid = userInfoEntity.getUid();
				}
			} else {
				logger.debug("userInfoEntity is NULL");
				try {
					response.sendRedirect(frontendContextUrl + "/sp/error");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		} else {
			try {
				response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
			} catch (IOException e) {
				e.printStackTrace();
			}
		}

		/**
		 * 資料庫資料存取
		 */
		Account account = null;
		account = new Account();
		account.setAccountId("D85D2CE6-16DC-41BF-8EBC-EE43B1E736AE");
		account.setLoginId("H296197830");
		account.setAddress("桃園市桃園區莊敬路二段38號");
		account.setLoginId("H296197830");
		account.setPid("H296197830");
		account.setName("李小花");

		List<ChildExt> childExtList = new ArrayList<ChildExt>();
		ChildExt ext = new ChildExt();
		// ext.set
		ext.setBirthday(new Date());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		try {
			Date t = formatter.parse("1982-09-27");
			ext.setBirthday(t);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		ext.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
		try {
			Date t1 = formatter.parse("2016-01-01");
			ext.setBirthday(t1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			Date t2 = formatter.parse("2017-01-01");
			ext.setCtime(t2);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		ext.setName("李大童");
		ext.setGender("m");
		ext.setParentPid("H296197830");
		List<Growth> growthList = new ArrayList<Growth>();
		for (int i = 0; i < 10; i++) {
			Growth g = new Growth();
			g.setGid("09B0EA4E-B8E6-4666-9381-797499EA59BB");
			g.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
			g.setParentPid("H296197830");
			g.setHeight(81d);
			g.setWeight(21d);
			g.setHeadCircumference(41d);
			String inpstr = "2017-" + i + "-01";
			try {
				Date t3 = formatter.parse(inpstr);
				g.setCtime(t3);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			g.setCanChange(0);
			growthList.add(g);
		}
		ext.setGrowthList(growthList);

		List<VaccinationRecord> vaccinationRecordList = new ArrayList<VaccinationRecord>();
		for (int i = 0; i < 10; i++) {
			String inpstr = "2017-" + i + "-01";
			VaccinationRecord v = new VaccinationRecord();
			v.setVrid("1339FE87-4434-402C-BA6C-782454CC4AAD");
			v.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
			v.setParentPid("H296197830");
			v.setSuitableAge("出生滿4個月");
			v.setVaccineSpecies("白喉破傷風非細胞性百日咳、b型嗜血桿菌及不活化小兒麻痺五合一疫苗 第二劑");
			v.setVaccineCount(2);
			v.setCanChange(0);
			v.setSubsidy(1);
			v.setInoculated("1");
			v.setUnit("衛生福利部桃園醫院");
			try {
				Date t3 = formatter.parse(inpstr);
				v.setCtime(t3);
				v.setVaccinationDate(t3);
			} catch (ParseException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			vaccinationRecordList.add(v);
		}
		ext.setVaccinationRecordList(vaccinationRecordList);
		childExtList.add(ext);

		String filename = downPath + "/chbook" + session.getId() + ".pdf";
		File tempFile = new File(filename);
		if (!tempFile.getParentFile().exists()) {
			tempFile.getParentFile().mkdirs();
		}

		try {
			// ariblk.ttf 華康細明體.TTF mingliu.TTF(細明體統包)
			BaseFont bfChinese = BaseFont.createFont("kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			Font chineseFont = new Font(bfChinese, 12, Font.NORMAL);
			Document document = new Document(PageSize.A4, 36, 36, 54, 36);
			PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(filename));
			TableHeader event = new TableHeader();
			writer.setPageEvent(event);
			document.open();
			/*
			 * //設定作者 document.addAuthor("衛生福利部桃園醫院"); //設定建立者 document.addCreator("資訊室");
			 * //設定主題 document.addSubject("孕婦健康手冊"); //設定標題 document.addTitle("產前檢查記錄");
			 */
			// 設定建立時間(為當下時間)
			document.addCreationDate();
			if (childExtList != null && childExtList.size() > 0 && childExtList.get(0).getGrowthList() != null
					&& childExtList.get(0).getGrowthList().size() > 0) {
				document.add(new Phrase(childExtList.get(0).getName() + "-成長紀錄\n", chineseFont));
				document.add(createGrowthTable(childExtList.get(0).getGrowthList()));
			} else {
				document.add(new Phrase("成長紀錄：無資料\n", chineseFont));
			}
			document.newPage();
			if (childExtList != null && childExtList.size() > 0
					&& childExtList.get(0).getVaccinationRecordList() != null
					&& childExtList.get(0).getVaccinationRecordList().size() > 0) {
				document.add(new Phrase(childExtList.get(0).getName() + "-未滿7歲子女疫苗注射記錄\n", chineseFont));
				document.add(createVaccinationTable(childExtList.get(0).getVaccinationRecordList()));
			} else {
				document.add(new Phrase("未滿7歲子女疫苗注射記錄：無資料\n", chineseFont));
			}
			document.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

		if (!tempFile.exists()) {
			try {
				throw new ServletException("File doesn't exists on server.");
			} catch (ServletException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("File location on server::" + tempFile.getAbsolutePath());
		InputStream fis;
		try {
			fis = new FileInputStream(tempFile);
			response.setContentType("application/octet-stream");
			response.setContentLength((int) tempFile.length());
			response.setHeader("Content-Disposition", "attachment; filename=\"" + tempFile.getName() + "\"");

			ServletOutputStream os = response.getOutputStream();
			byte[] bufferData = new byte[1024];
			int read = 0;
			while ((read = fis.read(bufferData)) != -1) {
				os.write(bufferData, 0, read);
			}
			os.flush();
			os.close();
			fis.close();
		} catch (Exception e) {
			System.out.println(e);
			e.printStackTrace();
		}
	}

	/**
	 * 批量處理，觸發批量作業程序
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@GetMapping("/async/start")
	public void getAsyncProcessor(HttpServletRequest request, HttpServletResponse response, ModelMap model)
			throws IOException {
		String accessToken = "";
		uid = "";
		if (request.getParameter("accessToken") != null && request.getParameter("accessToken").trim().length() > 0
				&& !request.getParameter("accessToken").equalsIgnoreCase("null")) {
			/**
			 * 反查access_token
			 */
			accessToken = request.getParameter("accessToken").trim();
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			/*
			 * 取得 user_info
			 */
			UserInfoEntity userInfoEntity = null;
			try {
				// 以access_token去要求user_info
				userInfoEntity = gspClient.requestUserInfo(accessToken);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (userInfoEntity != null) {
				logger.debug("sub .............. {}", userInfoEntity.getSub()); // 與id_token相同
				logger.debug("account .......... {}", userInfoEntity.getAccount()); // egov帳號
				logger.debug("uid .............. {}", userInfoEntity.getUid()); // 身份證字號
				logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); // 身份證字號是否已驗證
				logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
				logger.debug("gender ........... {}", userInfoEntity.getGender());
				logger.debug("name ............. {}", userInfoEntity.getName());
				logger.debug("email ............ {}", userInfoEntity.getEmail());
				logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
				if (userInfoEntity.getUid() != null && !userInfoEntity.getUid().isEmpty()
						&& userInfoEntity.getUid().trim().length() > 0) {
					uid = userInfoEntity.getUid();
				}
			} else {
				logger.debug("userInfoEntity is NULL");
				try {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

			ProcessThread pt = new ProcessThread();
			// pt.requestParam = requestParser.getRquestParamMap();
			Thread t = new Thread(pt);
			t.start();

			response.setContentType("text/html;charset=UTF-8");
			try (PrintWriter out = response.getWriter()) {
				out.println("<!DOCTYPE html>");
				out.println("<html>");
				out.println("<head>");
				out.println("<title>批量服務已接收</title>");
				out.println("</head>");
				out.println("<body>");
				out.println("<h1>批量服務已接收！</h1>");
				out.println("</body>");
				out.println("</html>");
			}
		} else {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
		}
	}

	class ProcessThread implements Runnable {
		public void run() {
			// 要壓縮的來源目錄
			String sourceDir = downPath + "/" + uid;
			File delOldFile = new File(sourceDir);
			if (delOldFile.exists()) {
				File[] childdelOldFiles = delOldFile.listFiles();
				if (childdelOldFiles != null && childdelOldFiles.length > 0) {
					for (File delfile : childdelOldFiles) {
						System.out.println("delete old file=" + delfile.getAbsolutePath());
						delfile.delete();
					}
				}
				delOldFile.deleteOnExit();
			}
			File delOldzipFile = new File(sourceDir + ".zip");
			delOldzipFile.deleteOnExit();
			try {
				/**
				 * 資料庫資料存取(目前程式填入，請抽換為用資料庫內存取)
				 */
				Account account = null;
				account = new Account();
				account.setAccountId("D85D2CE6-16DC-41BF-8EBC-EE43B1E736AE");
				account.setLoginId("H296197830");
				account.setAddress("桃園市桃園區莊敬路二段38號");
				account.setLoginId("H296197830");
				account.setPid("H296197830");
				account.setName("李小花");

				List<ChildExt> childExtList = new ArrayList<ChildExt>();
				ChildExt ext = new ChildExt();
				// ext.set
				ext.setBirthday(new Date());
				SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
				try {
					Date t = formatter.parse("1982-09-27");
					ext.setBirthday(t);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				ext.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
				try {
					Date t1 = formatter.parse("2016-01-01");
					ext.setBirthday(t1);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				try {
					Date t2 = formatter.parse("2017-01-01");
					ext.setCtime(t2);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				ext.setName("李大童");
				ext.setGender("m");
				ext.setParentPid("H296197830");
				List<Growth> growthList = new ArrayList<Growth>();
				for (int i = 0; i < 2; i++) {
					Growth g = new Growth();
					g.setGid("09B0EA4E-B8E6-4666-9381-797499EA59BB");
					g.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
					g.setParentPid("H296197830");
					g.setHeight(81d);
					g.setWeight(21d);
					g.setHeadCircumference(41d);
					String inpstr = "2017-" + i + "-01";
					try {
						Date t3 = formatter.parse(inpstr);
						g.setCtime(t3);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					g.setCanChange(0);
					growthList.add(g);
				}
				ext.setGrowthList(growthList);

				List<VaccinationRecord> vaccinationRecordList = new ArrayList<VaccinationRecord>();
				for (int i = 0; i < 2; i++) {
					String inpstr = "2017-" + i + "-01";
					VaccinationRecord v = new VaccinationRecord();
					v.setVrid("1339FE87-4434-402C-BA6C-782454CC4AAD");
					v.setCid("88687BB4-208A-45FA-AAE4-440817EB7B89");
					v.setParentPid("H296197830");
					v.setSuitableAge("出生滿4個月");
					v.setVaccineSpecies("白喉破傷風非細胞性百日咳、b型嗜血桿菌及不活化小兒麻痺五合一疫苗 第二劑");
					v.setVaccineCount(2);
					v.setCanChange(0);
					v.setSubsidy(1);
					v.setInoculated("1");
					v.setUnit("衛生福利部桃園醫院");
					try {
						Date t3 = formatter.parse(inpstr);
						v.setCtime(t3);
						v.setVaccinationDate(t3);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

					vaccinationRecordList.add(v);
				}
				ext.setVaccinationRecordList(vaccinationRecordList);
				childExtList.add(ext);

				ChileExtList ChileObjExtList = new ChileExtList();
				ChileObjExtList.setChildExtList(childExtList);

				JAXBContext jaxbContext = JAXBContext.newInstance(ChileExtList.class);
				Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
				jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
				StringWriter sw = new StringWriter();
				jaxbMarshaller.marshal(ChileObjExtList, sw);
				String xmlString = sw.toString();
				System.out.println(xmlString);
				// Write to File
				BufferedWriter bOut;
				try {
					String filename = downPath + "/" + uid + "/chbook.xml";
					File tempFile = new File(filename);
					if (!tempFile.getParentFile().exists()) {
						tempFile.getParentFile().mkdirs();
					}
					bOut = new BufferedWriter(new FileWriter(filename));
					for (int i = 0; i < ((xmlString.length() / 1000) + 1); i++) {
						int start = 0 + i * 1000;
						int last = 1000 + i * 1000;
						if (last > xmlString.length()) {
							last = xmlString.length();
						}
						bOut.write(xmlString.substring(start, last));
						bOut.flush();
					}
					bOut.close();
				} catch (IOException e) {
					e.printStackTrace();
				}

				/**
				 * 處理檔案
				 */
				System.out.println("--------------------- 處理檔案 start ----------------------");
				// 1. 找出所有需處理檔案
				File[] sourceDirFiles = new File(sourceDir).listFiles();
				// 2. 初始化Triple-DES 密鑰
				byte[] key = DESedeCoder.initkey();
				// 3. Triple-DES 壓密
				if (sourceDirFiles != null && sourceDirFiles.length > 0) {
					for (int i = 0; i < sourceDirFiles.length; i++) {
						File f = sourceDirFiles[i];
						Path path = Paths.get(f.getAbsolutePath());
						byte[] data = Files.readAllBytes(path);
						FileUtils.writeByteArrayToFile(new File(f.getAbsolutePath()), DESedeCoder.encrypt(data, key));
					}
				}
				// 4. key RSA 私鑰加密（私鑰) (key base64 Ecode後壓密)
				RSAUtil rsaUtil = new RSAUtil();
				rsaUtil.setKeystorePrivateCrypto(keystorePrivateCrypto);
				rsaUtil.setKeystorePrivateCryptoPassword(keystorePrivateCryptoPassword);
				rsaUtil.setKeystorePublicCrypto(keystorePublicCrypto);

				String privateKeyStr = rsaUtil.getPrivateKeyStr();
				// key base64 Ecode後壓密
				System.out.println("壓密前:" + Base64.getEncoder().encodeToString(key));
				String encryptedData = rsaUtil.encryptByPrivateKey(Base64.getEncoder().encodeToString(key),
						privateKeyStr);
				System.out.println("壓密後:" + encryptedData);
				BufferedWriter outBuf = null;
				try {
					outBuf = new BufferedWriter(new FileWriter(sourceDir + "/DESedeKey.dat"));
					outBuf.write(encryptedData);
					outBuf.flush();
				} catch (IOException e) {
					System.out.println("Exception ");
				} finally {
					outBuf.close();
				}

				/**
				 * 壓縮檔案
				 */
				// 壓縮後要放置ZIP檔的目錄
				String targetDir = downPath;
				File books = new File(sourceDir);
				ZipOutputStream zos = new ZipOutputStream(new FileOutputStream(new File(targetDir, uid + ".zip")));
				// 取出來源目錄底下的所有 File 並新增至 ZIP 中
				for (File tmp : books.listFiles()) {
					checkFileType(tmp, zos, tmp.getName());
				}
				zos.finish();
				zos.close();
				books = null;

			} catch (Exception ex) {
				logger.debug(ex.getMessage(), ex);
			}
		}
	}

	/**
	 * 批量處理下載處理完資料檔案
	 * 
	 * @param request
	 * @param response
	 * @param model
	 * @throws IOException
	 */
	@GetMapping("/async/download")
	public void getAsyncDownloadProcessor(HttpServletRequest request, HttpServletResponse response, ModelMap model)
			throws IOException {
		String accessToken = "";
		if (request.getParameter("accessToken") != null && request.getParameter("accessToken").trim().length() > 0
				&& !request.getParameter("accessToken").equalsIgnoreCase("null")) {
			/**
			 * 反查access_token
			 */
			accessToken = request.getParameter("accessToken").trim();
			IntrospectEntity introspectEntity = null;
			try {
				introspectEntity = gspClient.introspectAccessToken(accessToken, resourceId, resourceSecret);
				if (introspectEntity != null && introspectEntity.getActive() == true) {
					logger.debug("sub .............. {}", introspectEntity.getSub());
					logger.debug("scop .............. {}", introspectEntity.getScope());
					logger.debug("clientId .............. {}", introspectEntity.getClientId());
				} else {
					try {
						response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
			/*
			 * 取得 user_info
			 */
			UserInfoEntity userInfoEntity = null;
			try {
				// 以access_token去要求user_info
				userInfoEntity = gspClient.requestUserInfo(accessToken);
			} catch (ClientProtocolException e) {
				e.printStackTrace();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if (userInfoEntity != null) {
				logger.debug("sub .............. {}", userInfoEntity.getSub()); // 與id_token相同
				logger.debug("account .......... {}", userInfoEntity.getAccount()); // egov帳號
				logger.debug("uid .............. {}", userInfoEntity.getUid()); // 身份證字號
				logger.debug("is_valid_uid ..... {}", userInfoEntity.getIsValidUid()); // 身份證字號是否已驗證
				logger.debug("birthdate ........ {}", userInfoEntity.getBirthdate());
				logger.debug("gender ........... {}", userInfoEntity.getGender());
				logger.debug("name ............. {}", userInfoEntity.getName());
				logger.debug("email ............ {}", userInfoEntity.getEmail());
				logger.debug("email_verified ... {}", userInfoEntity.getEmailVerified());
			} else {
				logger.debug("userInfoEntity is NULL");
				try {
					response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			String filename = downPath + "/" + userInfoEntity.getUid() + ".zip";
			File tempFile = new File(filename);
			if (!tempFile.exists()) {
				try {
					throw new ServletException("File doesn't exists on server.");
				} catch (ServletException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			System.out.println("File location on server::" + tempFile.getAbsolutePath());
			InputStream fis;
			try {
				fis = new FileInputStream(tempFile);
				response.setContentType("application/octet-stream");
				response.setContentLength((int) tempFile.length());
				response.setHeader("Content-Disposition", "attachment; filename=\"" + tempFile.getName() + "\"");

				ServletOutputStream os = response.getOutputStream();
				byte[] bufferData = new byte[1024];
				int read = 0;
				while ((read = fis.read(bufferData)) != -1) {
					os.write(bufferData, 0, read);
				}
				os.flush();
				os.close();
				fis.close();
			} catch (Exception e) {
				System.out.println(e);
				e.printStackTrace();
			}
		} else {
			response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Access Denied");
		}
	}

	public static PdfPTable createGrowthTable(List<Growth> growthList) {
		PdfPTable table = new PdfPTable(4);
		BaseFont bfChinese;
		try {
			bfChinese = BaseFont.createFont("kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			Font chineseFont = new Font(bfChinese, 12, Font.NORMAL);
			// the cell object
			PdfPCell cell;
			// header
			cell = new PdfPCell(new Phrase("時間", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("身高", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("體重", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("頭圍", chineseFont));
			table.addCell(cell);

			for (Growth g : growthList) {
				if (g.getCtime() == null) {
					table.addCell("");
				} else {
					table.addCell(sdf.format(g.getCtime()));
				}

				if (g.getHeight() == null) {
					table.addCell("");
				} else {
					table.addCell(sdf.format(g.getHeight()));
				}

				if (g.getWeight() == null) {
					table.addCell("");
				} else {
					table.addCell(sdf.format(g.getWeight()));
				}

				if (g.getHeadCircumference() == null) {
					table.addCell("");
				} else {
					table.addCell(sdf.format(g.getHeadCircumference()));
				}
			}
		} catch (DocumentException e) {
			System.out.println(e);
			e.printStackTrace();
		} catch (IOException e) {
			System.out.println(e);
			e.printStackTrace();
		}

		return table;
	}

	public static PdfPTable createVaccinationTable(List<VaccinationRecord> vaccinationRecordList) {
		PdfPTable table = new PdfPTable(4);
		BaseFont bfChinese;
		try {
			bfChinese = BaseFont.createFont("kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
			Font chineseFont = new Font(bfChinese, 12, Font.NORMAL);
			PdfPCell cell;
			// header
			cell = new PdfPCell(new Phrase("注射時間", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("適合年齡", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("疫苗種類", chineseFont));
			table.addCell(cell);
			cell = new PdfPCell(new Phrase("注射單位", chineseFont));
			table.addCell(cell);
			for (VaccinationRecord g : vaccinationRecordList) {
				if (g.getVaccinationDate() == null) {
					table.addCell("");
				} else {
					table.addCell(sdf.format(g.getVaccinationDate()));
				}
				if (g.getSuitableAge() == null) {
					table.addCell("");
				} else {
					table.addCell(new Phrase(g.getSuitableAge(), chineseFont));
				}
				if (g.getVaccineSpecies() == null) {
					table.addCell("");
				} else {
					table.addCell(new Phrase(g.getVaccineSpecies(), chineseFont));
				}
				if (g.getUnit() == null) {
					table.addCell("");
				} else {
					table.addCell(new Phrase(g.getUnit(), chineseFont));
				}
			}
		} catch (DocumentException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return table;
	}

	public class TableHeader extends PdfPageEventHelper {
		String header;
		PdfTemplate total;

		public void setHeader(String header) {
			this.header = header;
		}

		public void onOpenDocument(PdfWriter writer, Document document) {
			total = writer.getDirectContent().createTemplate(30, 16);
		}

		public void onEndPage(PdfWriter writer, Document document) {
			PdfPTable table = new PdfPTable(3);
			try {
				BaseFont bfChinese = BaseFont.createFont("kaiu.ttf", BaseFont.IDENTITY_H, BaseFont.EMBEDDED);
				Font chineseFont = new Font(bfChinese, 12, Font.NORMAL);
				table.setWidths(new int[] { 24, 24, 2 });
				table.setTotalWidth(527);
				table.setLockedWidth(true);
				table.getDefaultCell().setFixedHeight(20);
				table.getDefaultCell().setBorder(Rectangle.BOTTOM);
				table.addCell(header);
				table.getDefaultCell().setHorizontalAlignment(Element.ALIGN_RIGHT);
				// table.addCell(String.format("Page %d of", writer.getPageNumber()));
				table.addCell(new Phrase("衛生福利部桃園醫院 下載時間:" + sdf1.format(new Date()), chineseFont));
				PdfPCell cell = new PdfPCell(Image.getInstance(total));
				cell.setBorder(Rectangle.BOTTOM);
				table.addCell(cell);
				table.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
			} catch (DocumentException | IOException de) {
				throw new ExceptionConverter(de);
			}
			try {
				PdfContentByte cb = writer.getDirectContent();
				Image imgSoc = Image
						.getInstance("/home/develope/deploy/webapps/tygh-children-care/resources/dist/img/unnamed.png");
				imgSoc.scaleToFit(30, 30);
				imgSoc.setAbsolutePosition(33, 780);

				cb.addImage(imgSoc);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void onCloseDocument(PdfWriter writer, Document document) {
			ColumnText.showTextAligned(total, Element.ALIGN_LEFT,
					new Phrase(String.valueOf(writer.getPageNumber() - 1)), 2, 2, 0);
		}
	}

	/**
	 * 遞迴檢查 File 的屬性
	 * 
	 * @param file
	 * @param zos
	 * @param fileName
	 * @throws Exception
	 */
	private static void checkFileType(File file, ZipOutputStream zos, String fileName) throws Exception {

		if (file.isDirectory()) {
			for (File tmp : file.listFiles()) {
				checkFileType(tmp, zos, fileName + "/" + tmp.getName());
			}
		} else {
			addZipFile(file, zos, fileName);
		}
	}

	/**
	 * 新增 File 至 Zip 檔
	 * 
	 * @param file
	 * @param zos
	 * @param fileName
	 * @throws Exception
	 */
	private static void addZipFile(File file, ZipOutputStream zos, String fileName) throws Exception {
		int l;

		byte[] b = new byte[(int) file.length()];

		FileInputStream fis = new FileInputStream(file);

		ZipEntry entry = new ZipEntry(fileName);

		zos.putNextEntry(entry);

		while ((l = fis.read(b)) != -1) {
			zos.write(b, 0, l);
		}

		entry = null;
		fis.close();
		b = null;

	}

	/**
	 * 取得加密憑證(e管家訊息平台的加密憑證)
	 * 
	 * @return 已轉成byte[]的憑證
	 * @throws java.io.FileNotFoundException
	 * @throws java.io.IOException
	 */
	public byte[] getEmsgEncryptCertificate() throws FileNotFoundException, IOException {
		// 取得e管家加密憑證，轉成byte[]
		File certFile = new File(keystoreCrypto);
		FileInputStream certis = new FileInputStream(certFile);
		byte[] b = new byte[2048];
		certis.read(b);
		return b;
	}
}
